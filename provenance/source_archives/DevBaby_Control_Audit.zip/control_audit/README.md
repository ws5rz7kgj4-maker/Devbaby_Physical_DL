# Frozen world-model control audit

Posthoc evaluation only. No optimizer or training step runs. The canceled experiment is not resumed.

Reads the immutable source revision resolved at job start from swenlio/devbaby-worldmodel-results, runs/worldmodel-dacc6ff327cf. Every downloaded file is SHA256 recorded. Results are written to a unique audits/ prefix in the private dataset swenlio/devbaby-control-audit-results, created by this OAuth application. A CPU preflight successfully uploaded and read back a ZIP. Source remains the original dataset.

1. Download all 160 saved full-audio prediction panels (8 model seeds × 4 ages × 5 domains).
2. Generate 8 new synthetic exploration episodes; compare correct actions, zero actions, and reversed action sequences for object-region prediction errors, proprioception, and image persistence.
3. Generate 4 new paired scenes and 8 candidate sequences per scene: six random piecewise-constant sequences, idle, and a privileged reference as a positive control. Randomize candidate order. Evaluate frozen models at all ages against actual simulator outcomes at horizons 8/32/64.
4. Preserve full sensory recordings, raw results, source hashes and protocol. Publish after every model seed and on error.

The privileged sequence uses truth only to create an evaluation candidate. No truth enters the neural model. Its candidate identity is not given to the model. This is not a learned policy success rate, nor a test of full CEM search. Reversed-action prediction error is a diagnostic of action usefulness, not a counterfactual simulation. Aggregate means are exploratory; old and new evaluation scenes must not be reused as untouched tests after tuning.

Run with Python 3.11, torch 2.6.0, numpy 1.26.4, scipy 1.13.1, Pillow 10.4.0, pybullet 3.2.7, espeakng-loader 0.2.4, huggingface_hub 0.36.0. Set HF_TOKEN via a secret and AUDIT_PREFIX to a new path, then `python audit.py`.

Cloud configuration: one L4, maximum 30 minutes, no automatic restart. See job.json for actual submitted identity. Local validation uses a randomly initialized model only.
