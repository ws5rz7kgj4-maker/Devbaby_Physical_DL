"""Export an archived sensory episode with its actual synthetic mixture audio."""
from pathlib import Path
import argparse
import subprocess
import tempfile
import numpy as np
from scipy.io import wavfile

def export(episode,output,hz=8):
    import imageio.v2 as imageio
    import imageio_ffmpeg
    episode=Path(episode);output=Path(output).resolve();output.parent.mkdir(parents=True,exist_ok=True)
    with np.load(episode/'observations.npz',allow_pickle=False) as z:rgb=z['rgb']
    rate,wav=wavfile.read(episode/'audio.wav')
    with tempfile.TemporaryDirectory() as temp:
        temp=Path(temp);silent=temp/'video.mp4';audio=temp/'mixture.wav'
        wavfile.write(audio,rate,wav[:,0] if wav.ndim==2 else wav)
        with imageio.get_writer(silent,fps=hz,codec='libx264',quality=8) as writer:
            for frame in rgb[:-1]:writer.append_data(np.concatenate(frame,axis=1))
        subprocess.run([imageio_ffmpeg.get_ffmpeg_exe(),'-y','-loglevel','error','-i',str(silent),'-i',str(audio),
            '-c:v','copy','-c:a','aac','-shortest',str(output)],check=True)
    return output

def main():
    p=argparse.ArgumentParser();p.add_argument('--episode',required=True);p.add_argument('--output',required=True);p.add_argument('--hz',type=int,default=8)
    a=p.parse_args();print(export(a.episode,a.output,a.hz))
if __name__=='__main__':main()
