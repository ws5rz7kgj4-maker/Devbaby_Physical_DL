"""Frozen diagnostics and live physical evaluation. Ground truth stays here."""
from pathlib import Path
import json
import time
import zipfile
import shutil
import numpy as np
import torch
from .wm_data import image_tensor,choose_audio
from .wm_world import PhysicalWorld,Recorder,target_goal,achieved,RandomMotor,PrivilegedReference,atomic_npz
from .wm_control import LatentPlanner,BCPolicy
from .utils import atomic_json,derived_seed

@torch.no_grad()
def beliefs(model,ep,arm,device,donor):
    rgb=image_tensor(ep['rgb'],device)
    audio=torch.tensor(choose_audio(ep,arm,donor),device=device,dtype=torch.float32)[:,None]
    body=torch.tensor(ep['proprio'],device=device,dtype=torch.float32)
    actions=torch.tensor(ep['actions'],device=device,dtype=torch.float32)
    h=model.initial(1,device);out=[]
    for t in range(len(rgb)):
        if t:h=model.prior(h,actions[t-1:t])
        h=model.observe(h,rgb[t:t+1],audio[t:t+1],body[t:t+1]);out.append(h[0].cpu().numpy())
    return np.stack(out)

def load_episode(path):
    with np.load(Path(path)/'observations.npz',allow_pickle=False) as z:return {k:z[k] for k in z.files}
def load_truth(path):
    with np.load(Path(path)/'annotations/truth.npz',allow_pickle=False) as z:return {k:z[k] for k in z.files}

def fit_probe(model,paths,arm,device,stride,ridge,destination):
    xs=[];ys=[];masks=[];model.eval()
    for i,path in enumerate(paths):
        ep=load_episode(path);truth=load_truth(path);donor=load_episode(paths[(i+1)%len(paths)])
        h=beliefs(model,ep,arm,device,donor)[::stride];present=truth['present'][::stride]
        y=np.concatenate([truth['state'][::stride].reshape(len(h),72),present,truth['contacts'][::stride]],1)
        mask=np.concatenate([np.repeat(present,18,1),np.ones((len(h),14))],1)
        xs.append(h);ys.append(y);masks.append(mask)
    x=np.concatenate(xs).astype(np.float64);y=np.concatenate(ys).astype(np.float64);mask=np.concatenate(masks)
    mean=x.mean(0);std=x.std(0).clip(.01);x=np.c_[(x-mean)/std,np.ones(len(x))]
    beta=np.zeros((x.shape[1],86));reg=np.eye(x.shape[1])*ridge;reg[-1,-1]=0
    for group in [slice(i*18,(i+1)*18) for i in range(4)]+[slice(72,86)]:
        valid=mask[:,group.start]>.5;xx=x[valid];yy=y[valid,group]
        if len(xx):beta[:,group]=np.linalg.solve(xx.T@xx+reg+np.eye(x.shape[1])*1e-8,xx.T@yy)
    atomic_npz(destination,dict(mean=mean,std=std,beta=beta))

def probe_read(probe,h):return np.r_[(h-probe['mean'])/probe['std'],1]@probe['beta']

def rotation_error(pred,true):
    pred=np.asarray(pred).reshape(-1,3,3);true=np.asarray(true).reshape(-1,3,3)
    u,_,v=np.linalg.svd(pred);r=u@v
    flip=np.linalg.det(r)<0;u[flip,:,-1]*=-1;r=u@v
    cos=((r*true).sum((1,2))-1)/2
    return float(np.rad2deg(np.arccos(np.clip(cos,-1,1))).mean())

def state_metrics(pred,truth,present,contacts):
    state=pred[:72].reshape(4,18);valid=present>.5;s=state[valid];t=truth[valid]
    c=np.clip(pred[76:],0,1);b=c>=.5;actual=contacts>.5
    return dict(position_m=float(np.linalg.norm(s[:,:3]-t[:,:3],axis=1).mean()),
        rotation_deg=rotation_error(s[:,3:12],t[:,3:12]),
        velocity_m_s=float(np.linalg.norm(s[:,12:15]-t[:,12:15],axis=1).mean()),
        angular_rad_s=float(np.linalg.norm(s[:,15:18]-t[:,15:18],axis=1).mean()),
        presence_brier=float(((np.clip(pred[72:76],0,1)-present)**2).mean()),
        contact_brier=float(((c-contacts)**2).mean()),contact_tp=int((b&actual).sum()),
        contact_fp=int((b&~actual).sum()),contact_fn=int((~b&actual).sum()),contact_positives=int(actual.sum()))

@torch.no_grad()
def prediction_episode(model,path,donorpath,arm,probe,p,cfg,device):
    ep=load_episode(path);truth=load_truth(path);donor=load_episode(donorpath)
    hs=beliefs(model,ep,arm,device,donor);start=p['prediction_context']
    # Only the prefix belief is used; posterior future values below are for a
    # separate current-observation probe calibration row, never the rollout.
    h=torch.tensor(hs[start:start+1],device=device);rows=[]
    base=ep['rgb'][start].astype(float)/255;source=truth['state'][start]
    for k in range(1,max(p['prediction_horizons'])+1):
        action=torch.tensor(ep['actions'][start+k-1:start+k],device=device)
        h=model.prior(h,action)
        if k not in p['prediction_horizons']:continue
        t=start+k;rgb,_=model.decode(h);expected=image_tensor(ep['rgb'][t],device)
        # Region masks come solely from the held-out evaluator.
        roi=(truth['masks'][t]>0)|(truth['masks'][start]>0)
        roi=np.repeat(roi[:,None],3,1).reshape(6,64,64);roi_t=torch.tensor(roi,device=device)
        sq=(rgb[0]-expected).square();persist=image_tensor(ep['rgb'][start],device)
        pred=probe_read(probe,h[0].cpu().numpy())
        metrics=state_metrics(pred,truth['state'][t],truth['present'][t],truth['contacts'][t])
        current=state_metrics(probe_read(probe,hs[t]),truth['state'][t],truth['present'][t],truth['contacts'][t])
        valid=truth['present'][t]>.5;dt=k/cfg.control_hz
        cv=source[valid,:3]+source[valid,12:15]*dt
        rows.append(dict(horizon=k,rgb_mse=float(sq.mean()),rgb_object_mse=float(sq[roi_t].mean()) if roi.any() else None,
            persistence_rgb_mse=float((persist-expected).square().mean()),
            persistence_object_mse=float((persist-expected).square()[roi_t].mean()) if roi.any() else None,
            persistence_position_m=float(np.linalg.norm(source[valid,:3]-truth['state'][t,valid,:3],axis=1).mean()),
            constant_velocity_position_m=float(np.linalg.norm(cv-truth['state'][t,valid,:3],axis=1).mean()),
            **metrics,observed_probe_position_m=current['position_m'],observed_probe_rotation_deg=current['rotation_deg']))
    return rows

def physical_panel(spec,p,cfg,speech,model,root,donor=None,should_stop=lambda:None):
    root=Path(root);marker=root/'panel.json'
    if marker.exists():return json.loads(marker.read_text())
    root.mkdir(parents=True,exist_ok=True);episodes=root/'episodes';rows=[]
    for trial in range(spec['trials']):
        should_stop();episode=episodes/f'{trial:04d}';result=episode/'result.json'
        if result.exists():rows.append(json.loads(result.read_text()));continue
        # Shared environment seed excludes model seed, audio arm, planner horizon.
        seed=derived_seed(p['namespace'],'scenes',spec['split'],spec['domain'],spec['task'],trial)
        n=3 if spec['task']=='arrange_3' else 2
        with PhysicalWorld(cfg,speech,seed,spec['domain'],n_objects=n,task=spec['task']) as world:
            goal,truth=target_goal(world,spec['task']);obs=world.observe();rec=Recorder(world,obs)
            rngseed=derived_seed(p['namespace'],'policy',spec['seed'],spec['split'],spec['domain'],spec['task'],trial)
            arm=spec['intervention'] or spec['arm'];started=time.monotonic()
            if spec['kind']=='wm':policy=LatentPlanner(model,cfg,goal,arm,spec['horizon'],rngseed,donor)
            elif spec['kind']=='bc':policy=BCPolicy(model,goal,arm,donor)
            elif spec['kind']=='oracle':policy=PrivilegedReference(world,truth)
            elif spec['kind']=='random':policy=RandomMotor(rngseed)
            else:raise ValueError(spec['kind'])
            successes=[];first=None;distances=[]
            for step in range(cfg.task_steps):
                if step%16==0:should_stop()
                action=policy(obs);obs,wave,ann=world.step(action);rec.add(action,obs,wave,ann)
                ok,distances=achieved(world,truth);successes.append(ok)
                if len(successes)>=3 and all(successes[-3:]) and first is None:first=step+1
            row=dict(trial=trial,scene_seed=seed,success=int(len(successes)>=3 and all(successes[-3:])),
                ever_success=int(first is not None),first_success_step=first,final_distance_m=float(np.mean(distances)),
                seconds=time.monotonic()-started,planned_transitions=getattr(policy,'transitions',0),
                n_objects=len(world.objects),mean_mass_kg=float(np.mean([x['mass'] for x in world.objects])),
                mean_friction=float(np.mean([x['friction'] for x in world.objects])),
                mean_restitution=float(np.mean([x['restitution'] for x in world.objects])),
                mean_size_m=float(np.mean([x['size'] for x in world.objects])),
                motor_delay=world.motor_delay,motor_gain=world.motor_gain,gravity=world.gravity,
                materials='+'.join(sorted(x['material'] for x in world.objects)),
                shapes='+'.join(sorted(x['shape'] for x in world.objects)))
            rec.save(episode,dict(seed=seed,domain=spec['domain'],split=spec['split'],evaluation=True))
            atomic_npz(episode/'goal.npz',goal);atomic_json(episode/'annotations/goal_truth.json',truth)
            atomic_json(result,row);rows.append(row)
    tmp=root/'sensory.zip.tmp'
    with zipfile.ZipFile(tmp,'w',zipfile.ZIP_STORED) as z:
        for f in sorted(episodes.rglob('*')):
            if f.is_file():z.write(f,f.relative_to(episodes).as_posix())
    tmp.replace(root/'sensory.zip');out=dict(complete=True,spec=spec,rows=rows)
    atomic_json(marker,out);shutil.rmtree(episodes)
    return out
