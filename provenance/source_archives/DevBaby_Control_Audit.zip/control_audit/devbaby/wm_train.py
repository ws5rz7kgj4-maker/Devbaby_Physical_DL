"""Fixed-budget optimization and resumable checkpoints, with causal replay."""
from pathlib import Path
from dataclasses import replace
import random
import time
import json
import copy
import numpy as np
import torch
from .wm_model import WorldModel,GoalBC
from .wm_data import Replay
from .wm_plan import model_id
from .utils import seed_all,derived_seed,atomic_json
from .wm_numeric import optimizer_update,NUMERICS_VERSION

def atomic_torch(path,obj):
    path=Path(path);path.parent.mkdir(parents=True,exist_ok=True);tmp=path.with_suffix('.tmp')
    torch.save(obj,tmp);tmp.replace(path)
def rng_state(rng):
    return dict(python=random.getstate(),numpy=np.random.get_state(),torch=torch.get_rng_state(),
        cuda=torch.cuda.get_rng_state_all() if torch.cuda.is_available() else None,sampler=rng.bit_generator.state)
def restore_rng(state,rng):
    random.setstate(state['python']);np.random.set_state(state['numpy']);torch.set_rng_state(state['torch'].cpu())
    if state['cuda'] is not None and torch.cuda.is_available():torch.cuda.set_rng_state_all([s.cpu() for s in state['cuda']])
    rng.bit_generator.state=state['sampler']
def make_model(cfg,seed,kind,device):
    seed_all(derived_seed('wm-initialization',seed,kind))
    return (WorldModel(cfg) if kind=='wm' else GoalBC(cfg)).to(device)
def load_model(path,cfg,device):
    ck=torch.load(path,map_location=device,weights_only=False)
    model=make_model(cfg,ck['seed'],ck['kind'],device);model.load_state_dict(ck['model']);return model.eval()

def train_series(cfg,p,root,seed,arm,kind,paths,checkpoint_callback,check_stop,adapt_age=None,base=None):
    root=Path(root);name=f'{kind}-s{seed}-{arm}'+('' if adapt_age is None else f'-age{adapt_age}-adapt')
    latest=root/'checkpoints'/name/'training.pt'
    model=make_model(cfg,seed,kind,checkpoint_callback.device)
    optimizer=torch.optim.AdamW(model.parameters(),lr=cfg.learning_rate,weight_decay=1e-5)
    scaler=torch.amp.GradScaler('cuda',enabled=cfg.amp and checkpoint_callback.device.type=='cuda')
    rng=np.random.default_rng(derived_seed(p['namespace'],'sampler',seed,kind,adapt_age))
    update=0;trace=[];done=False;pending_rng=None
    adapt=adapt_age is not None
    if adapt:
        target=max(p['adaptation_budgets'])//cfg.episode_steps*p['adaptation_updates_per_episode']
        snapshot_updates={b//cfg.episode_steps*p['adaptation_updates_per_episode']:b for b in p['adaptation_budgets'][1:]}
        if base is None:raise ValueError('Adaptation requires an immutable initial-age checkpoint')
        ck=torch.load(base,map_location=checkpoint_callback.device,weights_only=False);model.load_state_dict(ck['model'])
    else:
        target=cfg.blocks*cfg.updates_per_block
        snapshot_updates={age//(cfg.episodes_per_block*cfg.episode_steps)*cfg.updates_per_block:age for age in p['ages']}
        if kind=='bc':snapshot_updates={target:p['ages'][-1]}
    if latest.exists():
        ck=torch.load(latest,map_location=checkpoint_callback.device,weights_only=False)
        model.load_state_dict(ck['model']);optimizer.load_state_dict(ck['optimizer']);scaler.load_state_dict(ck['scaler'])
        update=ck['update'];trace=ck['trace'];restore_rng(ck['rng'],rng)
    def save():
        payload=dict(model=model.state_dict(),optimizer=optimizer.state_dict(),scaler=scaler.state_dict(),
            rng=pending_rng if pending_rng is not None else rng_state(rng),
            seed=seed,arm=arm,kind=kind,update=update,target=target,trace=trace,config=cfg.asdict(),adapt_age=adapt_age,
            numerics_version=NUMERICS_VERSION)
        atomic_torch(latest,payload)
        if update in snapshot_updates:
            age=snapshot_updates[update]
            identity=model_id(seed,arm,adapt_age if adapt else age,kind,age if adapt else None)
            atomic_torch(root/'checkpoints'/f'{identity}.pt',payload)
    if not latest.exists():save()
    replay=None;available=-1
    try:
        while update<target:
            check_stop()
            if adapt:n=max(2,min(len(paths),(update//p['adaptation_updates_per_episode'])+1))
            else:n=min(len(paths),(update//cfg.updates_per_block+1)*cfg.episodes_per_block)
            # Adaptation starts after 2 episodes; this is why budgets begin at 256.
            if n!=available:replay=Replay(paths[:n],cfg.cache_episodes);available=n
            # The checkpoint retains the RNG before the uncommitted draw. An
            # exception must not silently advance the sampler on restart.
            pending_rng=copy.deepcopy(rng_state(rng))
            batch=replay.sample(cfg,arm,rng,checkpoint_callback.device)
            def retry(event):
                atomic_json(root/'diagnostics'/f'numerics-{name}.json',dict(
                    numerics_version=NUMERICS_VERSION,update=update,sample_ids=batch['sample_ids'],event=event))
                print(f'NUMERIC RETRY {name} update={update} '+json.dumps(event),flush=True)
            result=optimizer_update(model,optimizer,scaler,batch,retry)
            update+=1;pending_rng=None
            trace.append(dict(update=update,available_episodes=n,loss=result['loss'],
                **result['parts'],sample_ids=batch['sample_ids'],
                numerical={k:v for k,v in result.items() if k not in {'loss','parts'}}))
            if update%16==0 or update in snapshot_updates or update==target:
                save();checkpoint_callback(f'train {name} {update}/{target}')
        save();done=True
    finally:
        # A cooperative timeout commits the exact optimizer, RNG and sampler state.
        if not done:save()
    atomic_json(latest.parent/'complete.json',dict(updates=target,seed=seed,arm=arm,kind=kind))
