"""Single source of truth for expected cells, pairing and completeness."""
import hashlib
import json

def key(spec):return hashlib.sha256(json.dumps(spec,sort_keys=True,separators=(',',':')).encode()).hexdigest()[:20]
def model_id(seed,arm,age,kind='wm',adapt=None):
    base=f'{kind}-s{seed}-{arm}-age{age}'
    return base if adapt is None else base+f'-adapt{adapt}'
def models(p):
    last=p['ages'][-1]
    for seed in p['seeds']:
        for arm in p['arms']:
            for age in p['ages']:
                yield dict(id=model_id(seed,arm,age),seed=seed,arm=arm,age=age,kind='wm')
        yield dict(id=model_id(seed,'full',last,'bc'),seed=seed,arm='full',age=last,kind='bc')
        for age in (0,last):
            for budget in p['adaptation_budgets'][1:]:
                yield dict(id=model_id(seed,'full',age,adapt=budget),seed=seed,arm='full',age=age,kind='wm',adapt=budget)
def evaluation_plan(p):
    rows={};last=p['ages'][-1];h=max(p['planning_horizons'])
    def add(seed,arm,age,domain,task,split,n,kind='wm',horizon=h,intervention=None,adapt=None):
        spec=dict(model=model_id(seed,arm,age,kind,adapt),seed=seed,arm=arm,age=age,
            domain=domain,task=task,split=split,trials=n,kind=kind,horizon=horizon,
            intervention=intervention,adapt=adapt)
        rows[key(spec)]=spec
    for seed in p['seeds']:
        for age in p['ages']:
            for d in p['domains']:
                for t in p['tasks']:add(seed,'full',age,d,t,'development',p['development_trials'])
        for d in p['domains']:
            for t in p['tasks']:
                add(seed,'full',last,d,t,'test',p['trials'])
                add(seed,'full',last,d,t,'test',p['trials'],kind='bc')
        for arm in p['arms']:
            for d in p['audio_domains']:
                for t in p['audio_tasks']:
                    add(seed,arm,last,d,t,'test',p['trials'])
        for intervention in ('silent','shuffled'):
            for d in p['audio_domains']:
                for t in p['audio_tasks']:
                    add(seed,'full',last,d,t,'test',p['trials'],intervention=intervention)
        for horizon in p['planning_horizons']:
            for d in p['long_domains']:
                for t in p['long_tasks']:add(seed,'full',last,d,t,'test',p['trials'],horizon=horizon)
        for age in (0,last):
            for budget in p['adaptation_budgets']:
                for t in ('relocate','arrange_2'):
                    add(seed,'full',age,p['adaptation_domain'],t,'adaptation',p['adaptation_trials'],adapt=budget or None)
    # Feasibility and random references share exact scenes, have no learning seeds.
    for kind in ('random','oracle'):
        for d in p['domains']:
            for t in p['tasks']:add(0,'full',last,d,t,'test',p['trials'],kind=kind)
    return rows

def diagnostic_models(p):
    return [m for m in models(p) if m['kind']=='wm' and 'adapt' not in m and (m['arm']=='full' or m['age']==p['ages'][-1])]
def plan_summary(p):
    e=evaluation_plan(p);cfg=p['config'];counts={}
    for s in e.values():counts[s['split']]=counts.get(s['split'],0)+s['trials']
    return dict(development_only=p['development_only'],models=len(list(models(p))),
        training_interactions_per_seed=p['ages'][-1],training_seed_count=len(p['seeds']),
        trainable_audio_arms=len(p['arms']),physical_panels=len(e),physical_episodes=counts,
        maximum_real_evaluation_steps=sum(counts.values())*cfg['task_steps'],
        diagnostic_panels=len(diagnostic_models(p))*len(p['domains']),
        raw_episode_steps=cfg['episode_steps'],hard_job_hours=24,
        note='A full study may need multiple explicitly requested paid jobs. No automatic resubmission. plan counts are not runtime or success forecasts.')
