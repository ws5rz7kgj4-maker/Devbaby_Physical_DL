"""One committed optimizer update; AMP retries never consume another batch.

Policy v1: at most 8 FP16 attempts, then one unscaled FP32 attempt. All
conditions use this same policy. A failed FP32 attempt is an error, not a
discarded example. No optimizer step occurs with nonfinite gradients.
"""
import math
import torch

NUMERICS_VERSION = 'same-batch-amp-recovery-v1'


def clip_finite_gradients(model, max_norm=10.):
    """FP64 reduction also avoids overflow from squaring finite FP32 grads."""
    gradients = [p.grad for p in model.parameters() if p.grad is not None]
    if not gradients:
        raise FloatingPointError('No gradients were produced')
    norm = torch.linalg.vector_norm(torch.stack([
        torch.linalg.vector_norm(g.detach(), dtype=torch.float64) for g in gradients]))
    value = float(norm)
    if math.isfinite(value):
        coefficient = min(1., max_norm / (value + 1e-6))
        for gradient in gradients:
            gradient.mul_(coefficient)
    return value


def optimizer_update(model, optimizer, scaler, batch, on_retry=None, max_amp_attempts=8):
    """Return only after exactly one successful parameter update.

    CPU GradScaler is supported for fault-injection tests; production AMP uses
    CUDA. Restoring RNG before each retry also preserves stochastic layers.
    Current models have no BatchNorm or other mutable forward buffers.
    """
    for name, value in batch.items():
        if torch.is_tensor(value) and not bool(torch.isfinite(value).all()):
            raise FloatingPointError('Non-finite input: '+name)
    device = next(model.parameters()).device
    cpu_rng = torch.get_rng_state()
    cuda_rng = torch.cuda.get_rng_state_all() if device.type == 'cuda' else None
    events = []
    attempts = max_amp_attempts if scaler.is_enabled() else 0
    model.train()
    for attempt in range(attempts + 1):
        use_amp = attempt < attempts
        torch.set_rng_state(cpu_rng)
        if cuda_rng is not None:
            torch.cuda.set_rng_state_all(cuda_rng)
        optimizer.zero_grad(set_to_none=True)
        with torch.autocast(device_type=device.type, dtype=torch.float16, enabled=use_amp):
            loss, parts = model.loss(batch)
        finite_loss = bool(torch.isfinite(loss))
        norm = None
        if finite_loss:
            if use_amp:
                scaler.scale(loss).backward()
                scaler.unscale_(optimizer)
            else:
                loss.backward()
            norm = clip_finite_gradients(model)
            if math.isfinite(norm):
                if use_amp:
                    scaler.step(optimizer)
                    scaler.update()
                else:
                    optimizer.step()
                return dict(loss=float(loss.detach()), parts={k:float(v) for k,v in parts.items()},
                            grad_norm=norm, precision='fp16' if use_amp else 'fp32',
                            attempts=attempt+1, events=events,
                            scale=float(scaler.get_scale()))
        event = dict(attempt=attempt+1, precision='fp16' if use_amp else 'fp32',
                     reason='nonfinite_gradient' if finite_loss else 'nonfinite_loss',
                     scale=float(scaler.get_scale()),
                     parameters=[n for n,p in model.named_parameters()
                                 if p.grad is not None and not bool(torch.isfinite(p.grad).all())][:12])
        if use_amp:
            if finite_loss:
                # unscale_ recorded inf/NaN. step skips the update; update backs
                # off the scale and clears this optimizer's per-step state.
                scaler.step(optimizer)
                scaler.update()
            else:
                # No backward/unscale occurred. Initialize the scaler if needed,
                # then explicitly reduce it without ever applying bad gradients.
                scaler.scale(loss)
                scaler.update(new_scale=scaler.get_scale() * scaler.get_backoff_factor())
            event['next_scale'] = float(scaler.get_scale())
        events.append(event)
        if on_retry is not None:
            on_retry(event)
        optimizer.zero_grad(set_to_none=True)
        if not use_amp:
            raise FloatingPointError('FP32 retry also failed: '+event['reason'])
    raise AssertionError('Unreachable numerical recovery state')
