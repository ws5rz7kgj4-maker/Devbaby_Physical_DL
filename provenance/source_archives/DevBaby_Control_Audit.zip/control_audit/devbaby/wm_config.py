"""Explicit operational definitions, shared by plan/train/evaluate."""
from dataclasses import dataclass, asdict
import json
from pathlib import Path

ARMS = ('full','silent','impact_only','speech_only','shuffled')
DOMAINS = ('iid','new_physics','new_layout','occluded','material_shift')
TASKS = ('relocate','lift','stack_2','arrange_2','arrange_3')

@dataclass
class WMConfig:
    seed: int = 0
    hidden: int = 192
    audio_dim: int = 48
    batch_size: int = 8
    burn_in: int = 8
    train_steps: int = 16
    unroll: int = 32
    episode_steps: int = 128
    learning_rate: float = 0.0003
    updates_per_block: int = 256
    episodes_per_block: int = 32
    blocks: int = 16
    cache_episodes: int = 128
    threads: int = 4
    control_hz: int = 8
    physics_hz: int = 120
    sample_rate: int = 16000
    action_repeat: int = 4
    planning_budget: int = 2048
    planning_iterations: int = 3
    task_steps: int = 128
    amp: bool = True
    def validate(self):
        assert self.episode_steps >= self.burn_in + max(self.train_steps,self.unroll) + 1
        assert self.burn_in >= 1 and self.batch_size >= 2
        assert self.hidden >= 8 and self.action_repeat >= 1
        assert self.physics_hz % self.control_hz == 0 and self.sample_rate % self.control_hz == 0
        assert min(self.blocks,self.updates_per_block,self.episodes_per_block) >= 1
        return self
    def asdict(self): return asdict(self)

def load_protocol(path):
    p=json.loads(Path(path).read_text());cfg=WMConfig(**p['config']).validate()
    assert p['version']=='DevBaby-worldmodel-v2'
    assert p['seeds'] and len(set(p['seeds']))==len(p['seeds'])
    assert set(p['arms'])<=set(ARMS) and 'full' in p['arms']
    assert p['ages']==sorted(set(p['ages'])) and p['ages'][0]==0
    assert p['ages'][-1]==cfg.blocks*cfg.episodes_per_block*cfg.episode_steps
    assert all(a%(cfg.episodes_per_block*cfg.episode_steps)==0 for a in p['ages'])
    assert max(p['prediction_horizons'])<cfg.episode_steps-p['prediction_context']
    assert len(set(p['planning_horizons']))==len(p['planning_horizons'])
    assert all(cfg.planning_budget//h>=4 for h in p['planning_horizons'])
    assert p['namespace'] and p['job_seconds']<=82800
    assert p['adaptation_budgets']==sorted(set(p['adaptation_budgets']))
    assert all(b%cfg.episode_steps==0 for b in p['adaptation_budgets'])
    if not p['development_only']:
        assert p['seeds']==list(range(8)) and tuple(p['arms'])==ARMS
        assert cfg.task_steps>=128 and max(p['prediction_horizons'])>=64
        assert p['trials']>=24
    return p,cfg
