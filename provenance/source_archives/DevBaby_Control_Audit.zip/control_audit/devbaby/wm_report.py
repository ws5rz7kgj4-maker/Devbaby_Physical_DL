"""Completeness-gated reporting. Seeds and scenes are crossed sampling units."""
from pathlib import Path
import csv
import html
import itertools
import json
import numpy as np
from .wm_plan import evaluation_plan,diagnostic_models,key
from .utils import atomic_json,derived_seed

def write_csv(path,rows):
    columns=list(dict.fromkeys(k for row in rows for k in row))
    with Path(path).open('w',newline='') as f:
        w=csv.DictWriter(f,columns);w.writeheader();w.writerows(rows)

def paired_inference(delta,draws,rng):
    """[training seed, fixed domain/task stratum, independently sampled scene]."""
    delta=np.asarray(delta,float);n,s,t=delta.shape;boot=[]
    for _ in range(draws):
        sample=delta[rng.integers(n,size=n)]
        boot.append(np.mean([sample[:,j,rng.integers(t,size=t)].mean() for j in range(s)]))
    seedmeans=delta.mean((1,2));observed=abs(seedmeans.mean())
    if n<=16:
        null=np.array([abs(np.mean(seedmeans*np.array(sign))) for sign in itertools.product((-1,1),repeat=n)])
        p=float(np.mean(null>=observed-1e-12))
    else:
        null=np.abs((rng.choice([-1,1],(10000,n))*seedmeans).mean(1));p=float((1+(null>=observed).sum())/(len(null)+1))
    lo,hi=np.quantile(boot,[.025,.975])
    return dict(effect=float(delta.mean()),ci_low=float(lo),ci_high=float(hi),p=p,seeds=n,strata=s,scenes_per_stratum=t)

def holm(ps):
    order=np.argsort(ps);out=np.ones(len(ps));last=0
    for rank,index in enumerate(order):last=max(last,min(1,ps[index]*(len(ps)-rank)));out[index]=last
    return out

def report(root):
    root=Path(root);p=json.loads((root/'protocol.lock.json').read_text());plan=evaluation_plan(p)
    panels={};flat=[];diagnostics=[]
    for ident,spec in plan.items():
        path=root/'physical_panels'/ident/'panel.json'
        if path.exists():
            panel=json.loads(path.read_text())
            if panel.get('complete') is not True or panel['spec']!=spec or len(panel['rows'])!=spec['trials']:
                raise ValueError('Malformed evaluation panel '+ident)
            if sorted(r['trial'] for r in panel['rows'])!=list(range(spec['trials'])):raise ValueError('Duplicate/missing scene IDs')
            panels[ident]=panel
            flat.extend([{**spec,**r} for r in panel['rows']])
    for file in sorted((root/'diagnostics').glob('*.json')) if (root/'diagnostics').exists() else []:
        data=json.loads(file.read_text())
        if data.get('complete'):diagnostics.extend(data['rows'])
    curves=[]
    for ident,panel in panels.items():
        spec=panel['spec'];r=panel['rows']
        curves.append(dict(**spec,success_rate=float(np.mean([x['success'] for x in r])),
            ever_success_rate=float(np.mean([x['ever_success'] for x in r])),mean_final_distance_m=float(np.mean([x['final_distance_m'] for x in r])),
            seconds=float(np.sum([x['seconds'] for x in r])),planned_transitions=int(np.sum([x['planned_transitions'] for x in r]))))
    write_csv(root/'trial_results.csv',flat);write_csv(root/'curves.csv',curves);write_csv(root/'predictions.csv',diagnostics)
    # Exploratory property slices retain counts and model seed; no extra primary
    # p-values are generated from inspecting many attribute combinations.
    properties=[]
    for field in ('materials','shapes','motor_delay'):
        groups={}
        for row in flat:
            if row['kind']!='wm' or row['arm']!='full' or row['intervention'] is not None or row['split']!='development':continue
            if field not in row:continue
            g=(row['seed'],row['age'],row['domain'],row['task'],str(row[field]))
            groups.setdefault(g,[]).append(row['success'])
        for (seed,age,domain,task,value),scores in groups.items():
            properties.append(dict(attribute=field,value=value,seed=seed,age=age,domain=domain,task=task,
                scenes=len(scores),success_rate=float(np.mean(scores))))
    write_csv(root/'property_slices.csv',properties)
    def select(**filters):return [r for r in curves if all(r.get(k)==v for k,v in filters.items())]
    growth=[]
    for seed in p['seeds']:
        for d in p['domains']:
            for t in p['tasks']:
                rows=select(seed=seed,domain=d,task=t,split='development');byage={r['age']:r for r in rows}
                for a,b in zip(p['ages'][:-1],p['ages'][1:]):
                    if a in byage and b in byage:
                        delta=byage[b]['success_rate']-byage[a]['success_rate']
                        growth.append(dict(seed=seed,domain=d,task=t,start_interactions=a,end_interactions=b,
                            start_success=byage[a]['success_rate'],end_success=byage[b]['success_rate'],
                            success_gain=delta,gain_per_1000_interactions=delta/(b-a)*1000))
    write_csv(root/'learning_speed.csv',growth)
    adaptation=[]
    for seed in p['seeds']:
        for age in (0,p['ages'][-1]):
            for task in ('relocate','arrange_2'):
                rows=select(seed=seed,age=age,task=task,split='adaptation');bybudget={r['adapt'] or 0:r for r in rows}
                for a,b in zip(p['adaptation_budgets'][:-1],p['adaptation_budgets'][1:]):
                    if a in bybudget and b in bybudget:
                        adaptation.append(dict(seed=seed,pretraining_interactions=age,task=task,budget_start=a,budget_end=b,
                            gain_per_1000_new_interactions=(bybudget[b]['success_rate']-bybudget[a]['success_rate'])*1000/(b-a)))
    write_csv(root/'adaptation_speed.csv',adaptation)
    from .wm_curves import curve_summaries
    curve_summaries(root,p,panels)
    contrasts=[];missing=[];last=p['ages'][-1];h=max(p['planning_horizons']);rng=np.random.default_rng(derived_seed(p['namespace'],'bootstrap'))
    def tensor(domains,tasks,**filters):
        result=[]
        for seed in p['seeds']:
            strata=[]
            for d,t in itertools.product(domains,tasks):
                matches=[v for v in panels.values() if all(v['spec'].get(k)==val for k,val in dict(seed=seed,age=last,domain=d,task=t,split='test',adapt=None,**filters).items())]
                if len(matches)!=1:raise LookupError(f'Missing/nonunique primary cell {seed}/{d}/{t}/{filters}')
                strata.append([r['success'] for r in sorted(matches[0]['rows'],key=lambda x:x['trial'])])
            result.append(strata)
        return np.asarray(result)
    for name in p['primary_family']:
        try:
            if name.startswith('full_minus_'):
                arm=name[len('full_minus_'):]
                a=tensor(p['audio_domains'],p['audio_tasks'],arm='full',kind='wm',horizon=h,intervention=None)
                b=tensor(p['audio_domains'],p['audio_tasks'],arm=arm,kind='wm',horizon=h,intervention=None)
            elif name=='horizon64_minus_horizon8':
                a=tensor(p['long_domains'],p['long_tasks'],arm='full',kind='wm',horizon=max(p['planning_horizons']),intervention=None)
                b=tensor(p['long_domains'],p['long_tasks'],arm='full',kind='wm',horizon=min(p['planning_horizons']),intervention=None)
            elif name=='worldmodel_minus_gcbc':
                a=tensor(p['bc_domains'],p['bc_tasks'],arm='full',kind='wm',horizon=h,intervention=None)
                b=tensor(p['bc_domains'],p['bc_tasks'],arm='full',kind='bc',horizon=h,intervention=None)
            else:raise ValueError(name)
            contrasts.append(dict(contrast=name,**paired_inference(a-b,p['bootstrap_draws'],rng)))
        except LookupError as e:missing.append(str(e))
    primary_complete=len(contrasts)==len(p['primary_family']) and not p['development_only']
    if primary_complete:
        for row,q in zip(contrasts,holm([r['p'] for r in contrasts])):row['p_holm']=float(q)
    else:
        # Partial families never quietly reduce the multiple-comparison penalty.
        for row in contrasts:row['p_holm']=None;row['inference_withheld']=True
    write_csv(root/'contrasts.csv',contrasts)
    expected_diagnostics=len(diagnostic_models(p))*len(p['domains'])*p['prediction_episodes']*len(p['prediction_horizons'])
    complete=len(panels)==len(plan) and len(diagnostics)==expected_diagnostics
    summary=dict(development_only=p['development_only'],all_evaluations_complete=complete,
        physical_panels_completed=len(panels),physical_panels_expected=len(plan),
        diagnostic_rows=len(diagnostics),diagnostic_rows_expected=expected_diagnostics,
        primary_family_complete=primary_complete,primary_missing=missing,
        interpretation='Physical success is the outcome. Prediction and frozen label probes are diagnostic, not proof of understanding or consciousness.',
        limits='One simulator and a built-in grasp primitive. Novel combinations use known objects. Probe supervision is isolated from learner/controller.')
    atomic_json(root/'summary.json',summary)
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    fig,axes=plt.subplots(1,2,figsize=(12,4))
    for domain in p['domains']:
        vals=[]
        for age in p['ages']:
            rows=select(domain=domain,age=age,split='development')
            vals.append(np.mean([r['success_rate'] for r in rows]) if rows else np.nan)
        axes[0].plot(p['ages'],vals,marker='o',label=domain)
    axes[0].set(xlabel='Random physical interactions',ylabel='Final physical success rate',ylim=(-.02,1.02));axes[0].legend(fontsize=8)
    for age in (0,last):
        vals=[]
        for b in p['adaptation_budgets']:
            rows=select(age=age,split='adaptation',adapt=b or None)
            vals.append(np.mean([r['success_rate'] for r in rows]) if rows else np.nan)
        axes[1].plot(p['adaptation_budgets'],vals,marker='o',label=f'Pretraining {age}')
    axes[1].set(xlabel='New-domain random interactions',ylabel='Adaptation physical success',ylim=(-.02,1.02));axes[1].legend()
    fig.tight_layout();fig.savefig(root/'physical_learning.png',dpi=160);plt.close(fig)
    table=''.join('<tr>'+''.join('<td>'+html.escape(str(row.get(k,'')))+'</td>' for k in ('contrast','effect','ci_low','ci_high','p_holm'))+'</tr>' for row in contrasts)
    text='''<!doctype html><meta charset="utf-8"><title>DevBaby World Model</title><style>body{font:16px system-ui;max-width:1100px;margin:40px auto;padding:0 20px}td,th{padding:10px;border:1px solid #ddd}img{max-width:100%}pre{white-space:pre-wrap}</style>'''
    text+='<h1>DevBaby 世界模型实验</h1><p>结果只在固定模拟器、身体和任务定义内解释。零成功率也是有效结果；预测改善不代表能规划成功。</p>'
    text+='<p>开发测试：'+str(p['development_only'])+'；完整评测：'+str(complete)+'；完整正式主检验：'+str(primary_complete)+'</p>'
    text+='<img src="physical_learning.png"><p>图为描述性平均；种子级原始数据、增长速度和配对统计见 CSV。未完成的数据不作正式结论。</p>'
    text+='<table><tr><th>Comparison</th><th>Difference</th><th>CI low</th><th>CI high</th><th>Holm p</th></tr>'+table+'</table>'
    text+='<pre>'+html.escape(json.dumps(summary,ensure_ascii=False,indent=2))+'</pre>'
    (root/'report.html').write_text(text,encoding='utf-8')
    return summary
