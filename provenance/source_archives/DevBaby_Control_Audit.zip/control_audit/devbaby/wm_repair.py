"""Narrow, auditable data-only migration from the known failed experiment.

No training checkpoint or evaluation result is imported. The formal protocol
and simulator stay unchanged; the new code receives its own run identity.
"""
import hashlib
import json
from pathlib import Path, PurePosixPath

SOURCE_RUN = 'worldmodel-fd0f484f6879'
SOURCE_JOB = '6adc0292046eb82b1ecd8fed'
SOURCE_CODE = 'b00d6b49b030ad3d87a6ff3942ab7d241235cde8071bebffd2ab6e7ea65da64c'
SOURCE_PROTOCOL = 'aab6cbe8e4957908aee1323da0a5424c486042fc885382d9291e13a8cab72946'
EPISODE_FILES = {'observations.npz', 'audio.wav', 'complete.json',
                 'annotations/truth.npz', 'annotations/scene.json', 'annotations/frames.jsonl'}


def fingerprint(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(',', ':')).encode()).hexdigest()


def selected_files(index):
    files = index['files']
    for name in files:
        path = PurePosixPath(name)
        if path.is_absolute() or '..' in path.parts or '\\' in name or not name:
            raise ValueError('Unsafe source file index')
    selected = set()
    for episode in range(512):
        prefix = f'data/train/s0/{episode:06d}/'
        for suffix in EPISODE_FILES:
            name = prefix + suffix
            if name not in files:
                raise ValueError('Source experience is incomplete: '+name)
            selected.add(name)
    selected.update(n for n in files if n.startswith('speech/') and n.endswith('.wav'))
    return sorted(selected)


def validate_source(index, identity, state, repo, run_id, protocol_sha):
    if run_id != SOURCE_RUN or index.get('repo') != repo or index.get('run_id') != run_id:
        raise ValueError('Unexpected repair source')
    if protocol_sha != SOURCE_PROTOCOL or identity != dict(code_sha256=SOURCE_CODE, protocol_sha256=SOURCE_PROTOCOL):
        raise ValueError('Repair source code/protocol mismatch')
    if state.get('status') != 'error' or state.get('phase') != 'training':
        raise ValueError('Repair is restricted to the failed training run')
    if 'fit_seal.json' in index['files'] or any(n.startswith('physical_panels/') for n in index['files']):
        raise ValueError('Source has reached evaluation; this repair must precede evaluation')
    selected_files(index)


def restore_experience(manifest, out, cache=None):
    """Read only a pinned completed publication, then verify each raw file."""
    spec = manifest.get('data_import')
    if not spec:
        return
    out = Path(out)
    provenance_file = out/'repair_provenance.json'
    if provenance_file.exists():
        previous = json.loads(provenance_file.read_text())
        if any(previous.get(k) != v for k,v in spec.items()):
            raise ValueError('Restored data provenance does not match launch manifest')
        return
    if (out/'checkpoints').exists():
        raise ValueError('Checkpoints exist without data provenance; refusing an ambiguous import')
    from huggingface_hub import hf_hub_download, snapshot_download
    repo, revision, run_id = spec['repo'], spec['revision'], spec['run_id']
    prefix = 'runs/'+run_id+'/'
    def read(name):
        return json.loads(Path(hf_hub_download(repo, prefix+name, repo_type='dataset', revision=revision)).read_text())
    index = read('.wm_sync_index.json')
    validate_source(index, read('identity.json'), read('state.json'), repo, run_id, manifest['protocol_sha256'])
    if fingerprint(index) != spec['index_fingerprint']:
        raise ValueError('Source index changed')
    names = selected_files(index)
    cache = Path(cache or '/tmp/devbaby-wm-raw-import')
    snapshot_download(repo, repo_type='dataset', revision=revision,
                      allow_patterns=[prefix+n for n in names], local_dir=cache, max_workers=4)
    out = Path(out); out.mkdir(parents=True, exist_ok=True)
    # Verify the entire import before installing any complete episode marker.
    for name in names:
        source = cache/prefix/name
        meta = index['files'][name]
        if not source.is_file() or source.is_symlink() or source.stat().st_size != meta['bytes']:
            raise ValueError('Raw import size/type mismatch: '+name)
        h = hashlib.sha256()
        with source.open('rb') as f:
            for block in iter(lambda:f.read(1<<20), b''):
                h.update(block)
        if h.hexdigest() != meta['sha256']:
            raise ValueError('Raw import checksum mismatch: '+name)
    for name in sorted(names, key=lambda n:(n.endswith('/complete.json'), n)):
        destination = out/name
        destination.parent.mkdir(parents=True, exist_ok=True)
        (cache/prefix/name).replace(destination)
    provenance = dict(**spec, imported_files=len(names), imported_episodes=512,
                      imported_transitions=65536, weights_imported=False,
                      optimizer_imported=False, evaluation_imported=False)
    (out/'repair_provenance.json').write_text(json.dumps(provenance, indent=2))
    print('REPAIR: verified and reused 512 episodes / 65536 transitions; random initialization retained.', flush=True)
