"""Action-conditioned recurrent world model, initialized entirely at random.

Physical labels are deliberately absent. Only image and proprioceptive losses
train the model. Future prediction calls prior(), never observe().
"""
import torch
from torch import nn
import torch.nn.functional as F

class ImageEncoder(nn.Module):
    def __init__(self,hidden):
        super().__init__();self.net=nn.Sequential(nn.Conv2d(6,24,4,2,1),nn.SiLU(),
            nn.Conv2d(24,48,4,2,1),nn.SiLU(),nn.Conv2d(48,64,4,2,1),nn.SiLU(),
            nn.Conv2d(64,96,4,2,1),nn.SiLU(),nn.Flatten(),nn.Linear(96*4*4,hidden),nn.LayerNorm(hidden))
    def forward(self,x):return self.net(x)

class ObservationEncoder(nn.Module):
    def __init__(self,cfg):
        super().__init__();self.image=ImageEncoder(cfg.hidden)
        self.audio=nn.Sequential(nn.Conv2d(1,12,3,2,1),nn.SiLU(),nn.Conv2d(12,24,3,2,1),nn.SiLU(),nn.Flatten(),nn.Linear(24*8*4,cfg.audio_dim),nn.Tanh())
        self.fuse=nn.Sequential(nn.Linear(cfg.hidden+cfg.audio_dim+10,cfg.hidden),nn.LayerNorm(cfg.hidden),nn.SiLU())
    def forward(self,rgb,audio,proprio):return self.fuse(torch.cat([self.image(rgb),self.audio(audio),proprio],-1))

class WorldModel(nn.Module):
    def __init__(self,cfg):
        super().__init__();self.cfg=cfg;self.encoder=ObservationEncoder(cfg)
        self.dynamics=nn.GRUCell(5,cfg.hidden);self.filter=nn.GRUCell(cfg.hidden,cfg.hidden)
        self.image_start=nn.Linear(cfg.hidden,96*4*4)
        self.image_decoder=nn.Sequential(nn.ConvTranspose2d(96,64,4,2,1),nn.SiLU(),
            nn.ConvTranspose2d(64,48,4,2,1),nn.SiLU(),nn.ConvTranspose2d(48,24,4,2,1),nn.SiLU(),
            nn.ConvTranspose2d(24,6,4,2,1),nn.Sigmoid())
        self.body_decoder=nn.Sequential(nn.Linear(cfg.hidden,cfg.hidden),nn.SiLU(),nn.Linear(cfg.hidden,10))
    def initial(self,batch,device):return torch.zeros(batch,self.cfg.hidden,device=device)
    def prior(self,h,action):return self.dynamics(action,h)
    def observe(self,h,rgb,audio,proprio):return self.filter(self.encoder(rgb,audio,proprio),h)
    def decode(self,h):return self.image_decoder(self.image_start(h).reshape(-1,96,4,4)),self.body_decoder(h)
    def forward(self,b):
        B,T=b['rgb'].shape[:2];h=self.initial(B,b['rgb'].device);states=[]
        for t in range(T):
            if t:h=self.prior(h,b['actions'][:,t-1])
            h=self.observe(h,b['rgb'][:,t],b['audio'][:,t],b['proprio'][:,t]);states.append(h)
        return torch.stack(states,1)
    def loss(self,b):
        cfg=self.cfg;B,T=b['rgb'].shape[:2];h=self.initial(B,b['rgb'].device)
        # Burn-in reconstructs belief using only past observations, without backprop.
        with torch.no_grad():
            for t in range(cfg.burn_in):
                if t:h=self.prior(h,b['actions'][:,t-1])
                h=self.observe(h,b['rgb'][:,t],b['audio'][:,t],b['proprio'][:,t])
        anchor=None;rec=[];one=[];latent=[]
        for t in range(cfg.burn_in,cfg.burn_in+cfg.train_steps):
            h=self.prior(h,b['actions'][:,t-1]);prior=h
            h=self.observe(h,b['rgb'][:,t],b['audio'][:,t],b['proprio'][:,t]);latent.append(h)
            if anchor is None:anchor=h
            rgb,body=self.decode(h)
            rec.append(F.mse_loss(rgb,b['rgb'][:,t])+F.mse_loss(body,b['proprio'][:,t]))
            rgb,body=self.decode(prior)
            motion=1+10*(b['rgb'][:,t]-b['rgb'][:,t-1]).abs().mean(1,keepdim=True)
            one.append(((rgb-b['rgb'][:,t]).square()*motion).mean()+F.mse_loss(body,b['proprio'][:,t]))
        # Open-loop multistep prediction, at geometrically spaced horizons.
        h=anchor;multi=[];start=cfg.burn_in
        horizons=set([1,2,4,8,16,32,cfg.unroll])
        for k in range(1,cfg.unroll+1):
            h=self.prior(h,b['actions'][:,start+k-1])
            if k in horizons:
                rgb,body=self.decode(h);target=b['rgb'][:,start+k]
                motion=1+10*(target-b['rgb'][:,start]).abs().mean(1,keepdim=True)
                multi.append(((rgb-target).square()*motion).mean()+F.mse_loss(body,b['proprio'][:,start+k]))
        r=torch.stack(rec).mean();o=torch.stack(one).mean();m=torch.stack(multi).mean()
        # Small anti-collapse penalty on the randomly initialized latent representation.
        spread=F.relu(.1-torch.stack(latent,1).flatten(0,1).std(0,unbiased=False)).mean()
        return r+o+m+.01*spread,dict(reconstruction=r.detach(),one_step=o.detach(),multi_step=m.detach())

class GoalBC(nn.Module):
    """Hindsight goal-conditioned behavior cloning, not an oracle demonstration."""
    def __init__(self,cfg):
        super().__init__();self.cfg=cfg;self.encoder=ObservationEncoder(cfg)
        self.goal=ImageEncoder(cfg.hidden);self.memory=nn.GRUCell(cfg.hidden+5,cfg.hidden)
        self.head=nn.Sequential(nn.Linear(2*cfg.hidden,cfg.hidden),nn.SiLU(),nn.Linear(cfg.hidden,5),nn.Tanh())
    def initial(self,batch,device):return torch.zeros(batch,self.cfg.hidden,device=device)
    def step(self,h,obs,previous,goal):
        x=self.encoder(obs['rgb'],obs['audio'],obs['proprio'])
        h=self.memory(torch.cat([x,previous],-1),h)
        return self.head(torch.cat([h,self.goal(goal)],-1)),h
    def loss(self,b):
        h=self.initial(b['rgb'].shape[0],b['rgb'].device);zero=torch.zeros_like(b['actions'][:,0])
        for t in range(self.cfg.burn_in+1):
            obs={k:b[k][:,t] for k in ('rgb','audio','proprio')}
            action,h=self.step(h,obs,b['actions'][:,t-1] if t else zero,b['goal'])
        loss=F.mse_loss(action,b['actions'][:,self.cfg.burn_in])
        return loss,dict(behavior_cloning=loss.detach())
