"""Strict learner data boundary. No annotation file is opened by this module."""
from collections import OrderedDict
from pathlib import Path
import numpy as np
import torch

KEYS={'rgb','audio','impact_audio','speech_audio','proprio','actions'}

def image_tensor(x,device='cpu'):
    x=np.asarray(x)
    # (..., view, height, width, channel) -> (..., view*channel, height, width)
    axes=list(range(x.ndim-4))+[x.ndim-4,x.ndim-1,x.ndim-3,x.ndim-2]
    x=x.transpose(axes)
    return torch.as_tensor(x.reshape(*x.shape[:-4],6,64,64).copy(),device=device,dtype=torch.float32)/255

def choose_audio(obs,arm,donor=None):
    if arm=='full':return obs['audio']
    if arm=='silent':return np.zeros_like(obs['audio'])
    if arm=='impact_only':return obs['impact_audio']
    if arm=='speech_only':return obs['speech_audio']
    if arm=='shuffled':
        if donor is None:raise ValueError('Shuffled audio requires an independent episode')
        return donor['audio']
    raise ValueError(arm)

def observation_tensor(obs,arm,device,donor=None):
    return dict(rgb=image_tensor(obs['rgb'],device).unsqueeze(0),
                audio=torch.as_tensor(choose_audio(obs,arm,donor),dtype=torch.float32,device=device)[None,None],
                proprio=torch.as_tensor(obs['proprio'],dtype=torch.float32,device=device)[None])

class Replay:
    def __init__(self,paths,capacity=8):
        self.paths=list(map(Path,paths));self.capacity=capacity;self.cache=OrderedDict()
        if len(self.paths)<2:raise ValueError('Need two independent episodes for audio donor control')
    def get(self,index):
        path=self.paths[index]
        if path not in self.cache:
            with np.load(path/'observations.npz',allow_pickle=False) as z:
                if set(z.files)!=KEYS:raise ValueError('Unexpected learner input keys')
                self.cache[path]={k:z[k] for k in z.files}
            while len(self.cache)>self.capacity:self.cache.popitem(last=False)
        self.cache.move_to_end(path)
        return self.cache[path]
    def sample(self,cfg,arm,rng,device):
        length=cfg.burn_in+max(cfg.train_steps,cfg.unroll)+1
        rows=[];goals=[];ids=[]
        for _ in range(cfg.batch_size):
            i=int(rng.integers(len(self.paths)));ep=self.get(i)
            start=int(rng.integers(len(ep['rgb'])-length+1))
            j=(i+int(rng.integers(1,len(self.paths))))%len(self.paths)
            donor=self.get(j);dstart=int(rng.integers(len(donor['rgb'])-length+1))
            audio=choose_audio(ep,arm,donor)
            # Donor is an independent observed training episode, never a future slice
            # of the same episode. Draws are identical in all arms.
            astart=dstart if arm=='shuffled' else start
            rows.append(dict(rgb=ep['rgb'][start:start+length],
                audio=audio[astart:astart+length],proprio=ep['proprio'][start:start+length],
                actions=ep['actions'][start:start+length-1]))
            g=int(rng.integers(start+cfg.burn_in+1,len(ep['rgb'])))
            goals.append(ep['rgb'][g]);ids.append((i,start,j,dstart,g))
        batch={k:np.stack([r[k] for r in rows]) for k in rows[0]}
        out={k:torch.as_tensor(v,device=device,dtype=torch.float32) for k,v in batch.items() if k!='rgb'}
        out['rgb']=image_tensor(batch['rgb'],device);out['audio']=out['audio'].unsqueeze(2)
        out['goal']=image_tensor(np.stack(goals),device);out['sample_ids']=ids
        return out
