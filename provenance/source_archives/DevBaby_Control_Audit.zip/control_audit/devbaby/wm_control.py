"""Policies accept public observations and goal pixels only, never simulator state."""
import math
import numpy as np
import torch
from .wm_data import image_tensor,observation_tensor

class LatentPlanner:
    def __init__(self,model,cfg,goal,arm,horizon,seed,donor=None):
        self.model=model.eval();self.cfg=cfg;self.arm=arm;self.horizon=horizon
        self.device=next(model.parameters()).device;self.h=model.initial(1,self.device)
        self.previous=None;self.queue=[];self.tick=0;self.donor=donor
        self.generator=torch.Generator(device=self.device).manual_seed(seed)
        self.goal=image_tensor(goal['rgb'],self.device)
        weights=np.repeat(goal['weights'][:,None],3,axis=1).reshape(6,64,64)
        self.weights=torch.tensor(weights,device=self.device)
        self.chunks=math.ceil(horizon/cfg.action_repeat);self.mean=torch.zeros(self.chunks,5,device=self.device)
        self.transitions=0
    @torch.no_grad()
    def __call__(self,obs):
        donor=None if self.donor is None else {'audio':self.donor[min(self.tick,len(self.donor)-1)]}
        x=observation_tensor(obs,self.arm,self.device,donor)
        if self.previous is not None:self.h=self.model.prior(self.h,self.previous[None])
        self.h=self.model.observe(self.h,**x);self.tick+=1
        if not self.queue:self.plan()
        self.previous=self.queue.pop(0)
        return self.previous.cpu().numpy()
    @torch.no_grad()
    def plan(self):
        cfg=self.cfg;n=max(4,cfg.planning_budget//self.horizon);elites=max(2,n//8)
        mean=self.mean;std=torch.ones_like(mean)*.7
        for iteration in range(cfg.planning_iterations):
            seq=(mean+std*torch.randn(n,self.chunks,5,device=self.device,generator=self.generator)).clamp(-1,1)
            seq[0]=mean;h=self.h.expand(n,-1).contiguous()
            for step in range(self.horizon):h=self.model.prior(h,seq[:,step//cfg.action_repeat])
            self.transitions+=n*self.horizon
            rgb,_=self.model.decode(h)
            cost=((rgb-self.goal).square()*self.weights).mean((1,2,3))
            cost+=.0001*seq[:,:,:3].square().mean((1,2))
            chosen=seq[torch.topk(cost,elites,largest=False).indices]
            mean=chosen.mean(0);std=chosen.std(0,unbiased=False).clamp_min(.08)
        self.queue=[mean[0].clone() for _ in range(cfg.action_repeat)]
        self.mean=torch.cat([mean[1:],torch.zeros(1,5,device=self.device)])

class BCPolicy:
    def __init__(self,model,goal,arm='full',donor=None):
        self.model=model.eval();self.device=next(model.parameters()).device
        self.goal=image_tensor(goal['rgb'],self.device)[None];self.arm=arm;self.donor=donor
        self.h=model.initial(1,self.device);self.previous=torch.zeros(1,5,device=self.device);self.tick=0
        self.transitions=0
    @torch.no_grad()
    def __call__(self,obs):
        donor=None if self.donor is None else {'audio':self.donor[min(self.tick,len(self.donor)-1)]}
        x=observation_tensor(obs,self.arm,self.device,donor)
        self.previous,self.h=self.model.step(self.h,x,self.previous,self.goal);self.tick+=1
        return self.previous[0].cpu().numpy()
