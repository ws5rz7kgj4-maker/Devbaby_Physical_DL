"""Descriptive crossed-bootstrap curves and learning-speed estimates."""
import itertools
import numpy as np
from .wm_report import paired_inference,write_csv
from .utils import derived_seed

def curve_summaries(root,p,panels):
    rng=np.random.default_rng(derived_seed(p['namespace'],'curve-bootstrap'));draws=p['bootstrap_draws']
    rows=[];speed=[];efficiency=[]
    def values(split,domain,task,age,adapt=None):
        result=[]
        for seed in p['seeds']:
            found=[v for v in panels.values() if all(v['spec'].get(k)==value for k,value in dict(
                split=split,domain=domain,task=task,age=age,seed=seed,adapt=adapt,kind='wm',arm='full',intervention=None,
                horizon=max(p['planning_horizons'])).items())]
            if len(found)!=1:return None
            result.append([r['success'] for r in sorted(found[0]['rows'],key=lambda r:r['trial'])])
        return np.asarray(result,dtype=float)[:,None,:]
    for domain,task in itertools.product(p['domains'],p['tasks']):
        collected=[]
        for age in p['ages']:
            x=values('development',domain,task,age)
            if x is None:continue
            stats=paired_inference(x,draws,rng);stats.pop('p')
            rows.append(dict(split='development',domain=domain,task=task,age=age,budget=0,**stats));collected.append((age,x))
        for (a,x),(b,y) in zip(collected,collected[1:]):
            if p['ages'].index(b)-p['ages'].index(a)!=1:continue
            stats=paired_inference((y-x)*1000/(b-a),draws,rng);stats.pop('p')
            speed.append(dict(split='development',domain=domain,task=task,start=a,end=b,unit='success_gain_per_1000_interactions',**stats))
        if len(collected)==len(p['ages']):
            allx=np.stack([x[:,0,:] for a,x in collected],axis=1)
            # AUC is normalized to [0,1], integrating success over interaction count.
            auc=np.trapz(allx,p['ages'],axis=1)/(p['ages'][-1]-p['ages'][0])
            stats=paired_inference(auc[:,None,:],draws,rng);stats.pop('p')
            efficiency.append(dict(domain=domain,task=task,metric='normalized_learning_auc',**stats))
            for i,seed in enumerate(p['seeds']):
                means=allx[i].mean(1);hit=next((a for a,v in zip(p['ages'],means) if v>=.5),None)
                efficiency.append(dict(domain=domain,task=task,metric='first_observed_50pct',seed=seed,interactions=hit,right_censored=hit is None))
    for age,task in itertools.product((0,p['ages'][-1]),('relocate','arrange_2')):
        collected=[]
        for b in p['adaptation_budgets']:
            x=values('adaptation',p['adaptation_domain'],task,age,b or None)
            if x is None:continue
            stats=paired_inference(x,draws,rng);stats.pop('p')
            rows.append(dict(split='adaptation',domain=p['adaptation_domain'],task=task,age=age,budget=b,**stats));collected.append((b,x))
        for (a,x),(b,y) in zip(collected,collected[1:]):
            if p['adaptation_budgets'].index(b)-p['adaptation_budgets'].index(a)!=1:continue
            stats=paired_inference((y-x)*1000/(b-a),draws,rng);stats.pop('p')
            speed.append(dict(split='adaptation',domain=p['adaptation_domain'],task=task,age=age,start=a,end=b,unit='success_gain_per_1000_new_interactions',**stats))
    write_csv(root/'curve_intervals.csv',rows);write_csv(root/'speed_intervals.csv',speed);write_csv(root/'learning_efficiency.csv',efficiency)
    return rows
