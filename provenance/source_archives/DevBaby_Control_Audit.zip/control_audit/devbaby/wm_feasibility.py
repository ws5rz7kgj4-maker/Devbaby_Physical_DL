"""Development-only privileged mechanical check, never used for model training."""
from pathlib import Path
import argparse
import numpy as np
from .wm_config import WMConfig,DOMAINS,TASKS
from .wm_world import PhysicalWorld,target_goal,achieved,PrivilegedReference
from .audio import Speech
from .utils import derived_seed,atomic_json

def check(output,trials=3):
    output=Path(output);cfg=WMConfig();speech=Speech(output.parent/'mechanical_speech');rows=[]
    for domain in DOMAINS:
        for task in TASKS:
            for trial in range(trials):
                seed=derived_seed('wm-mechanical-check-only',domain,task,trial)
                with PhysicalWorld(cfg,speech,seed,domain,n_objects=3 if task=='arrange_3' else 2,task=task) as world:
                    _,truth=target_goal(world,task);obs=world.observe();policy=PrivilegedReference(world,truth);successes=[]
                    for step in range(cfg.task_steps):
                        obs,_,_=world.step(policy(obs));ok,distance=achieved(world,truth);successes.append(ok)
                    rows.append(dict(domain=domain,task=task,trial=trial,scene_seed=seed,
                        success=int(all(successes[-3:])),distances=distance))
            print(domain,task,[r['success'] for r in rows[-trials:]],flush=True)
    result=dict(development_only=True,reference='privileged engineering controller, not a learned model or optimal oracle',
        success_count=sum(r['success'] for r in rows),trials=len(rows),task_steps=cfg.task_steps,
        warning='A failure here is not proof of task impossibility; small development panels do not establish universal feasibility.',rows=rows)
    atomic_json(output,result);return result

def main():
    p=argparse.ArgumentParser();p.add_argument('--output',required=True);p.add_argument('--trials',type=int,default=3)
    a=p.parse_args();check(a.output,a.trials)
if __name__=='__main__':main()
