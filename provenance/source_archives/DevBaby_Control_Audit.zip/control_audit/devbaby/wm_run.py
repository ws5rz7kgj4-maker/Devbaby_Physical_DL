"""Independent complete experiment. No job creation and no automatic paid retry."""
from pathlib import Path
from dataclasses import replace
import argparse
import hashlib
import json
import os
import platform
import sys
import time
import traceback
import numpy as np
import torch
from .wm_config import load_protocol
from .wm_world import collect_episode
from .wm_train import train_series,load_model
from .wm_eval import fit_probe,prediction_episode,physical_panel,load_episode
from .wm_plan import model_id,evaluation_plan,diagnostic_models,plan_summary,key
from .wm_sync import sync_run
from .audio import Speech
from .utils import atomic_json,derived_seed,device_for

class BudgetStop(Exception):pass
class Context:
    def __init__(self,root,p,device,seconds,repo,runid):
        self.root=root;self.p=p;self.device=device;self.deadline=time.monotonic()+seconds
        self.repo=repo;self.runid=runid;self.lastsync=time.monotonic();self.phase='setup'
        self.state={'status':'running','phase':'setup'}
    def check(self):
        if time.monotonic()>=self.deadline:raise BudgetStop('Cooperative time budget reached')
    def __call__(self,message,force=False):
        print(message,flush=True);self.state.update(status='running',phase=self.phase,message=message,unix_time=time.time())
        atomic_json(self.root/'state.json',self.state)
        if force or time.monotonic()-self.lastsync>=self.p['sync_seconds']:
            sync_run(self.root,self.repo,self.runid);self.lastsync=time.monotonic()
    def collect(self,cfg,speech,split,seed,count,domain='iid'):
        paths=[]
        for i in range(count):
            self.check();path=self.root/'data'/split/f's{seed}'/f'{i:06d}'
            collect_episode(cfg,speech,path,derived_seed(self.p['namespace'],split,seed,i),domain,split)
            paths.append(path)
            if i%16==0:self(f'data {split} seed {seed}: {i+1}/{count}')
        return paths

def code_digest():
    h=hashlib.sha256()
    for f in sorted(Path(__file__).parent.glob('*.py')):h.update(f.name.encode());h.update(f.read_bytes())
    return h.hexdigest()

def run(protocol,output,device='auto',seconds=None,repo=None,runid='local'):
    p,cfg=load_protocol(protocol);root=Path(output);root.mkdir(parents=True,exist_ok=True)
    identity=dict(code_sha256=code_digest(),protocol_sha256=hashlib.sha256(Path(protocol).read_bytes()).hexdigest())
    if (root/'identity.json').exists() and json.loads((root/'identity.json').read_text())!=identity:
        raise ValueError('Code/protocol changed: use a new output directory and namespace')
    atomic_json(root/'identity.json',identity);atomic_json(root/'protocol.lock.json',p)
    atomic_json(root/'plan.json',plan_summary(p));atomic_json(root/'planned_evaluations.json',evaluation_plan(p))
    torch.set_num_threads(cfg.threads);dev=device_for(device)
    atomic_json(root/'runtime.json',dict(python=sys.version,torch=torch.__version__,numpy=np.__version__,device=str(dev),
        platform=platform.platform(),cuda=torch.version.cuda,gpu=torch.cuda.get_device_name() if dev.type=='cuda' else None))
    ctx=Context(root,p,dev,seconds or p['job_seconds'],repo,runid);speech=Speech(root/'speech',cfg.sample_rate)
    try:
        if (root/'state.json').exists() and json.loads((root/'state.json').read_text()).get('status')=='complete':return
        ctx('World-model study begins/resumes',True)
        if dev.type=='cuda':
            from .wm_preflight import preflight
            ctx.phase='gpu_preflight'
            # On the repair run these episodes already exist and are not recollected.
            # On a fresh run only the first replay block is needed before testing.
            initial_cfg=replace(cfg,seed=p['seeds'][0])
            initial_paths=ctx.collect(initial_cfg,speech,'train',p['seeds'][0],cfg.episodes_per_block)
            preflight(initial_cfg,p,initial_paths,root,ctx)
            ctx('GPU preflight passed; formal training starts/resumes',True)
        # No final-evaluation scene is collected or scored until all model fitting
        # (including posthoc diagnostic readouts) has completed.
        for seed in p['seeds']:
            cfgseed=replace(cfg,seed=seed);ctx.phase='training'
            paths=ctx.collect(cfgseed,speech,'train',seed,cfg.blocks*cfg.episodes_per_block)
            audit=root/f'coverage_seed{seed}.json'
            if not audit.exists():
                from .wm_audit import coverage
                coverage(paths,audit)
            for arm in p['arms']:
                train_series(cfgseed,p,root,seed,arm,'wm',paths,ctx,ctx.check)
            train_series(cfgseed,p,root,seed,'full','bc',paths,ctx,ctx.check)
            ctx.phase='adaptation_training'
            adaptpaths=ctx.collect(cfgseed,speech,'adapt_train',seed,max(p['adaptation_budgets'])//cfg.episode_steps,p['adaptation_domain'])
            for age in (0,p['ages'][-1]):
                train_series(cfgseed,p,root,seed,'full','wm',adaptpaths,ctx,ctx.check,age,
                    root/'checkpoints'/f'{model_id(seed,"full",age)}.pt')
            ctx.phase='probe_fitting'
            probepaths=ctx.collect(cfgseed,speech,'probe_fit',seed,p['probe_fit_episodes'])
            for m in [x for x in diagnostic_models(p) if x['seed']==seed]:
                ctx.check();probe=root/'probes'/f'{m["id"]}.npz'
                if not probe.exists():
                    model=load_model(root/'checkpoints'/f'{m["id"]}.pt',cfgseed,dev)
                    fit_probe(model,probepaths,m['arm'],dev,p['probe_stride'],p['probe_ridge'],probe)
                ctx('probe fitted '+m['id'])
        atomic_json(root/'fit_seal.json',dict(complete=True,identity=identity,unix_time=time.time(),final_evaluation_started=False))
        ctx('All fitting sealed before final evaluation',True)
        ctx.phase='prediction_evaluation'
        for m in diagnostic_models(p):
            cfgseed=replace(cfg,seed=m['seed']);model=None
            with np.load(root/'probes'/f'{m["id"]}.npz') as z:probe={k:z[k] for k in z.files}
            for domain in p['domains']:
                spec=dict(model=m['id'],domain=domain);dest=root/'diagnostics'/f'{key(spec)}.json'
                if dest.exists():continue
                paths=ctx.collect(cfgseed,speech,'prediction_'+domain,0,p['prediction_episodes'],domain)
                if model is None:model=load_model(root/'checkpoints'/f'{m["id"]}.pt',cfgseed,dev)
                rows=[]
                for i,path in enumerate(paths):
                    ctx.check()
                    for r in prediction_episode(model,path,paths[(i+1)%len(paths)],m['arm'],probe,p,cfg,dev):
                        rows.append(dict(model=m['id'],seed=m['seed'],arm=m['arm'],age=m['age'],domain=domain,episode=i,**r))
                atomic_json(dest,dict(spec=spec,rows=rows,complete=True));ctx('prediction '+m['id']+' '+domain)
        ctx.phase='physical_evaluation';loaded=None;model=None
        # One exogenous, independent donor recording for each test domain. The
        # donor is generated under a distinct split and supplies no physical truth.
        donors={}
        for domain in p['domains']:
            paths=ctx.collect(cfg,speech,'audio_donor_'+domain,0,2,domain)
            donors[domain]=load_episode(paths[0])['audio']
        for ident,spec in evaluation_plan(p).items():
            ctx.check();dest=root/'physical_panels'/ident
            if (dest/'panel.json').exists():continue
            if spec['kind'] in {'wm','bc'} and loaded!=spec['model']:
                model=load_model(root/'checkpoints'/f'{spec["model"]}.pt',cfg,dev);loaded=spec['model']
            physical_panel(spec,p,cfg,speech,model,dest,donors[spec['domain']],ctx.check)
            ctx(f'physical {spec["model"]} {spec["split"]} {spec["domain"]} {spec["task"]} h{spec["horizon"]}')
        ctx.phase='report';from .wm_report import report
        report(root);ctx.state.update(status='complete',phase='complete',unix_time=time.time())
        atomic_json(root/'state.json',ctx.state);sync_run(root,repo,runid)
        print('COMPLETE: '+str(root/'report.html'),flush=True)
    except BudgetStop as e:
        ctx.state.update(status='paused',phase=ctx.phase,message=str(e));atomic_json(root/'state.json',ctx.state)
        from .wm_report import report
        report(root);sync_run(root,repo,runid);print('PAUSED; resume explicitly to continue.',flush=True)
    except BaseException:
        (root/'failure.txt').write_text(traceback.format_exc());ctx.state.update(status='error',phase=ctx.phase)
        atomic_json(root/'state.json',ctx.state)
        try:sync_run(root,repo,runid)
        except Exception:traceback.print_exc()
        raise

def main():
    q=argparse.ArgumentParser();q.add_argument('--protocol',default='protocol.json');q.add_argument('--output',required=True)
    q.add_argument('--device',default='auto');q.add_argument('--seconds',type=float);q.add_argument('--repo');q.add_argument('--run-id',default='local')
    a=q.parse_args();run(a.protocol,a.output,a.device,a.seconds,a.repo,a.run_id)
if __name__=='__main__':main()
