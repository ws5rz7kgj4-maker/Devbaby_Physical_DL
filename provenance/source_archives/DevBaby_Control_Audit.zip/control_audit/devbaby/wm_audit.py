"""Offline coverage summaries; output is never fed back to learner or controller."""
from pathlib import Path
import json
import numpy as np
from .utils import atomic_json

def coverage(paths,destination):
    out=dict(episodes=len(paths),transitions=0,frames_with_hand_contact=0,frames_with_grasp=0,
             frames_with_moving_object=0,object_instances=0,materials={},shapes={},colors={})
    for path in paths:
        path=Path(path)
        with np.load(path/'observations.npz') as ep:
            out['transitions']+=len(ep['actions']);out['frames_with_hand_contact']+=int((ep['proprio'][1:,7]>.5).sum())
            out['frames_with_grasp']+=int((ep['proprio'][1:,9]>.5).sum())
        with np.load(path/'annotations/truth.npz') as truth:
            speed=np.linalg.norm(truth['state'][1:,:,12:15],axis=-1)
            out['frames_with_moving_object']+=int((speed>.03).any(1).sum())
        scene=json.loads((path/'annotations/scene.json').read_text())
        for obj in scene['objects']:
            out['object_instances']+=1
            for field in ['material','shape','color']:
                group=field+'s';v=obj[field];out[group][v]=out[group].get(v,0)+1
    for name in ('frames_with_hand_contact','frames_with_grasp','frames_with_moving_object'):
        out[name+'_fraction']=out[name]/max(1,out['transitions'])
    out['interpretation']='Coverage is descriptive only; low contact/grasp coverage can explain failure. It never changes training budgets or selects test scenes.'
    atomic_json(destination,out);return out
