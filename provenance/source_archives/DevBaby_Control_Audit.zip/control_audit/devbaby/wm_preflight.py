"""Bounded GPU checks on training data, never on held-out evaluation scenes.

Disposable networks use the actual formal batch, burn-in and rollout sizes.
Neither their weights nor their optimizer/RNG state enter formal training.
"""
import json
import time
import numpy as np
import torch
from .wm_data import Replay
from .wm_numeric import optimizer_update, NUMERICS_VERSION
from .wm_train import make_model, rng_state, restore_rng
from .utils import atomic_json, derived_seed


class OverflowProbe(torch.nn.Module):
    def __init__(self, device):
        super().__init__()
        self.weight = torch.nn.Parameter(torch.ones(1, device=device))

    def loss(self, batch):
        value = self.weight.square().mean()
        return value, {'probe_loss': value.detach()}


def overflow_probe(device):
    model = OverflowProbe(device)
    optimizer = torch.optim.SGD(model.parameters(), lr=.01)
    scaler = torch.amp.GradScaler(device.type, enabled=True)
    calls = [0]
    def poison_once(gradient):
        calls[0] += 1
        return gradient * float('inf') if calls[0] == 1 else gradient
    handle = model.weight.register_hook(poison_once)
    result = optimizer_update(model, optimizer, scaler, {})
    handle.remove()
    if len(result['events']) != 1 or result['attempts'] != 2 or not torch.allclose(model.weight, torch.tensor([.98], device=device)):
        raise RuntimeError('AMP overflow retry did not make exactly one valid update')
    return result


def preflight(cfg, protocol, paths, root, context):
    device = context.device
    if device.type != 'cuda':
        return
    report_path = root/'gpu_preflight.json'
    report = dict(status='running', numerics_version=NUMERICS_VERSION,
                  torch=torch.__version__, cuda=torch.version.cuda,
                  gpu=torch.cuda.get_device_name(device), config=cfg.asdict(),
                  disposable_models=True, uses_training_data_only=True, cases=[])
    started = time.monotonic()
    dummy_rng = np.random.default_rng(0)
    original_rng = rng_state(dummy_rng)
    atomic_json(report_path, report)
    try:
        context('GPU preflight: injected-overflow recovery')
        report['overflow_probe'] = overflow_probe(device)
        replay = Replay(paths[:cfg.episodes_per_block], cfg.cache_episodes)
        for kind, arm in [('wm',a) for a in protocol['arms']] + [('bc','full')]:
            context.check()
            model = make_model(cfg, protocol['seeds'][0], kind, device)
            optimizer = torch.optim.AdamW(model.parameters(), lr=cfg.learning_rate, weight_decay=1e-5)
            scaler = torch.amp.GradScaler('cuda', enabled=cfg.amp)
            rng = np.random.default_rng(derived_seed(protocol['namespace'],'sampler',protocol['seeds'][0],kind,None))
            case = dict(kind=kind, arm=arm, updates=[])
            report['cases'].append(case)
            for step in range(4 if kind=='wm' else 2):
                context.check()
                batch = replay.sample(cfg, arm, rng, device)
                result = optimizer_update(model, optimizer, scaler, batch,
                    lambda event:print('PREFLIGHT RETRY '+json.dumps(event), flush=True))
                case['updates'].append(dict(update=step+1,sample_ids=batch['sample_ids'],**result))
                if not all(bool(torch.isfinite(v).all()) for v in model.state_dict().values()):
                    raise FloatingPointError('Preflight parameters became nonfinite')
                atomic_json(report_path, report)
            context(f'GPU preflight passed: {kind}/{arm}')
            del batch, model, optimizer, scaler
        torch.cuda.synchronize(device)
        report.update(status='passed', elapsed_seconds=time.monotonic()-started,
                      peak_allocated_bytes=torch.cuda.max_memory_allocated(device))
    except BaseException as exc:
        report.update(status='failed', error_type=type(exc).__name__, error=str(exc),
                      elapsed_seconds=time.monotonic()-started)
        raise
    finally:
        atomic_json(report_path, report)
        restore_rng(original_rng, dummy_rng)
        torch.cuda.empty_cache()
