"""Synthetic two-camera rigid-body experience; truth is audit-only.

The inherited grasp reflex is an explicit embodiment assumption. Learned policy
interfaces receive images, audio and proprioception, never this World object.
"""
from collections import deque
from dataclasses import replace
from pathlib import Path
import json
import math
import zipfile
import numpy as np
import pybullet as pb
from scipy.io import wavfile
from .config import Config
from .world import World,COLORS
from .audio import features
from .utils import atomic_json,derived_seed

SENSORY_KEYS={'rgb','audio','impact_audio','speech_audio','proprio','actions'}
MATERIALS={
    'wood':dict(mass=.08,friction=.45,restitution=.25),
    'metal':dict(mass=.22,friction=.18,restitution=.55),
    'rubber':dict(mass=.12,friction=.85,restitution=.70)}
COLOR_NAMES=tuple(COLORS)

class PhysicalWorld(World):
    def __init__(self,cfg,speech,seed,domain='iid',n_objects=None,caregiver=True,task=None):
        self.wcfg=cfg;self.domain=domain
        r=np.random.default_rng(derived_seed(seed,'objects'))
        n_objects=n_objects or int(r.integers(2,4))
        colors=list(r.choice(COLOR_NAMES,n_objects,replace=False))
        shapes=['block']*n_objects if task in {'stack_2','arrange_2','arrange_3'} else list(r.choice(['ball','block','cylinder'],n_objects))
        self.pending_speech_wave=np.zeros(cfg.sample_rate*8,np.float32)
        self.pending_impact_wave=np.zeros_like(self.pending_speech_wave)
        self.audio_kind='impact';self.streams={}
        legacy=Config(seed=cfg.seed,episode_steps=cfg.episode_steps,control_hz=cfg.control_hz,
            physics_hz=cfg.physics_hz,sample_rate=cfg.sample_rate,objects_min=2,objects_max=4,
            motor_domain_randomization=True,clip_steps=min(16,cfg.episode_steps-1))
        condition={'new_physics':'new_dynamics','new_layout':'new_layout'}.get(domain,'iid')
        super().__init__(legacy,speech,seed,condition,list(zip(colors,shapes)),caregiver)
        self.next_disturbance=10**12 # no unobserved future random force during prediction
        self.motor_delay=3 if domain=='new_physics' else int(r.integers(0,2))
        self.action_queue=deque([np.zeros(5,np.float32) for _ in range(self.motor_delay)])
        for obj in self.objects:
            base=MATERIALS[obj['material']]
            scale=1.7 if domain in {'new_physics','material_shift'} else 1.0
            mass=base['mass']*(obj['size']/.06)**3*float(r.uniform(.8,1.2))*scale
            friction=float(np.clip(base['friction']*r.uniform(.85,1.15)/(1.7 if domain=='material_shift' else 1),.04,.95))
            restitution=float(np.clip(base['restitution']+r.uniform(-.08,.08),.05,.9))
            obj.update(mass=mass,friction=friction,restitution=restitution)
            self.call('changeDynamics',obj['id'],-1,mass=mass,lateralFriction=friction,restitution=restitution)
        # All bodies, cameras and obstacles are held fixed across audio arms.
        self.next_disturbance=10**12

    def _physics_tick(self):
        # Explicit actuator: stabilize roll/pitch and servo commanded yaw using
        # bounded torque, rather than silently letting the grasp sphere tumble.
        _,q=self.call('getBasePositionAndOrientation',self.hand)
        target=pb.getQuaternionFromEuler([0,0,self.yaw])
        difference=pb.getDifferenceQuaternion(q,target)
        axis,angle=pb.getAxisAngleFromQuaternion(difference)
        _,omega=self.call('getBaseVelocity',self.hand)
        torque=np.clip(.12*np.asarray(axis)*angle-.012*np.asarray(omega),-.08,.08)
        self.call('applyExternalTorque',self.hand,-1,torque.tolist(),pb.WORLD_FRAME)
        super()._physics_tick()

    def _add_audio(self,wav,offset=0):
        super()._add_audio(wav,offset)
        buf=self.pending_speech_wave if self.audio_kind=='speech' else self.pending_impact_wave
        n=min(len(wav),len(buf)-offset)
        if n>0:buf[offset:offset+n]+=wav[:n]

    def _speak(self):
        r=self.language_rng;self.focal_index=int(r.integers(len(self.objects)))
        obj=self.objects[self.focal_index]
        templates=['the {c} {s} is {m}','look at the {m} {s}','there is a {c} {s}','{m} {s}']
        text=str(r.choice(templates)).format(c=obj['color'],s=obj['shape'],m=obj['material'])
        voice=str(r.choice(['en-us','en']));speed=int(r.choice([175,195,215]));pitch=int(r.choice([35,50,65]))
        wave=self.speech.synthesize(text,voice,speed,pitch)
        self.audio_kind='speech'
        try:self._add_audio(wave)
        finally:self.audio_kind='impact'
        self.utterances.append(dict(text=text,start_s=self.step_index*self.dt,
            end_s=self.step_index*self.dt+len(wave)/self.cfg.sample_rate,
            voice=voice,speed=speed,pitch=pitch,referent_id=obj['id'],
            color=obj['color'],shape=obj['shape'],material=obj['material'],learner_receives_text=False))
        self.next_speech=self.step_index+int(r.integers(20,36))

    def render(self,size=None):
        size=size or self.cfg.image_size
        eyes=[[-.38,-.64,.72],[.65,.6,1.15]];target=[.43,0,.06]
        images=[];masks=[];cameras=[]
        for view_index,eye in enumerate(eyes):
            view=pb.computeViewMatrix(eye,target,[0,0,1]);proj=pb.computeProjectionMatrixFOV(62,1,.02,5)
            im=self.call('getCameraImage',size,size,viewMatrix=view,projectionMatrix=proj,
                renderer=pb.ER_TINY_RENDERER,flags=pb.ER_SEGMENTATION_MASK_OBJECT_AND_LINKINDEX,
                shadow=0,lightDirection=[-1,-1,3])
            rgb=np.asarray(im[2],np.uint8).reshape(size,size,4)[:,:,:3].copy()
            mask=np.asarray(im[4]).reshape(size,size).copy()
            # An observable opaque camera occluder; masks remain evaluation-only.
            if self.domain=='occluded':
                left=16 if view_index==0 else 32
                rgb[18:46,left:left+12]=np.array([40,43,46],np.uint8)
                mask[18:46,left:left+12]=-1
            images.append(rgb);masks.append(mask)
            cameras.append(dict(eye=eye,target=target,up=[0,0,1],view=view,projection=proj))
        self.multi_masks=np.stack(masks);self.cameras=cameras
        self.latest_camera=cameras[0]
        return np.stack(images),masks[0]

    def observe(self,audio=None):
        observation=super().observe(audio)
        zero=np.zeros(self.n_audio,np.float32)
        observation['impact_audio']=features(self.streams.get('impact',zero),self.cfg.sample_rate)
        observation['speech_audio']=features(self.streams.get('speech',zero),self.cfg.sample_rate)
        return observation

    def step(self,action):
        issued=np.clip(np.asarray(action,np.float32),-1,1)
        observation,mix,ann=super().step(issued)
        self.streams={'speech':self.pending_speech_wave[:self.n_audio].copy(),
                      'impact':self.pending_impact_wave[:self.n_audio].copy()}
        for buf in (self.pending_speech_wave,self.pending_impact_wave):
            buf[:-self.n_audio]=buf[self.n_audio:];buf[-self.n_audio:]=0
        observation['speech_audio']=features(np.clip(self.streams['speech'],-1,1),self.cfg.sample_rate)
        observation['impact_audio']=features(np.clip(self.streams['impact'],-1,1),self.cfg.sample_rate)
        ann['issued_action']=issued.tolist()
        return observation,mix,ann

    def annotation(self,action=None):
        a=super().annotation(action)
        a['cameras']=getattr(self,'cameras',[])
        a['object_contacts']=[[int(x),int(y)] for x,y in self.object_contact_pairs()]
        a['hand_contacts']=[int(obj['id']) for obj in self.objects if self.call('getContactPoints',bodyA=self.hand,bodyB=obj['id'])]
        return a

    def object_contact_pairs(self):
        return sorted({tuple(sorted((c[1],c[2]))) for c in self.call('getContactPoints')
            if c[1] in self.object_ids and c[2] in self.object_ids and c[1]!=c[2]})

    def metadata(self):
        return {**super().metadata(),'domain':self.domain,'two_fixed_cameras':True,
                'material_physics':MATERIALS,'unobserved_external_pushes':False,'orientation_servo':dict(stiffness=.12,damping=.012,torque_limit=.08)}

class RandomMotor:
    """Correlated random motor babbling; no object, goal or task input."""
    def __init__(self,seed):
        self.rng=np.random.default_rng(seed);self.remaining=0
    def __call__(self,obs):
        if self.remaining<=0:
            self.target=self.rng.uniform([.08,-.45,.05],[.88,.45,.48])
            self.grip=float(self.rng.choice([-1,1]));self.remaining=int(self.rng.integers(4,17))
        self.remaining-=1
        act=np.zeros(5,np.float32)
        act[:3]=np.clip((self.target-obs['proprio'][:3])/.09+self.rng.normal(0,.12,3),-1,1)
        act[3]=self.grip;act[4]=self.rng.uniform(-.3,.3)
        return act

def state_label(world):
    """Separate frozen-probe/evaluation label, sorted by visible color identity.

    4 color identities x [position3, rotation_matrix9, velocity3, angular3],
    plus hand contacts4 and unordered object contacts6. Presence is not an input.
    """
    state=np.zeros((4,18),np.float32);present=np.zeros(4,np.float32);contacts=np.zeros(10,np.float32)
    by_color={o['color']:o for o in world.objects}
    for i,color in enumerate(COLOR_NAMES):
        if color not in by_color:continue
        obj=by_color[color];bid=obj['id'];pos,q=world.call('getBasePositionAndOrientation',bid)
        v,w=world.call('getBaseVelocity',bid)
        state[i]=np.r_[pos,pb.getMatrixFromQuaternion(q),v,w];present[i]=1
        contacts[i]=bool(world.call('getContactPoints',bodyA=world.hand,bodyB=bid))
    k=4
    for i in range(4):
        for j in range(i+1,4):
            if COLOR_NAMES[i] in by_color and COLOR_NAMES[j] in by_color:
                contacts[k]=bool(world.call('getContactPoints',bodyA=by_color[COLOR_NAMES[i]]['id'],bodyB=by_color[COLOR_NAMES[j]]['id']))
            k+=1
    masks=np.zeros_like(world.multi_masks,np.uint8)
    for i,color in enumerate(COLOR_NAMES):
        if color in by_color:masks[(world.multi_masks & ((1<<24)-1))==by_color[color]['id']]=i+1
    return dict(state=state,present=present,contacts=contacts,masks=masks)

class Recorder:
    def __init__(self,world,obs):
        self.world=world;self.observations=[obs];self.actions=[];self.waves=[]
        self.annotations=[world.annotation()];self.labels=[state_label(world)]
    def add(self,action,obs,wave,annotation):
        self.actions.append(np.asarray(action,np.float32));self.observations.append(obs)
        self.waves.append(np.stack([wave,self.world.streams['impact'],self.world.streams['speech']],axis=-1))
        self.annotations.append(annotation);self.labels.append(state_label(self.world))
    def save(self,path,identity):
        path=Path(path);path.mkdir(parents=True,exist_ok=True)
        arrays={k:np.stack([o[k] for o in self.observations]) for k in ('rgb','audio','impact_audio','speech_audio','proprio')}
        arrays['actions']=np.stack(self.actions);assert set(arrays)==SENSORY_KEYS
        atomic_npz(path/'observations.npz',arrays)
        hidden=path/'annotations';hidden.mkdir(exist_ok=True)
        atomic_npz(hidden/'truth.npz',{k:np.stack([r[k] for r in self.labels]) for k in self.labels[0]})
        atomic_json(hidden/'scene.json',{**self.world.metadata(),'utterances':self.world.utterances})
        with (hidden/'frames.jsonl').open('w') as f:
            for row in self.annotations:f.write(json.dumps(row)+'\n')
        wavfile.write(path/'audio.wav',self.world.cfg.sample_rate,
            np.clip(np.concatenate(self.waves)*32767,-32768,32767).astype(np.int16))
        atomic_json(path/'complete.json',{**identity,'steps':len(self.actions),
            'audio_channels':['mixture','physical_impacts','caregiver_speech'],
            'training_keys':sorted(SENSORY_KEYS),'annotations_are_model_inputs':False})

def atomic_npz(path,arrays):
    path=Path(path);path.parent.mkdir(parents=True,exist_ok=True)
    temporary=path.with_suffix('.tmp')
    with temporary.open('wb') as f:np.savez_compressed(f,**arrays)
    temporary.replace(path)

def collect_episode(cfg,speech,path,seed,domain='iid',split='train'):
    path=Path(path);identity=dict(seed=int(seed),domain=domain,split=split)
    if (path/'complete.json').exists():
        old=json.loads((path/'complete.json').read_text())
        if any(old.get(k)!=v for k,v in identity.items()):raise ValueError('Episode cache identity mismatch')
        return old
    with PhysicalWorld(cfg,speech,seed,domain,caregiver=True) as world:
        obs=world.observe();rec=Recorder(world,obs);policy=RandomMotor(derived_seed(seed,'babbling'))
        for _ in range(cfg.episode_steps):
            action=policy(obs);obs,wav,ann=world.step(action);rec.add(action,obs,wav,ann)
        rec.save(path,identity)
    return json.loads((path/'complete.json').read_text())

def target_goal(world,task):
    """Return public final images and private scoring specification separately."""
    obj=world.objects;initial={o['id']:np.array(world.call('getBasePositionAndOrientation',o['id'])[0]) for o in obj}
    positions={k:v.copy() for k,v in initial.items()};r=np.random.default_rng(derived_seed(world.seed,'goal',task))
    if task=='relocate':
        # Goal generation may consult simulator geometry; the learned controller
        # receives only the resulting final image. Reject obstacle-intersecting
        # end states before evaluation, never based on a model's performance.
        selected=obj[0];origin=initial[selected['id']];half=selected['size']
        sign=1 if origin[0]<.55 else -1
        candidates=[origin+np.array([.18*sign,0,0])]
        candidates += [origin+np.array([.18*np.cos(a),.18*np.sin(a),0]) for a in np.linspace(0,2*np.pi,16,endpoint=False)]
        def clear(pos):
            if not (.09<pos[0]<.95 and -.55<pos[1]<.55):return False
            for other in obj[1:]:
                if np.all(np.abs(pos-initial[other['id']])<half+other['size']+.005):return False
            for geom in world.static_geometry:
                center=np.array(geom['position']);extent=np.array(geom['half_extents'])
                if center[2]+extent[2]<=.001:continue
                if np.all(np.abs(pos-center)<extent+half+.005):return False
            return True
        feasible=[v for v in candidates if clear(v)]
        if not feasible:raise RuntimeError('No collision-free relocation goal; protocol needs a new development revision')
        positions[selected['id']]=feasible[0]
    elif task=='lift':positions[obj[0]['id']][2]+=.25
    elif task=='stack_2':positions[obj[1]['id']]=positions[obj[0]['id']]+[0,0,obj[0]['size']+obj[1]['size']]
    elif task in {'arrange_2','arrange_3'}:
        n=2 if task=='arrange_2' else 3
        for i in range(n):positions[obj[i]['id']]=np.array([.70,-.28+i*.27,initial[obj[i]['id']][2]])
    else:raise ValueError(task)
    sid=world.call('saveState');before=world.observe()['rgb']
    try:
        for o in obj:
            _,q=world.call('getBasePositionAndOrientation',o['id'])
            world.call('resetBasePositionAndOrientation',o['id'],positions[o['id']].tolist(),q)
        target=world.observe()['rgb']
    finally:world.call('restoreState',stateId=sid);world.call('removeState',stateUniqueId=sid)
    changed=np.max(np.abs(target.astype(float)-before.astype(float)),axis=-1)>.08*255
    # Public change weights are derived only from the two supplied images.
    from scipy.ndimage import maximum_filter
    weights=np.stack([maximum_filter(m.astype(float),size=5) for m in changed]).astype(np.float32)
    weights=.05+weights
    truth=dict(task=task,targets={str(k):v.tolist() for k,v in positions.items()},
               initial={str(k):v.tolist() for k,v in initial.items()},object_ids=[o['id'] for o in obj])
    return {'rgb':target,'weights':weights},truth

def achieved(world,truth):
    distances=[]
    for bid,pos in truth['targets'].items():
        now=np.asarray(world.call('getBasePositionAndOrientation',int(bid))[0])
        distances.append(float(np.linalg.norm(now-np.asarray(pos))))
    ok=all(d<.075 for d in distances)
    if truth['task']=='lift':ok=ok and world.held_id==truth['object_ids'][0]
    else:ok=ok and world.constraint is None
    if truth['task']=='stack_2':
        a,b=truth['object_ids'][:2]
        ok=ok and bool(world.call('getContactPoints',bodyA=a,bodyB=b))
    return bool(ok),distances

class PrivilegedReference:
    """Feasibility only; no reference trajectories are training data."""
    def __init__(self,world,truth):
        self.world=world;self.truth=truth;self.phase=0;self.selected=None;self.wait=0
    def __call__(self,obs):
        w=self.world;hand=np.array(obs['proprio'][:3]);act=np.zeros(5,np.float32)
        if self.wait:
            self.wait-=1;act[3]=-1;return act
        if self.selected is None:
            candidates=[int(bid) for bid,pos in self.truth['targets'].items()
                if np.linalg.norm(np.array(w.call('getBasePositionAndOrientation',int(bid))[0])-pos)>.04]
            if not candidates:act[3]=-1;return act
            self.selected=candidates[0];self.phase=0
        bid=self.selected;pos=np.array(w.call('getBasePositionAndOrientation',bid)[0]);goal=np.array(self.truth['targets'][str(bid)])
        # Maintain the actual grasp offset; it is a privileged reference only.
        offset=hand-pos if w.held_id==bid else np.array([0,0,.05])
        mass=next(o['mass'] for o in w.objects if o['id']==bid)
        hover=.48+mass*abs(w.gravity)/w.motor_gain
        if self.phase==0:
            destination=np.array([pos[0],pos[1],.42]);act[3]=-1
            if np.linalg.norm(hand[:2]-pos[:2])<.035 and hand[2]>.34:self.phase=1
        elif self.phase==1:
            destination=pos+np.array([0,0,.025]);act[3]=1
            if w.held_id==bid:self.phase=2
            elif w.held_id is not None:act[3]=-1;self.phase=0
        elif self.phase==2:
            destination=np.array([pos[0]+offset[0],pos[1]+offset[1],hover]);act[3]=1
            if hand[2]>.42:self.phase=3
        elif self.phase==3:
            destination=np.array([goal[0]+offset[0],goal[1]+offset[1],hover]);act[3]=1
            if np.linalg.norm(pos[:2]-goal[:2])<.045:self.phase=4
        else:
            velocity=np.array(w.call('getBaseVelocity',bid)[0])
            destination=w.target+.35*(goal-pos)-.06*velocity;act[3]=1
            if self.truth['task']!='lift' and np.linalg.norm(pos-goal)<.045:
                act[3]=-1;self.selected=None;self.wait=4
        # Compensate queued motor commands in the privileged delayed-motor case.
        pending=sum((np.asarray(a[:3])*w.motor_step for a in w.action_queue),np.zeros(3))
        act[:3]=np.clip((destination-w.target-pending)/w.motor_step,-1,1)
        return act
