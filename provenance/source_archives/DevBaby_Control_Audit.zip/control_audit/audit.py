"""Posthoc diagnostic of frozen DevBaby checkpoints; never trains weights."""
import hashlib,json,os,time,zipfile
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import numpy as np
import torch
from scipy.stats import spearmanr
from huggingface_hub import HfApi,hf_hub_download
from devbaby.wm_config import WMConfig
from devbaby.wm_world import PhysicalWorld,RandomMotor,Recorder,target_goal,achieved,PrivilegedReference
from devbaby.audio import Speech
from devbaby.wm_train import load_model
from devbaby.wm_data import image_tensor,observation_tensor
from devbaby.wm_plan import key
from devbaby.utils import atomic_json,derived_seed

REPO='swenlio/devbaby-worldmodel-results'
OUTPUT_REPO='swenlio/devbaby-control-audit-results'
SOURCE='runs/worldmodel-dacc6ff327cf'
OUT=Path('output')
api=None;revision=None
prefix=os.environ.get('AUDIT_PREFIX');cfg=WMConfig();device='cuda' if torch.cuda.is_available() else 'cpu'
torch.set_num_threads(4);started=time.time();download_hashes={}

def fetch(rel):
    path=Path(hf_hub_download(REPO,SOURCE+'/'+rel,repo_type='dataset',revision=revision))
    download_hashes[rel]=hashlib.sha256(path.read_bytes()).hexdigest()
    return path

def publish(phase):
    atomic_json(OUT/'status.json',dict(phase=phase,elapsed_s=time.time()-started,source_revision=revision,
        device=device,training_performed=False))
    atomic_json(OUT/'source_hashes.json',download_hashes)
    api.upload_folder(repo_id=OUTPUT_REPO,repo_type='dataset',folder_path=str(OUT),path_in_repo=prefix,
        commit_message='DevBaby frozen control audit: '+phase)
    print('AUDIT_PHASE',phase,flush=True)

@torch.no_grad()
def predictions(model,ep,truth,seed,age,episode):
    start=16;h=model.initial(1,device)
    for t in range(start+1):
        if t:h=model.prior(h,torch.tensor(ep['actions'][t-1:t],device=device))
        h=model.observe(h,**observation_tensor({k:ep[k][t] for k in ('rgb','audio','proprio')},'full',device))
    actions=ep['actions'][start:start+64]
    variants=np.stack([actions,np.zeros_like(actions),actions[::-1].copy()])
    hs=h.expand(3,-1).contiguous();rows=[]
    for k in range(1,65):
        hs=model.prior(hs,torch.tensor(variants[:,k-1],device=device))
        if k not in (1,8,32,64):continue
        rgb,body=model.decode(hs);target=image_tensor(ep['rgb'][start+k],device)
        persist=image_tensor(ep['rgb'][start],device)
        mask=(truth['masks'][start]>0)|(truth['masks'][start+k]>0)
        roi=torch.tensor(np.repeat(mask[:,None],3,axis=1).reshape(6,64,64),device=device)
        present=truth['present'][start]>.5
        delta=np.linalg.norm(truth['state'][start+k,present,:3]-truth['state'][start,present,:3],axis=1)
        for v,name in enumerate(('actual','zero','reversed')):
            rows.append(dict(seed=seed,age=age,episode=episode,horizon=k,action_variant=name,
                rgb_mse=float((rgb[v]-target).square().mean()),
                object_mse=float((rgb[v]-target).square()[roi].mean()),
                persistence_object_mse=float((persist-target).square()[roi].mean()),
                body_mse=float((body[v]-torch.tensor(ep['proprio'][start+k],device=device)).square().mean()),
                prediction_difference_from_actual=float((rgb[v]-rgb[0]).square().mean()),
                moving_segment=bool(delta.max()>.02),object_displacement_m=float(delta.mean())))
    return rows

def generate(prediction_count=8,ranking_scenes=4):
    speech=Speech('speech');episodes=[];candidates=[]
    for i in range(prediction_count):
        seed=derived_seed('frozen-control-audit-v1','prediction',i)
        with PhysicalWorld(cfg,speech,seed,caregiver=True) as w:
            obs=w.observe();rec=Recorder(w,obs);policy=RandomMotor(derived_seed(seed,'motor'))
            for _ in range(128):
                a=policy(obs);obs,wave,ann=w.step(a);rec.add(a,obs,wave,ann)
            path=Path('recordings')/f'prediction-{i}';rec.save(path,dict(seed=seed,split='new-development'))
            with np.load(path/'observations.npz') as z:ep={k:z[k] for k in z.files}
            with np.load(path/'annotations/truth.npz') as z:truth={k:z[k] for k in z.files}
            episodes.append((ep,truth))
    # Identical starting state per candidate, including actuator delay and RNGs.
    # A privileged reference supplies one positive-control action sequence only.
    # Candidate order is shuffled, and the model never sees candidate identities.
    for scene in range(ranking_scenes):
        seed=derived_seed('frozen-control-audit-v1','ranking',scene)
        rng=np.random.default_rng(derived_seed(seed,'candidates'))
        templates=[np.zeros((64,5),np.float32)]+[np.repeat(rng.uniform(-1,1,(16,5)),4,axis=0).astype(np.float32) for _ in range(6)]+[None]
        order=rng.permutation(8);records=[]
        for candidate in order:
            with PhysicalWorld(cfg,speech,seed,n_objects=2,task='relocate') as w:
                goal,truth=target_goal(w,'relocate');initial=w.observe();obs=initial
                rec=Recorder(w,obs);reference=PrivilegedReference(w,truth);actions=[];ends={}
                for t in range(64):
                    a=reference(obs) if templates[candidate] is None else templates[candidate][t]
                    actions.append(a.copy());obs,wave,ann=w.step(a);rec.add(a,obs,wave,ann)
                    if t+1 in (8,32,64):
                        success,d=achieved(w,truth)
                        weights=np.repeat(goal['weights'][:,None],3,1).reshape(6,64,64)
                        cost=float((((image_tensor(obs['rgb'])-image_tensor(goal['rgb']))**2)*torch.tensor(weights)).mean())
                        ends[t+1]=dict(pixel_cost=cost,distance_m=float(np.mean(d)),success=bool(success))
                rec.save(Path('recordings')/f'ranking-{scene}-{candidate}',dict(seed=seed,split='new-development',reference_only=bool(candidate==7)))
                records.append(dict(initial=initial,goal=goal,actions=np.array(actions),ends=ends,candidate=int(candidate)))
        candidates.append(records)
    with zipfile.ZipFile(OUT/'new_diagnostic_recordings.zip','w',zipfile.ZIP_DEFLATED) as z:
        for f in Path('recordings').rglob('*'):
            if f.is_file():z.write(f,f.relative_to('recordings'))
    return episodes,candidates

@torch.no_grad()
def rank(model,candidates,seed,age):
    rows=[]
    for scene,recs in enumerate(candidates):
        assert all(np.array_equal(r['initial']['rgb'],recs[0]['initial']['rgb']) for r in recs)
        h=model.observe(model.initial(1,device),**observation_tensor(recs[0]['initial'],'full',device)).expand(8,-1).contiguous()
        acts=torch.tensor(np.stack([r['actions'] for r in recs]),device=device)
        goal=image_tensor(recs[0]['goal']['rgb'],device)
        weights=torch.tensor(np.repeat(recs[0]['goal']['weights'][:,None],3,1).reshape(6,64,64),device=device)
        for k in range(1,65):
            h=model.prior(h,acts[:,k-1])
            if k not in (8,32,64):continue
            rgb,_=model.decode(h);cost=((rgb-goal).square()*weights).mean((1,2,3)).cpu().numpy()
            # Match the original planner's small translational effort term.
            effort=.0001*(acts[:,:k,:3].square().mean((1,2))).cpu().numpy()
            scores=cost+effort;actual=np.array([r['ends'][k]['pixel_cost'] for r in recs])+effort
            distances=np.array([r['ends'][k]['distance_m'] for r in recs]);chosen=int(scores.argmin())
            rho=float(spearmanr(scores,actual).statistic) if np.std(actual)>1e-12 and np.std(scores)>1e-12 else None
            rows.append(dict(seed=seed,age=age,scene=scene,horizon=k,predicted_scores=scores.tolist(),
                actual_scores=actual.tolist(),actual_distances=distances.tolist(),candidate_ids=[r['candidate'] for r in recs],
                selected_index=chosen,rank_correlation=rho,
                pixel_regret=float(actual[chosen]-actual.min()),
                distance_advantage_over_uniform=float(distances.mean()-distances[chosen]),
                selected_distance_m=float(distances[chosen]),best_candidate_distance_m=float(distances.min())))
    return rows

def main():
    global api,revision
    if not prefix:raise ValueError('AUDIT_PREFIX is required')
    OUT.mkdir(exist_ok=True);api=HfApi();revision=api.repo_info(REPO,repo_type='dataset').sha
    atomic_json(OUT/'protocol.json',dict(version='frozen-control-audit-v1',source=SOURCE,revision=revision,
        model_seeds=list(range(8)),ages=[0,16384,32768,65536],new_prediction_episodes=8,new_ranking_scenes=4,
        candidate_count=8,horizons=[8,32,64],training=False,
        limitations=['Posthoc diagnostic, not confirmatory generalization test',
        'Reversed actions are a mismatch diagnostic, not their ground-truth counterfactual outcome',
        'One privileged candidate is a positive control; not training data and not a learned success rate',
        'Ranking tests a fixed candidate set, not full CEM optimization',
        'Pixel error may reflect background; object ROI is evaluator-only']))
    publish('started')
    # Reuse all saved full-arm prediction panels without recomputing them.
    specs=[dict(model=f'wm-s{s}-full-age{a}',domain=d) for s in range(8) for a in (0,16384,32768,65536)
        for d in ('iid','new_physics','new_layout','occluded','material_shift')]
    def read(spec):
        obj=json.loads(fetch('diagnostics/'+key(spec)+'.json').read_text())
        assert obj['complete'] and obj['spec']==spec and len(obj['rows'])==168
        return obj
    with ThreadPoolExecutor(max_workers=8) as pool:old=list(pool.map(read,specs))
    atomic_json(OUT/'existing_prediction_panels.json',old)
    publish('existing_predictions_downloaded')
    episodes,candidates=generate();publish('new_synthetic_probes_collected')
    pred=[];ranking=[]
    for seed in range(8):
        for age in (0,16384,32768,65536):
            model=load_model(fetch(f'checkpoints/wm-s{seed}-full-age{age}.pt'),cfg,device)
            for i,(ep,truth) in enumerate(episodes):pred+=predictions(model,ep,truth,seed,age,i)
            ranking+=rank(model,candidates,seed,age)
            del model
        atomic_json(OUT/'action_predictions.json',pred);atomic_json(OUT/'candidate_ranking.json',ranking)
        publish('evaluated_seed_'+str(seed))
    # Compact descriptive summary. Replicates remain separately stored for paired analysis.
    summary={}
    for age in (0,16384,32768,65536):
        summary[str(age)]={}
        for horizon in (8,32,64):
            rr=[r for r in ranking if r['age']==age and r['horizon']==horizon]
            pp=[r for r in pred if r['age']==age and r['horizon']==horizon]
            oldrows=[r for panel in old for r in panel['rows'] if r['age']==age and r['horizon']==horizon]
            summary[str(age)][str(horizon)]=dict(
                ranking_n=len(rr),rank_correlation=float(np.mean([r['rank_correlation'] for r in rr if r['rank_correlation'] is not None])),
                distance_advantage_over_uniform=float(np.mean([r['distance_advantage_over_uniform'] for r in rr])),
                action_object_mse={v:float(np.mean([r['object_mse'] for r in pp if r['action_variant']==v])) for v in ('actual','zero','reversed')},
                new_persistence_object_mse=float(np.mean([r['persistence_object_mse'] for r in pp])),
                existing_object_mse=float(np.mean([r['rgb_object_mse'] for r in oldrows])),
                existing_persistence_object_mse=float(np.mean([r['persistence_object_mse'] for r in oldrows])))
    atomic_json(OUT/'summary.json',summary);publish('completed')

if __name__=='__main__':
    try:
        with torch.inference_mode():main()
    except Exception as e:
        atomic_json(OUT/'error.json',dict(type=type(e).__name__,message=str(e)))
        try:publish('error')
        except Exception as upload_error:print('ERROR_REPORT_UPLOAD_FAILED',type(upload_error).__name__,flush=True)
        raise
