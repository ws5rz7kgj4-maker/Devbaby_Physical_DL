"""Small training-path diagnostic, not a formal generalization experiment."""
import os,json,time,hashlib,zipfile,copy
from pathlib import Path
from dataclasses import replace
import numpy as np
import torch
from huggingface_hub import HfApi,hf_hub_download
from devbaby.wm_model import WorldModel
from devbaby.wm_config import WMConfig
from devbaby.wm_data import Replay
from devbaby.wm_numeric import optimizer_update
from devbaby.utils import atomic_json
import audit

def balanced_loss(pred,target,previous):
    # Image-only changed regions, no simulator object labels.
    change=(target-previous).abs().mean(1,keepdim=True)>.03
    error=(pred-target).square().mean(1,keepdim=True)
    n=change.sum((1,2,3));bg=(~change).sum((1,2,3))
    foreground=(error*change).sum((1,2,3))/n.clamp_min(1)
    background=(error*(~change)).sum((1,2,3))/bg.clamp_min(1)
    return torch.where(n>0,.5*(foreground+background),background).mean()

class BalancedWorldModel(WorldModel):
    def loss(self,b):
        cfg=self.cfg;h=self.initial(len(b['rgb']),b['rgb'].device)
        with torch.no_grad():
            for t in range(cfg.burn_in):
                if t:h=self.prior(h,b['actions'][:,t-1])
                h=self.observe(h,b['rgb'][:,t],b['audio'][:,t],b['proprio'][:,t])
        rec=[];one=[];latents=[];anchor=None
        for t in range(cfg.burn_in,cfg.burn_in+cfg.train_steps):
            prior=self.prior(h,b['actions'][:,t-1]);h=self.observe(prior,b['rgb'][:,t],b['audio'][:,t],b['proprio'][:,t]);latents.append(h)
            if anchor is None:anchor=h
            for state,losses in ((h,rec),(prior,one)):
                rgb,body=self.decode(state)
                losses.append(balanced_loss(rgb,b['rgb'][:,t],b['rgb'][:,t-1])+torch.nn.functional.mse_loss(body,b['proprio'][:,t]))
        h=anchor;multi=[];start=cfg.burn_in
        for k in range(1,cfg.unroll+1):
            h=self.prior(h,b['actions'][:,start+k-1])
            if k in {1,2,4,8,16,32,cfg.unroll}:
                rgb,body=self.decode(h)
                multi.append(balanced_loss(rgb,b['rgb'][:,start+k],b['rgb'][:,start])+torch.nn.functional.mse_loss(body,b['proprio'][:,start+k]))
        r=torch.stack(rec).mean();o=torch.stack(one).mean();m=torch.stack(multi).mean()
        spread=torch.relu(.1-torch.stack(latents,1).flatten(0,1).std(0,unbiased=False)).mean()
        return r+o+m+.01*spread,dict(reconstruction=r.detach(),one_step=o.detach(),multi_step=m.detach())

def main():
    api=HfApi();out=Path('output');out.mkdir(exist_ok=True);start=time.time()
    output_repo='swenlio/devbaby-control-audit-results';source_repo='swenlio/devbaby-worldmodel-results'
    rev=api.repo_info(source_repo,repo_type='dataset').sha;datarev=api.repo_info(output_repo,repo_type='dataset').sha
    prefix=os.environ['BASELINE_PREFIX'];cfg=replace(WMConfig(),batch_size=4,amp=False);device='cuda'
    assert torch.cuda.is_available();torch.set_num_threads(4)
    # Loss sanity checks before any training budget is consumed.
    x=torch.zeros(2,6,4,4,device=device);y=torch.ones_like(x)
    assert torch.allclose(balanced_loss(y,x,x),torch.tensor(1.,device=device))
    assert balanced_loss(x,x,x)==0
    sparse=x.clone();sparse[:,:,0,0]=1
    assert torch.allclose(balanced_loss(x,sparse,x),torch.tensor(.5,device=device))
    def publish(phase):
        atomic_json(out/'status.json',dict(phase=phase,elapsed_s=time.time()-start,training_performed=True,development_only=True))
        api.upload_folder(repo_id=output_repo,repo_type='dataset',folder_path=str(out),path_in_repo=prefix,commit_message='Baseline learning diagnostic '+phase)
        print('BASELINE_PHASE',phase,flush=True)
    atomic_json(out/'protocol.json',dict(version='baseline-check-v1',source_revision=rev,data_revision=datarev,
        training_episodes=[0,1,2,3],development_validation_episodes=[4,5,6,7],
        treatments=['original','change_balanced'],updates=200,initial_model_seed=0,precision='fp32',
        limitations=['One model seed and four training scenes only','Development data already inspected; not a formal test',
        'No task success claim','Changed-image regions may include hand or pointer, not only objects'],
        purpose='Check training path and whether uniform pixel loss overlooks sparse changes'))
    publish('started')
    source='runs/worldmodel-dacc6ff327cf/checkpoints/'
    checkpoints={}
    for age in (0,65536):
        p=hf_hub_download(source_repo,source+f'wm-s0-full-age{age}.pt',repo_type='dataset',revision=rev)
        checkpoints[age]=torch.load(p,map_location='cpu',weights_only=False)
    initial=checkpoints[0]['model'];trained=checkpoints[65536]['model']
    changes={}
    for group in ('encoder','dynamics','filter','image_start','image_decoder','body_decoder'):
        keys=[k for k in initial if k.startswith(group+'.')]
        delta=sum(float((trained[k]-initial[k]).square().sum()) for k in keys)
        norm=sum(float(initial[k].square().sum()) for k in keys)
        changes[group]=dict(delta_l2=delta**.5,relative_l2=(delta/max(norm,1e-20))**.5)
    trace=checkpoints[65536]['trace']
    atomic_json(out/'old_training_audit.json',dict(parameter_changes=changes,committed_updates=checkpoints[65536]['update'],trace_head=trace[:4],trace_tail=trace[-4:]))
    p=hf_hub_download(output_repo,'audits/frozen-control-v1-ba8f8d332928/new_diagnostic_recordings.zip',repo_type='dataset',revision=datarev)
    with zipfile.ZipFile(p) as z:
        for name in z.namelist():
            if name.startswith('prediction-'):
                assert '..' not in Path(name).parts and not Path(name).is_absolute()
                z.extract(name,'data')
    paths=[Path('data')/f'prediction-{i}' for i in range(8)]
    replay=Replay(paths[:4],capacity=4);evaluations=[];traces=[]
    for treatment in ('original','change_balanced'):
        model=(WorldModel if treatment=='original' else BalancedWorldModel)(cfg).to(device)
        model.load_state_dict(initial);optimizer=torch.optim.AdamW(model.parameters(),lr=cfg.learning_rate,weight_decay=1e-5)
        scaler=torch.amp.GradScaler('cuda',enabled=False);rng=np.random.default_rng(314159)
        for update in range(201):
            if update in (0,50,200):
                model.eval()
                for i,path in enumerate(paths):
                    with np.load(path/'observations.npz') as z:ep={k:z[k] for k in z.files}
                    with np.load(path/'annotations/truth.npz') as z:truth={k:z[k] for k in z.files}
                    for row in audit.predictions(model,ep,truth,0,update,i):
                        evaluations.append(dict(**row,treatment=treatment,split='train' if i<4 else 'development_validation'))
                atomic_json(out/'evaluations.json',evaluations);atomic_json(out/'training_trace.json',traces)
                torch.save(dict(model=model.state_dict(),config=cfg.asdict(),update=update,treatment=treatment),out/f'{treatment}.pt')
                publish(treatment+'_update_'+str(update))
            if update==200:break
            batch=replay.sample(cfg,'full',rng,device);result=optimizer_update(model,optimizer,scaler,batch)
            traces.append(dict(treatment=treatment,update=update+1,sample_ids=batch['sample_ids'],**result))
    # Batch identities must match, so changes in data draws cannot explain the comparison.
    a=[r['sample_ids'] for r in traces if r['treatment']=='original'];b=[r['sample_ids'] for r in traces if r['treatment']=='change_balanced'];assert a==b
    summary=[]
    for treatment in ('original','change_balanced'):
        for update in (0,50,200):
            for split in ('train','development_validation'):
                for horizon in (1,8,32,64):
                    rows=[r for r in evaluations if r['treatment']==treatment and r['age']==update and r['split']==split and r['horizon']==horizon]
                    summary.append(dict(treatment=treatment,update=update,split=split,horizon=horizon,
                        object_mse={v:float(np.mean([r['object_mse'] for r in rows if r['action_variant']==v])) for v in ('actual','zero','reversed')},
                        rgb_mse=float(np.mean([r['rgb_mse'] for r in rows if r['action_variant']=='actual'])),
                        persistence_object_mse=float(np.mean([r['persistence_object_mse'] for r in rows]))))
    atomic_json(out/'summary.json',summary);publish('completed')

if __name__=='__main__':main()
