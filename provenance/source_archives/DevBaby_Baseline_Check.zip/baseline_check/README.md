# Baseline training-path diagnostic

This is a small development diagnostic, not the formal exploration/genera­lization experiment.

Checks parameter changes and first/last training losses in the original seed-0
checkpoint, then compares two randomly initialized models with identical weights
and identical batches for 200 FP32 updates each. Both retain original architecture,
proprioceptive loss and temporal horizons. Original loss is compared with a
changed-image balanced loss. The latter gives equal weight to changed and unchanged
pixels, using RGB differences only; no simulator labels enter training.

Four existing synthetic development episodes train the models; four distinct
episodes provide development validation. These scenes were previously inspected,
so they are not untouched formal test data. Evaluate at updates 0/50/200 for
actual/zero/reversed actions at horizons 1/8/32/64. Preserve raw per-episode metrics,
matched batch identities, training traces and checkpoints. Truth masks are used
only by the evaluator. Single model seed, no inferential or task-success claim.

Output uses the private swenlio/devbaby-control-audit-results repository, whose
write/read path already passed CPU preflight. The initial source upload must
succeed before reading checkpoints or training. Runs on one L4, maximum 30 minutes.

Dependencies: torch 2.6.0, numpy 1.26.4, scipy 1.13.1, Pillow 10.4.0,
pybullet 3.2.7, espeakng-loader 0.2.4, huggingface_hub 0.36.0.
Set HF_TOKEN securely and BASELINE_PREFIX to a new path, then run python check.py.
Source checkpoint and recording revisions are pinned at start.
