# Method and interpretation

This is an independently initialized, fully synthetic study. It is not a continuation of the old body-prediction checkpoints and does not change an existing cloud job. The JSON protocol is locked by source and protocol hashes when the user launches. It is not a claim of registration with a public preregistration service.

## Questions and estimands

The principal outcome is final physical task success on independent simulated scenes. Developmental age means the number of random motor interactions made available to training, not language proficiency or biological age. Curves measure success at four fixed ages; consecutive differences divided by interaction count measure growth, including negative growth. The adaptation study measures additional learning in a new dynamics distribution at four fixed budgets. Initial and mature models get the same new experiences and number of updates. Higher starting performance can create ceiling effects; adaptation slopes therefore must be read alongside absolute success.

Six two-sided primary comparisons are fixed before final evaluation: full minus silent, shuffled, impact-only, and speech-only audio; 64-step minus 8-step planning; world-model planner minus hindsight goal-conditioned behavior cloning. Audio comparisons average the fixed audio tasks/domains. Planning comparisons average the fixed long tasks/domains. Behavior-cloning comparisons average the fixed `bc_tasks` / `bc_domains`. All use the mature checkpoint and 24 scenes per domain/task with eight training seeds. A family with missing required cells is not silently reduced: Holm-adjusted inference is withheld. Learning, adaptation, prediction, acute audio intervention and feasibility analyses are descriptive/secondary, not additional uncorrected primary claims.

The 95% intervals use a crossed bootstrap: resample model seeds and resample scenes within each fixed domain/task stratum, preserving method pairing. Domain/task strata are fixed and equally weighted; the inference does not sample arbitrary task families. Exact two-sided sign randomization operates on the eight seed-level paired effects (256 assignments); Holm correction covers all six primary tests. These are modest-sample experiments and power is not guaranteed. Never treat individual frames as independent model seeds. The bootstrap intervals are pointwise, not simultaneous confidence bands. A first observed 50% stage is a coarse, potentially noisy crossing, not an exact sample-complexity estimate.

## Environment and data

The embodiment is one force-controlled sphere with a near-contact fixed-joint grasp mechanism, grip command, and yaw command. A bounded torque servo stabilizes roll/pitch and follows yaw. Position commands accumulate within x [-0.1,1.1], y [-0.62,0.62], z [0.045,1.1] metres. The expanded target-height range lets the force servo support heavier objects despite static spring deflection. These mechanisms are programmed embodiment assumptions. No articulated fingers, walking, spontaneous symbolic thought or consciousness is tested.

Objects are randomized rigid balls, boxes and cylinders with unique visible colors within a scene. Material affects synthesized impact resonances and physical mass/friction/restitution; material is not assigned a unique visual texture. The new-physics condition shifts gravity, hand mass/gains, object mass and motor delay. Layout adds a previously unseen obstacle arrangement; occlusion overlays a fixed opaque camera region; material shift changes masses/frictions. These are distribution shifts within PyBullet, not a new simulation engine or real-world transfer. No soft-body, fluid or deformable-material generalization is claimed. Compositional goals rearrange familiar primitive shapes; they do not demonstrate arbitrary novel objects.

Training exploration is correlated random motor babbling: sampled workspace destinations and gripper states, independent of object labels and future goals. All main arms share the exact recorded episodes and the same initial weights and sampler draws per seed. Data may be generated before optimization for efficiency; replay access is restricted to the current interaction prefix. The first main update follows one full block. Adaptation first collects two episodes before updating; a donor episode for shuffled audio is always distinct. Every episode retains RGB, issued actions, proprioception, mixed/impact/speech log-mel features, three-channel raw WAV, scene properties, per-step labels and utterance transcripts. Transcripts and physical labels are audit-only. Exploration contact/grasp/motion coverage is measured, not assumed.

Speech is eSpeak NG formant synthesis, not pretrained neural TTS; impacts are analytic damped oscillations. English templates, referent, voice, timing, pitch and speed are randomly sampled with consistent scene-property meanings. Unrestricted independent random words would remove the association the experiment is intended to test. The learner never gets words, a tokenizer, transcripts or pretrained features. A visible caregiver marker remains in every arm, so the audio intervention estimates benefit conditional on those visual cues. Speech timing can move that visible marker; future exogenous marker motion is not action-determined and can contribute irreducible full-frame prediction error. Physics diagnostics also report object-region image errors.

## Architecture and training

A CNN encodes the two camera images concatenated as six channels. A second CNN encodes a 32×16 past-interval log-mel patch. Proprioception and embeddings feed a GRU observation update. An action-conditioned GRU transition forms the open-loop prior. Decoders reconstruct both images and ten proprioceptive channels. All parameters are randomly initialized. Losses combine filtered reconstruction, next-step prediction and open-loop predictions at geometrically spaced horizons up to 32 steps. Image losses are weighted by raw image motion, never by simulator segmentation labels. A small latent spread penalty discourages collapse. No reward objective, object label loss, policy oracle or speech transcript loss is used.

The five trained arms have identical model dimensions and image/body objectives. Only their audio input differs. Shuffled audio comes from a distinct recorded episode at an independently sampled offset; it is not a circular shift of the same episode that might expose future events. Acute silence/donor tests change the mature full model's input without retraining and are reported separately from trained ablations. Identical numbers of updates do not imply identical realized FLOPs or convergence.

At checkpoints, an independently trained hindsight behavior-cloning baseline uses current sensory history and a future image from the same random trajectory as a goal, predicting the observed action. It uses neither demonstrations nor task labels. Its update budget and physical experience budget match a world-model arm, but its objective and per-update compute differ. It is a reasonable baseline implementation, not a reproduction of a named published benchmark.

## Planning and task scoring

The learned planner receives only current sensory observations and a final two-view goal image with change weights derived from current/goal pixels. The simulator generates desired end poses but does not provide their coordinates, task name or hand path to the planner. A CEM search optimizes motor chunks, each repeated four steps. It replans after four real steps. Horizons 8/32/64 use `floor(2048/horizon)` candidates and three iterations, equalizing the nominal number of latent transitions per iteration. Longer plans have fewer candidates and more action variables; comparison is budget-constrained, not pure horizon isolation or exact FLOP matching. Imagined rollouts call only the action transition, never future observations, future audio or a simulator.

Final success requires all specified objects within 0.075 m of their target for the last three steps. Lift additionally requires holding the selected object; other tasks require release; stacking additionally requires physical contact between the two designated objects. Distances, ever-success and time to first three-step success are secondary diagnostics. Task order is fixed; scenarios are seeded independently of model seed, arm and horizon to preserve pairing. Evaluation experiences are never added to training replay.

The privileged engineering reference can inspect object states, mass, action-delay queue and goals and use hand-coded waypoints. It is used only as a feasibility reference. It is not an optimal oracle and is never used as a demonstration, target or policy component. Poor reference performance is reported, not used to filter test scenes. Developmental mechanical checks use a separate namespace and cannot establish that all held-out tasks are feasible. Geometrically colliding relocation endpoints are rejected during deterministic goal construction before any policy is evaluated.

## Physics prediction diagnostics

The world model itself predicts images and proprioception. To ask whether its latent future carries object information, the model is frozen and ridge readouts are fitted on a separate IID random-experience split. Targets are color-indexed object position, rotation matrix, linear/angular velocity, presence and ten contacts. These labels train **only the posthoc readout**; neither planner nor world-model optimizer receives it. The readout maps action-only future latent states into physical estimates at 1,2,4,8,16,32,64 steps; extrapolation beyond the 32-step training horizon is explicit.

Readout errors conflate representation, dynamics and decoder calibration. Current-observation probe errors are therefore reported alongside future errors. Rotation estimates are projected to SO(3) by SVD before angular error calculation. Presence/contact Brier scores and contact true/false positives/negatives retain class-prevalence information. Full-frame and object-region image MSE are compared against image persistence. Position error is compared with privileged ground-truth persistence and constant-velocity extrapolation, which have stronger initial-state information than the latent probe. Those are diagnostic references, not fair end-to-end pixel-agent baselines. The fit is IID-only; OOD readout error can indicate probe extrapolation failure rather than a unique failure of learned dynamics.

All model training, adaptation and readout fitting finishes before final prediction/physical evaluation begins. Age curves are retrospectively evaluated from immutable saved checkpoints; no test result selects a checkpoint. Source edits after seeing results require a fresh run and namespace if confirmatory claims are desired.

## Persistence and compute

The local launcher uses public Hugging Face Hub APIs, a private result dataset and a pinned source archive. A durable local submission record precedes paid-job submission; unresolved responses are reconciled by job labels and are never automatically retried. A job has a 24-hour service timeout and 23-hour cooperative budget including most setup work. Further jobs require the user's explicit `resume` command.

Checkpoints preserve model, optimizer, AMP scaler and Python/NumPy/Torch/CUDA/sampler RNG state. CPU interruption equivalence is tested. GPU kernels and platform/library changes may still affect bitwise reproducibility; runtime versions are recorded. Data precedes checkpoints in upload order; state and its file index are published together last. Resume selects the last full publication commit rather than a partially uploaded repository HEAD. A hard kill may lose unuploaded updates, and an unfinished physical panel is redone on a new worker. Storage and evaluation cost are substantial; `plan` reports exact scheduled counts without submitting a job.

### Numerical repair before final evaluation (2026-10-24)

The original CUDA run terminated on a nonfinite gradient before formal evaluation.
This revision imports only its checksum-verified seed-0 raw training experience,
reinitializes all learners, and uses a new source hash/run ID. The protocol and
simulator are unchanged. No old optimizer, learned checkpoint, or test result is
merged. Import provenance pins the original completed publication commit.

Every learner uses a fixed recovery policy: up to eight FP16 attempts on the
same batch with GradScaler backoff, then one unscaled FP32 attempt; if that also
fails, training stops with diagnostics. Only committed parameter updates count
toward the fixed update budget. Failed attempts preserve the sampled examples
and forward RNG; failed checkpoints roll the sampler back before the pending
draw. Gradient norms use an FP64 reduction before clipping at 10. Per-update
logs retain precision, attempt count, scale and recovery events. This policy can
change wall-clock compute and numerical trajectories, so recovery frequencies
should accompany experiment reporting. It does not change the primary exposure
axis (physical interactions) or the prescribed number of successful updates.

Each GPU worker first tests injected-overflow recovery and the actual formal
model/batch/rollout dimensions using disposable networks and training data only.
Five audio arms receive four test updates each; BC receives two. Their weights
are discarded, RNG is restored and updates are excluded from learning curves.
These checks are engineering gates, not evidence of physical generalization.

## Prior work and dependency documentation

The implementation is inspired by action-conditioned latent dynamics planning; it is not PlaNet, Dreamer or a benchmark reproduction:

- Hafner et al., *Learning Latent Dynamics for Planning from Pixels*: https://arxiv.org/abs/1811.04551
- Hugging Face Jobs configuration: https://huggingface.co/docs/hub/jobs-configuration
- Hugging Face Hub Jobs guide: https://huggingface.co/docs/huggingface_hub/en/guides/jobs

Positive results would support bounded claims about synthetic experience, physical generalization and budget-constrained planning. Null results would still answer those questions if coverage, reference performance, uncertainty and protocol integrity are reported. The implementation does not by itself establish novelty, sufficient statistical power or publication acceptance.
