from pathlib import Path
from types import SimpleNamespace as NS
import io
import json
import zipfile
import pytest
import START as launch
from devbaby.wm_sync import sync_run

def job(id='job1',stage='RUNNING',key=''):
    return NS(id=id,url='https://huggingface.co/jobs/a/'+id,status=NS(stage=stage),labels={'devbaby_wm_key':key},environment={})
class API:
    token='test-not-secret'
    def __init__(self):self.jobs=[];self.runs=[];self.commits=[];self.fail=False
    def create_repo(self,**kwargs):pass
    def repo_info(self,**kwargs):return NS(private=True,sha='revision')
    def file_exists(self,**kwargs):return False
    def list_repo_files(self,**kwargs):return []
    def list_jobs(self,**kwargs):return self.jobs
    def create_commit(self,**kwargs):self.commits.append(kwargs);return NS(oid='frozen-revision')
    def run_job(self,**kwargs):
        self.runs.append(kwargs)
        if self.fail:raise ConnectionError('unknown response')
        j=job(key=kwargs['labels']['devbaby_wm_key']);self.jobs.append(j);return j
    def inspect_job(self,**kwargs):return self.jobs[0]

def test_source_excludes_secrets(tmp_path):
    (tmp_path/'START.py').write_text('pass');(tmp_path/'protocol.json').write_text('{}')
    (tmp_path/'.env').write_text('secret');(tmp_path/'token.txt').write_text('secret');(tmp_path/'results').mkdir();(tmp_path/'results'/'test.py').write_text('secret')
    data,sha=launch.source_bytes(tmp_path)
    with zipfile.ZipFile(io.BytesIO(data)) as z:assert set(z.namelist())=={'START.py','protocol.json'}
    assert launch.source_bytes(tmp_path)[1]==sha

def test_reserved_env_absent():
    env=launch.make_environment('a/r','a','r','sha','m','key');assert not launch.RESERVED.intersection(env)

def test_repeat_launch_reuses_job(tmp_path,monkeypatch):
    monkeypatch.setattr(launch,'ROOT',tmp_path);(tmp_path/'protocol.json').write_text('{}')
    monkeypatch.setattr(launch,'validate_local',lambda:({},'p'));monkeypatch.setattr(launch,'source_bytes',lambda:(b'code','c'*64));monkeypatch.setattr(launch,'show_budget',lambda p:None)
    api=API();args=launch.parser().parse_args([])
    launch.submit(api,'token','a',args);launch.submit(api,'token','a',args)
    assert len(api.runs)==1 and api.runs[0]['timeout']=='24h'
    assert 'token' not in json.dumps(launch.read_json(launch.record_location(args)))

def test_unknown_submission_not_retried(tmp_path,monkeypatch):
    monkeypatch.setattr(launch,'ROOT',tmp_path);(tmp_path/'protocol.json').write_text('{}')
    monkeypatch.setattr(launch,'validate_local',lambda:({},'p'));monkeypatch.setattr(launch,'source_bytes',lambda:(b'code','d'*64));monkeypatch.setattr(launch,'show_budget',lambda p:None)
    api=API();api.fail=True;args=launch.parser().parse_args([])
    with pytest.raises(RuntimeError):launch.submit(api,'token','a',args)
    with pytest.raises(RuntimeError):launch.submit(api,'token','a',args)
    assert len(api.runs)==1

def test_remote_labels_reconcile():
    api=API();api.jobs=[job(key='abc')]
    r=launch.reconcile(api,'a',dict(phase='submitting',submission_key='abc'))
    assert r['job_id']=='job1'

def test_snapshot_publication_order_and_retry(tmp_path):
    (tmp_path/'state.json').write_text('{"status":"running"}')
    ep=tmp_path/'data/train/s0/000000';ep.mkdir(parents=True)
    (ep/'observations.npz').write_bytes(b'data');(ep/'complete.json').write_text('{}')
    checkpoint=tmp_path/'checkpoints';checkpoint.mkdir();(checkpoint/'model.pt').write_bytes(b'weights')
    api=API();sync_run(tmp_path,'a/r','r',api=api)
    paths=[[op.path_in_repo for op in c['operations']] for c in api.commits]
    assert paths[-1]==['runs/r/state.json','runs/r/.wm_sync_index.json']
    assert next(i for i,x in enumerate(paths) if 'runs/r/data/train/s0/000000/observations.npz' in x)<next(i for i,x in enumerate(paths) if 'runs/r/checkpoints/model.pt' in x)
    count=len(api.commits);sync_run(tmp_path,'a/r','r',api=api);assert len(api.commits)==count

def test_incomplete_episode_not_uploaded(tmp_path):
    (tmp_path/'state.json').write_text('{}');ep=tmp_path/'data/train/s0/000000';ep.mkdir(parents=True);(ep/'observations.npz').write_bytes(b'partial')
    api=API();sync_run(tmp_path,'a/r','r',api=api)
    assert not any('/data/' in op.path_in_repo for c in api.commits for op in c['operations'])

def test_code_change_blocks_resume(tmp_path,monkeypatch):
    monkeypatch.setattr(launch,'ROOT',tmp_path);args=launch.parser().parse_args(['resume'])
    record=tmp_path/'r.json';launch.save_record(record,dict(result_repo='a/r',run_id='r',code_sha256='old',protocol_sha256='p'))
    monkeypatch.setattr(launch,'validate_local',lambda:({},'p'));monkeypatch.setattr(launch,'source_bytes',lambda:(b'new','new'))
    with pytest.raises(RuntimeError,match='Code/protocol changed'):launch.submit(API(),'token','a',args,True)

def test_resume_uses_completed_publication(tmp_path,monkeypatch):
    monkeypatch.setattr(launch,'ROOT',tmp_path);(tmp_path/'protocol.json').write_text('{}')
    monkeypatch.setattr(launch,'validate_local',lambda:({},'p'));monkeypatch.setattr(launch,'source_bytes',lambda:(b'code','e'*64));monkeypatch.setattr(launch,'show_budget',lambda p:None)
    api=API();args=launch.parser().parse_args([]);launch.submit(api,'token','a',args)
    api.jobs[0].status.stage='COMPLETED'
    api.list_repo_commits=lambda **kw:[NS(title='partial checkpoint upload',commit_id='unsafe'),NS(title='WorldModel worldmodel-'+('e'*12)+': publish state and file index',commit_id='safe')]
    seen=[]
    monkeypatch.setattr(launch,'inspect_resume_output',lambda api,repo,runid,rev:(seen.append(rev) or True,{'status':'paused'}))
    launch.submit(api,'token','a',args,True)
    assert seen==['safe'] and len(api.runs)==2
    manifest=json.loads(api.commits[-1]['operations'][1].path_or_fileobj)
    assert manifest['resume_revision']=='safe'

def test_restore_rejects_corrupt_checkpoint(tmp_path,monkeypatch):
    import hashlib
    import cloud
    import huggingface_hub
    prefix='runs/run/';index=tmp_path/'index.json'
    index.write_text(json.dumps(dict(repo='a/r',run_id='run',files={'checkpoints/x.pt':{'bytes':4,'sha256':hashlib.sha256(b'good').hexdigest()}})))
    monkeypatch.setattr(huggingface_hub,'hf_hub_download',lambda *a,**kw:str(index))
    def download(*args,**kwargs):
        p=Path(kwargs['local_dir'])/prefix/'checkpoints/x.pt';p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b'evil')
    monkeypatch.setattr(huggingface_hub,'snapshot_download',download)
    with pytest.raises(ValueError,match='checksum mismatch'):
        cloud.restore(dict(resume_has_output=True,result_repo='a/r',resume_revision='pinned',run_id='run'),tmp_path/'output')
