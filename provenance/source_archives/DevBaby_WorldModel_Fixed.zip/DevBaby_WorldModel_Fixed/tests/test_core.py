from pathlib import Path
from dataclasses import replace
import copy
import importlib.util
import json
import zipfile
import io
import numpy as np
import pytest
import torch
from devbaby.wm_config import WMConfig,load_protocol
from devbaby.wm_data import Replay,image_tensor,choose_audio
from devbaby.wm_model import WorldModel
from devbaby.wm_control import LatentPlanner
from devbaby.wm_world import PhysicalWorld,collect_episode,target_goal,Recorder,SENSORY_KEYS
from devbaby.audio import Speech
from devbaby.wm_eval import rotation_error,state_metrics,beliefs,load_episode
from devbaby.wm_report import holm,paired_inference,report
from devbaby.wm_plan import evaluation_plan,model_id
from devbaby.wm_train import train_series

ROOT=Path(__file__).parents[1]
torch.set_num_threads(2)
@pytest.fixture
def cfg():return WMConfig(hidden=16,audio_dim=8,batch_size=2,burn_in=2,train_steps=2,unroll=4,episode_steps=16,blocks=1,episodes_per_block=2,updates_per_block=2,planning_budget=32,planning_iterations=1,action_repeat=2,task_steps=8,amp=False)
@pytest.fixture
def episodes(tmp_path,cfg):
    speech=Speech(tmp_path/'speech');paths=[]
    for seed in [21,42]:
        path=tmp_path/'train'/str(seed);collect_episode(cfg,speech,path,seed);paths.append(path)
    return paths

def test_raw_schema_and_audio(episodes,cfg):
    from scipy.io import wavfile
    ep=load_episode(episodes[0]);assert set(ep)==SENSORY_KEYS
    assert ep['rgb'].shape==(17,2,64,64,3);assert ep['actions'].shape==(16,5)
    sr,wave=wavfile.read(episodes[0]/'audio.wav');assert sr==16000 and wave.shape==(32000,3)
    assert np.any(wave[:,2]);assert (episodes[0]/'annotations/truth.npz').exists()
    assert np.isfinite(ep['audio']).all()

def test_audio_mixture_alignment(episodes):
    from scipy.io import wavfile
    _,w=wavfile.read(episodes[0]/'audio.wav');w=w.astype(float)
    # int16 quantization and mixture clipping produce <=2 integer LSB discrepancy
    assert np.quantile(np.abs(w[:,0]-np.clip(w[:,1]+w[:,2],-32768,32767)),.99)<=2

@pytest.mark.parametrize('arm',['full','silent','impact_only','speech_only','shuffled'])
def test_replay_boundary_and_donor(episodes,cfg,arm):
    r=Replay(episodes);b=r.sample(cfg,arm,np.random.default_rng(12),'cpu')
    assert b['rgb'].shape==(2,7,6,64,64)
    if arm=='silent':assert b['audio'].abs().sum()==0
    for row,ids in zip(b['audio'],b['sample_ids']):
        i,start,j,dstart,g=ids;assert i!=j and g>start+cfg.burn_in
        if arm=='shuffled':assert np.array_equal(row[:,0].numpy(),r.get(j)['audio'][dstart:dstart+7])
    assert not any('truth' in str(k) for k in b)

def test_same_sampling_across_arms(episodes,cfg):
    a=Replay(episodes).sample(cfg,'full',np.random.default_rng(7),'cpu')
    b=Replay(episodes).sample(cfg,'shuffled',np.random.default_rng(7),'cpu')
    assert a['sample_ids']==b['sample_ids'];assert torch.equal(a['rgb'],b['rgb'])

def test_learner_rejects_truth_keys(episodes,tmp_path):
    p=tmp_path/'bad';p.mkdir();e=load_episode(episodes[0]);e['state']=np.zeros(1);np.savez(p/'observations.npz',**e)
    with pytest.raises(ValueError):Replay([p,p]).get(0)

def test_future_observation_does_not_change_prefix(cfg,episodes):
    model=WorldModel(cfg).eval();e=load_episode(episodes[0]);donor=load_episode(episodes[1]);a=beliefs(model,e,'full','cpu',donor)
    future={k:v.copy() for k,v in e.items()};future['rgb'][8:]=0;future['audio'][8:]=100;future['proprio'][8:]=100
    b=beliefs(model,future,'full','cpu',donor);assert np.array_equal(a[:8],b[:8])

def test_loss_backward_and_long_prior(cfg,episodes):
    model=WorldModel(cfg);b=Replay(episodes).sample(cfg,'full',np.random.default_rng(9),'cpu')
    loss,_=model.loss(b);loss.backward();assert torch.isfinite(loss)
    assert all(torch.isfinite(p.grad).all() for p in model.parameters() if p.grad is not None)
    h=model.initial(1,'cpu')
    for _ in range(64):h=model.prior(h,torch.zeros(1,5))
    image,body=model.decode(h);assert image.shape==(1,6,64,64) and body.shape==(1,10)

def test_image_channel_layout():
    x=np.zeros((2,64,64,3),np.uint8);x[1,:,:,0]=255;t=image_tensor(x)
    assert t[3].sum()==4096 and t[:3].sum()==0

def test_pose_rotation_metrics():
    eye=np.eye(3).reshape(9);rot=np.diag([-1,-1,1]).reshape(9)
    assert rotation_error(eye,eye)<1e-5;assert rotation_error(rot,eye)==pytest.approx(180)

def test_planner_public_interface(cfg,episodes):
    model=WorldModel(cfg);ep=load_episode(episodes[0]);obs={k:v[0] for k,v in ep.items() if k!='actions'}
    goal={'rgb':ep['rgb'][-1],'weights':np.ones((2,64,64),np.float32)}
    planner=LatentPlanner(model,cfg,goal,'full',8,1)
    a=planner(obs);assert a.shape==(5,) and np.max(np.abs(a))<=1
    assert planner.transitions==cfg.planning_iterations*(cfg.planning_budget//8)*8
    assert not any(k in vars(planner) for k in ('world','task','targets','truth'))

def test_goal_restore_and_truth_separation(cfg,tmp_path):
    with PhysicalWorld(cfg,Speech(tmp_path/'speech'),13,n_objects=3,task='arrange_3') as w:
        before=w.observe()['rgb'];g,t=target_goal(w,'arrange_3');after=w.observe()['rgb']
        assert np.array_equal(before,after);assert set(g)=={'rgb','weights'};assert not np.array_equal(g['rgb'],before)
        assert 'targets' in t

def test_plan_pairing():
    p,_=load_protocol(ROOT/'protocol.json');rows=evaluation_plan(p)
    assert len(rows)==len(set(rows));assert all(s['trials']>=12 for s in rows.values())
    assert len(p['primary_family'])==6

def test_holm_and_paired_bootstrap():
    assert np.allclose(holm([.01,.04,.03]),[.03,.06,.06])
    r=paired_inference(np.ones((8,2,10)),100,np.random.default_rng(1));assert r['effect']==1 and r['ci_low']==1
    assert r['p']==2/256

def test_checkpoint_resume_exact(cfg,episodes,tmp_path):
    p=json.loads((ROOT/'smoke_protocol.json').read_text());p['ages']=[0,32]
    class Callback:
        device=torch.device('cpu')
        def __call__(self,*args,**kwargs):pass
    clean=tmp_path/'clean';resumed=tmp_path/'resume';calls=[0]
    train_series(cfg,p,clean,0,'full','wm',episodes,Callback(),lambda:None)
    def stop():
        calls[0]+=1
        if calls[0]==2:raise InterruptedError()
    with pytest.raises(InterruptedError):train_series(cfg,p,resumed,0,'full','wm',episodes,Callback(),stop)
    train_series(cfg,p,resumed,0,'full','wm',episodes,Callback(),lambda:None)
    a=torch.load(clean/'checkpoints/wm-s0-full/training.pt',weights_only=False)
    b=torch.load(resumed/'checkpoints/wm-s0-full/training.pt',weights_only=False)
    assert a['trace']==b['trace']
    for k in a['model']:assert torch.equal(a['model'][k],b['model'][k])

def test_partial_report_withholds(tmp_path):
    p=json.loads((ROOT/'smoke_protocol.json').read_text());(tmp_path/'protocol.lock.json').write_text(json.dumps(p))
    s=report(tmp_path);assert not s['all_evaluations_complete'] and not s['primary_family_complete']

def test_failed_batch_is_replayed_after_resume(cfg,episodes,tmp_path,monkeypatch):
    import devbaby.wm_train as train
    p=json.loads((ROOT/'smoke_protocol.json').read_text());p['ages']=[0,32]
    class Callback:
        device=torch.device('cpu')
        def __call__(self,*args,**kwargs):pass
    clean=tmp_path/'clean';resumed=tmp_path/'resume'
    train_series(cfg,p,clean,0,'full','wm',episodes,Callback(),lambda:None)
    original=train.optimizer_update;seen=[]
    def fail(model,opt,scaler,batch,*args,**kwargs):
        seen.append(batch['sample_ids'])
        if len(seen)==1:raise FloatingPointError('Injected failure after sampler advanced')
        return original(model,opt,scaler,batch,*args,**kwargs)
    monkeypatch.setattr(train,'optimizer_update',fail)
    with pytest.raises(FloatingPointError):
        train_series(cfg,p,resumed,0,'full','wm',episodes,Callback(),lambda:None)
    failed=torch.load(resumed/'checkpoints/wm-s0-full/training.pt',weights_only=False)
    assert failed['update']==0 and not failed['trace']
    train_series(cfg,p,resumed,0,'full','wm',episodes,Callback(),lambda:None)
    a=torch.load(clean/'checkpoints/wm-s0-full/training.pt',weights_only=False)
    b=torch.load(resumed/'checkpoints/wm-s0-full/training.pt',weights_only=False)
    assert seen[0]==seen[1] and a['trace']==b['trace']
    assert all(torch.equal(a['model'][k],b['model'][k]) for k in a['model'])
