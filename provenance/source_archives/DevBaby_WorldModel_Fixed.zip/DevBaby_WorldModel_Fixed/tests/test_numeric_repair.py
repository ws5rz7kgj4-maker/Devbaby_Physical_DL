import copy
import hashlib
import json
from pathlib import Path
from types import SimpleNamespace as NS
import numpy as np
import pytest
import torch
import START as launch
from devbaby.wm_numeric import optimizer_update,clip_finite_gradients
from devbaby.wm_preflight import overflow_probe,OverflowProbe
from devbaby.wm_repair import (selected_files,validate_source,restore_experience,
                              SOURCE_RUN,SOURCE_CODE,SOURCE_PROTOCOL,EPISODE_FILES,fingerprint)


def test_scaler_overflow_is_retried_and_not_counted():
    r=overflow_probe(torch.device('cpu'))
    assert r['events'][0]['scale']==65536 and r['scale']==32768


def test_persistent_amp_failure_falls_back_once_on_same_batch():
    m=OverflowProbe('cpu');opt=torch.optim.AdamW(m.parameters(),lr=.01)
    scaler=torch.amp.GradScaler('cpu');calls=[0]
    def poison(g):
        calls[0]+=1
        return g*float('inf') if calls[0]<=8 else g
    m.weight.register_hook(poison)
    result=optimizer_update(m,opt,scaler,{})
    assert result['precision']=='fp32' and result['attempts']==9
    assert len(result['events'])==8 and int(opt.state[m.weight]['step'])==1
    assert torch.isfinite(m.weight).all()


def test_fp32_failure_does_not_mutate_parameters_or_optimizer():
    m=OverflowProbe('cpu');before=m.weight.detach().clone()
    opt=torch.optim.AdamW(m.parameters());scaler=torch.amp.GradScaler('cpu')
    m.weight.register_hook(lambda g:g*float('inf'))
    with pytest.raises(FloatingPointError,match='FP32 retry also failed'):
        optimizer_update(m,opt,scaler,{})
    assert torch.equal(m.weight,before) and not opt.state
    assert m.weight.grad is None


def test_bad_inputs_fail_before_optimizer_update():
    m=OverflowProbe('cpu');opt=torch.optim.AdamW(m.parameters())
    with pytest.raises(FloatingPointError,match='Non-finite input: rgb'):
        optimizer_update(m,opt,torch.amp.GradScaler('cpu'),{'rgb':torch.tensor([float('nan')])})
    assert not opt.state


def test_large_finite_gradients_are_clipped_without_zeroing():
    m=OverflowProbe('cpu');m.weight.grad=torch.full_like(m.weight,1e30)
    norm=clip_finite_gradients(m)
    assert np.isfinite(norm) and norm>1e29
    assert float(m.weight.grad)==pytest.approx(10.,rel=1e-5)


def test_retry_preserves_stochastic_forward_rng():
    class Stochastic(OverflowProbe):
        def __init__(self):super().__init__('cpu');self.draws=[]
        def loss(self,b):
            x=torch.rand(4);self.draws.append(x.clone())
            loss=(self.weight*x).square().mean();return loss,{}
    m=Stochastic();opt=torch.optim.SGD(m.parameters(),lr=.01);calls=[0]
    def poison(g):
        calls[0]+=1
        return g*float('inf') if calls[0]==1 else g
    m.weight.register_hook(poison)
    optimizer_update(m,opt,torch.amp.GradScaler('cpu'),{})
    assert len(m.draws)==2 and torch.equal(*m.draws)


def source_fixture():
    files={f'data/train/s0/{i:06d}/{s}':{'bytes':1,'sha256':hashlib.sha256(b'x').hexdigest()}
           for i in range(512) for s in EPISODE_FILES}
    files['checkpoints/wm-s0-full/training.pt']={'bytes':4,'sha256':'ignored'}
    files['speech/test.wav']={'bytes':1,'sha256':hashlib.sha256(b'x').hexdigest()}
    return dict(repo='swenlio/devbaby-worldmodel-results',run_id=SOURCE_RUN,files=files)


def test_import_rejects_incomplete_or_evaluated_sources():
    index=source_fixture();identity=dict(code_sha256=SOURCE_CODE,protocol_sha256=SOURCE_PROTOCOL)
    args=(identity,dict(status='error',phase='training'),index['repo'],SOURCE_RUN,SOURCE_PROTOCOL)
    validate_source(index,*args)
    assert all(not n.startswith('checkpoints/') for n in selected_files(index))
    index['files']['fit_seal.json']={}
    with pytest.raises(ValueError,match='evaluation'):validate_source(index,*args)
    del index['files']['fit_seal.json'];del index['files']['data/train/s0/000511/audio.wav']
    with pytest.raises(ValueError,match='incomplete'):validate_source(index,*args)


@pytest.mark.parametrize('corrupt',[False,True])
def test_import_checks_bytes_and_copies_no_weights(tmp_path,monkeypatch,corrupt):
    import huggingface_hub
    index=source_fixture();identity=dict(code_sha256=SOURCE_CODE,protocol_sha256=SOURCE_PROTOCOL)
    values={'.wm_sync_index.json':index,'identity.json':identity,'state.json':dict(status='error',phase='training')}
    for name,obj in values.items():(tmp_path/name).write_text(json.dumps(obj))
    def get(repo,filename,**kwargs):
        assert kwargs['revision']=='pinned';return str(tmp_path/Path(filename).name)
    def download(repo,**kwargs):
        assert kwargs['revision']=='pinned'
        for name in kwargs['allow_patterns']:
            p=Path(kwargs['local_dir'])/name;p.parent.mkdir(parents=True,exist_ok=True)
            p.write_bytes(b'y' if corrupt and name.endswith('/000005/observations.npz') else b'x')
    monkeypatch.setattr(huggingface_hub,'hf_hub_download',get)
    monkeypatch.setattr(huggingface_hub,'snapshot_download',download)
    spec=dict(repo=index['repo'],run_id=SOURCE_RUN,revision='pinned',index_fingerprint=fingerprint(index))
    manifest=dict(data_import=spec,protocol_sha256=SOURCE_PROTOCOL,resume=False)
    out=tmp_path/'output'
    if corrupt:
        with pytest.raises(ValueError,match='checksum mismatch'):restore_experience(manifest,out,tmp_path/'cache')
        assert not list(out.rglob('complete.json'))
    else:
        restore_experience(manifest,out,tmp_path/'cache')
        assert len(list(out.rglob('complete.json')))==512 and not (out/'checkpoints').exists()
        provenance=json.loads((out/'repair_provenance.json').read_text())
        assert provenance['weights_imported'] is False and provenance['imported_transitions']==65536
        restore_experience(dict(manifest,resume=True),out,tmp_path/'cache')


def test_source_check_pins_completed_publication(monkeypatch):
    index=source_fixture();seen=[]
    api=NS(inspect_job=lambda **kw:NS(id='old',url='url',status=NS(stage='ERROR')),
           list_repo_commits=lambda **kw:[NS(title='partial upload',commit_id='unsafe'),
               NS(title=f'WorldModel {SOURCE_RUN}: publish state and file index',commit_id='safe')])
    def get(api,repo,path,revision):
        seen.append(revision)
        if path.endswith('/identity.json'):return dict(code_sha256=SOURCE_CODE,protocol_sha256=SOURCE_PROTOCOL)
        if path.endswith('/state.json'):return dict(status='error',phase='training')
        return index
    monkeypatch.setattr(launch,'remote_json',get)
    spec=launch.repair_source(api,'swenlio',SOURCE_PROTOCOL)
    assert spec['revision']=='safe' and set(seen)=={'safe'}


def test_unsafe_import_path_is_rejected():
    index=source_fixture();index['files']['../outside']={}
    with pytest.raises(ValueError,match='Unsafe'):selected_files(index)

def test_repair_submission_preserves_provenance_on_resume(tmp_path,monkeypatch):
    # No network or paid execution: use the launcher API double.
    from test_launcher import API
    monkeypatch.setattr(launch,'ROOT',tmp_path);(tmp_path/'protocol.json').write_text('{}')
    monkeypatch.setattr(launch,'validate_local',lambda:({},'p'))
    monkeypatch.setattr(launch,'source_bytes',lambda:(b'code','f'*64))
    monkeypatch.setattr(launch,'show_budget',lambda p:None)
    spec=dict(repo='swenlio/devbaby-worldmodel-results',revision='pinned',run_id=SOURCE_RUN)
    monkeypatch.setattr(launch,'repair_source',lambda *args:spec)
    api=API();args=launch.parser().parse_args(['repair'])
    first=launch.submit(api,'token','swenlio',args)
    launch.submit(api,'token','swenlio',args)
    assert len(api.runs)==1 and first['data_import']==spec
    api.jobs[0].status.stage='ERROR'
    api.list_repo_commits=lambda **kw:[NS(title=f'WorldModel {first["run_id"]}: setup',commit_id='setup')]
    monkeypatch.setattr(launch,'inspect_resume_output',lambda *args:(True,{'status':'setup'}))
    resumed=launch.submit(api,'token','swenlio',launch.parser().parse_args(['resume']),True)
    assert len(api.runs)==2 and resumed['data_import']==spec

def test_source_validation_failure_never_submits_job(tmp_path,monkeypatch):
    from test_launcher import API
    monkeypatch.setattr(launch,'ROOT',tmp_path);(tmp_path/'protocol.json').write_text('{}')
    monkeypatch.setattr(launch,'validate_local',lambda:({},'p'))
    monkeypatch.setattr(launch,'source_bytes',lambda:(b'code','f'*64))
    def fail(*args):raise ValueError('Incomplete source')
    monkeypatch.setattr(launch,'repair_source',fail)
    api=API()
    with pytest.raises(ValueError,match='Incomplete source'):
        launch.submit(api,'token','swenlio',launch.parser().parse_args(['repair']))
    assert not api.runs and not api.commits

def test_nonfinite_forward_never_becomes_an_update():
    class BadLoss(OverflowProbe):
        def loss(self,b):return self.weight.sum()*float('nan'),{}
    m=BadLoss('cpu');opt=torch.optim.AdamW(m.parameters())
    with pytest.raises(FloatingPointError,match='FP32 retry also failed'):
        optimizer_update(m,opt,torch.amp.GradScaler('cpu'),{})
    assert float(m.weight)==1 and not opt.state
