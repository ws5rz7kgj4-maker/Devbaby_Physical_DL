"""Reproducible full-dimension engineering check; no final-evaluation data.

python -m tests.verify_formal_numeric is not required: run this file from the
project root with PYTHONPATH=. and --output /temporary/directory.
CPU FP16 is a numerical-path check, not validation of CUDA kernels.
"""
import argparse
import json
from pathlib import Path
import time
import numpy as np
import torch
from devbaby.wm_config import load_protocol
from devbaby.wm_world import collect_episode
from devbaby.audio import Speech
from devbaby.wm_data import Replay
from devbaby.wm_train import make_model
from devbaby.wm_numeric import optimizer_update
from devbaby.wm_preflight import overflow_probe


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--output',required=True)
    parser.add_argument('--device',default='cpu')
    args=parser.parse_args();root=Path(args.output);root.mkdir(parents=True,exist_ok=True)
    p,cfg=load_protocol(Path(__file__).parents[1]/'protocol.json')
    device=torch.device(args.device);torch.set_num_threads(4)
    paths=[];speech=Speech(root/'speech')
    for seed in [78131,78132]:
        path=root/f'episode-{seed}';collect_episode(cfg,speech,path,seed,split='engineering_numeric')
        paths.append(path)
    replay=Replay(paths);results=[];start=time.monotonic()
    for amp in [False,True]:
        model=make_model(cfg,123456,'wm',device)
        opt=torch.optim.AdamW(model.parameters(),lr=cfg.learning_rate,weight_decay=1e-5)
        scaler=torch.amp.GradScaler(device.type,enabled=amp)
        rng=np.random.default_rng(819)
        for step in range(2):
            batch=replay.sample(cfg,'full',rng,device)
            result=optimizer_update(model,opt,scaler,batch)
            assert all(torch.isfinite(v).all() for v in model.state_dict().values())
            results.append(dict(requested_amp=amp,step=step+1,**result))
            print(json.dumps(results[-1]),flush=True)
        del batch,model,opt,scaler
    report=dict(device=str(device),torch=torch.__version__,cuda_available=torch.cuda.is_available(),
                config=cfg.asdict(),results=results,overflow_probe=overflow_probe(device),
                elapsed_seconds=time.monotonic()-start,formal_performance_evidence=False)
    (root/'formal_numeric.json').write_text(json.dumps(report,indent=2))
    print('VERIFIED '+str(root/'formal_numeric.json'))


if __name__=='__main__':main()
