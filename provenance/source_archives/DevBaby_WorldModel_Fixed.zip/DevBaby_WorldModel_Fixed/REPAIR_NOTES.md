# 2026-10-24 数值修复版

这份完整代码修复 `FloatingPointError: Non-finite gradient` 的退出处理。
原失败作业：`swenlio/6adc0292046eb82b1ecd8fed`。
原运行：`worldmodel-fd0f484f6879`。原运行和检查点保留，不覆盖。

## 在 Mac 启动

将 `DevBaby_WorldModel_Fixed.zip` 放入“下载”目录，运行：

```bash
unzip -o "$HOME/Downloads/DevBaby_WorldModel_Fixed.zip" -d "$HOME/Downloads"
python3 "$HOME/Downloads/DevBaby_WorldModel_Fixed/START.py" repair
```

第二行才会提交一个付费 L4 作业。修复包本身不会启动作业。重复同一命令会复用已记录的作业；提交响应不确定时不自动重试。没有自动续跑。保持完整目录及其启动记录，不要只复制单个 Python 文件。

`repair` 会在提交前检查原账号、原作业已结束、协议和代码身份、完整数据清单，并固定到最后一次完整发布的提交。云端会验证所有导入文件的 SHA-256。

复用第 0 个种子已采集的 **512 段经历、65,536 次交互**，包含图像、动作、声音和独立标注。其它种子仍按原协议采集。为了避免旧检查点已经推进的抽样状态污染实验，这次**重新随机初始化模型并从第一个训练批次开始**，不导入旧权重和优化器；不是从旧优化步数接着算。新版本从自身检查点恢复时则保留权重、优化器、缩放器和随机状态。

## 训练数值规则

所有声音条件和行为克隆使用同一条预先固定规则：

1. 遇到 FP16 非有限梯度，让 GradScaler 跳过更新并降低缩放值。
2. 重试同一批数据；不会另抽样、不会增加成功更新计数。
3. 最多尝试 8 次 FP16，仍不稳定时对同一批数据尝试一次 FP32。
4. FP32 仍失败则保存诊断并退出；不会伪造已完成的更新或悄悄丢弃样本。
5. 梯度范数用 FP64 归约后裁剪，避免有限梯度的平方求和本身溢出。
6. 异常保存的随机状态位于未提交批次的抽样之前，恢复后重新获得该批次。

每次成功更新的 `trace[].numerical` 记录精度、尝试次数、缩放值、梯度范数和回退事件；`diagnostics/numerics-*.json` 保存最近的异常批次信息。应在结果分析中报告回退次数，不能把它们当作额外学习步数。FP16/FP32 混合回退可能影响计算时间与数值轨迹；主要学习速度指标仍按真实交互次数计算。

## GPU 启动自检

每个新云端作业正式训练前，用一次性模型执行：

- 注入一次无穷大梯度，确认只发生一次有效更新。
- 使用正式网络规模、batch=8、burn-in=8、预测展开=32，五个声音条件各完成 4 次更新，行为克隆完成 2 次更新。
- 检查参数有限，保存 `gpu_preflight.json`。自检网络随后丢弃，不计入正式曲线。

自检只使用训练数据，恢复保存的全局随机状态，不使用测试集选参数。通过自检不保证整个长期实验不会出错。此修复包的本地验证使用 CPU；CUDA 自检结果须以你启动后的报告为准。

## 查进度与暂停后继续

```bash
python3 "$HOME/Downloads/DevBaby_WorldModel_Fixed/START.py" status
python3 "$HOME/Downloads/DevBaby_WorldModel_Fixed/START.py" logs
python3 "$HOME/Downloads/DevBaby_WorldModel_Fixed/START.py" download
```

只有当新版本的作业已经结束，而实验 `state.json` 为 `paused` 时，再明确提交下一次作业：

```bash
python3 "$HOME/Downloads/DevBaby_WorldModel_Fixed/START.py" resume
```

若状态为 `error`，先查看 `failure.txt` / `gpu_preflight.json`，不要盲目续跑。每个显式作业最多 24 小时，程序通常在约 23 小时保存暂停。完整正式研究可能需要多个作业；平台显示 COMPLETED 不等于研究全部完成，研究完成标志是 `state.status == "complete"`。

## 研究身份与数据隔离

`protocol.json` 保持原字节内容，环境、任务、种子、数据预算、评测和统计规则不变。修复发生在正式评测前；保留原随机场景命名空间以复用已收集的经验，但源码哈希和新运行 ID 均改变。`repair_provenance.json` 记录来源提交和数据导入事实。旧版结果不与新运行合并；原有代码/协议变更保护继续生效，不绕过哈希检查。

主模型依然只读取感觉输入白名单。真值标注仅用于诊断和评测。修复成功、loss 有限或者自检通过，均不代表已经获得物理泛化能力。

实现依据：PyTorch 官方 AMP 文档的 `unscale_`、`step` 和 `update` 约定：
https://docs.pytorch.org/docs/2.6/notes/amp_examples.html
