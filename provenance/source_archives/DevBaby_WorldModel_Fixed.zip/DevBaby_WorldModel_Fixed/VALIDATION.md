# Numerical repair validation — 2026-10-24

Verified locally on Linux, Python 3.11.17, PyTorch 2.6.0+cpu, NumPy 1.26.4 and the pinned runtime dependencies. No GPU was available and no paid job was submitted while preparing this repair.

- **44 tests passed.** The original 29 tests still pass. Added tests cover real CPU GradScaler overflow/backoff, one committed update after retries, bounded FP32 fallback, fatal FP32 failure without parameter mutation, finite input checks, stable gradient clipping, RNG-preserving retries, exact failed-batch replay after checkpoint resume, data-only migration, checksum corruption, unsafe paths, source publication pinning, no submission on invalid source, and repair provenance across explicit resume.
- **Formal model dimensions checked on CPU in both FP32 and FP16:** hidden=192, batch=8, burn-in=8, train_steps=16, unroll=32. Two actual simulated development episodes were used. Two updates in each precision completed with finite losses and parameters. These CPU checks do not reproduce L4 CUDA kernels or establish the exact original overflow cause.
- **Complete development smoke workflow passed after the repair:** all five audio arms, BC, adaptation, probes, prediction and all 48 physical panels. This uses tiny budgets; it is not a formal capability result.
- Exact CPU pause/resume and a failure after sampling were checked for matching successful-batch identities, traces and final model tensors.
- A new cloud worker automatically tests an injected-overflow recovery, followed by disposable formal-dimension models for every audio arm and BC. Those CUDA tests are **not yet executed**. Their actual results will appear in `gpu_preflight.json` after the user launches the job.

Repair evidence is in `verification/repair/`. Older evidence under `verification/` and `PREVIOUS_VALIDATION.md` belongs to the original release and is retained as historical context. Formal experiment success, learning speed, CUDA stability over the full run and total runtime/cost remain unmeasured by these engineering tests.
