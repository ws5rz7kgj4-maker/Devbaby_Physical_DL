# DevBaby WorldModel — 2026-10-24 数值修复版

这是从零初始化、全模拟数据的世界模型研究代码。主结果是**未见物理条件中的操作成功率、随交互经验增加的进步，以及新环境中的学习速度**。语音识别准确率不是主指标。本项目不以意识作为可测量结论。

**当前这份是完整修复包。** `repair` 会复用旧失败运行的第 0 种子 512 段原始经历，重新随机初始化模型，创建独立新运行。旧运行保持不变。详见 [REPAIR_NOTES.md](REPAIR_NOTES.md)。

## Mac：直接启动 Hugging Face GPU

把完整 ZIP 下载到“下载”目录，然后在终端逐行运行（不用手动进入某个目录，不用自己建虚拟环境）：

```bash
unzip -o "$HOME/Downloads/DevBaby_WorldModel_Fixed.zip" -d "$HOME/Downloads"
python3 "$HOME/Downloads/DevBaby_WorldModel_Fixed/START.py" repair
```

需要 Python 3.10 或更新版本；建议 Mac 安装 Python 3.11。启动器自动建立只含 Hugging Face 客户端的独立环境，已有 HF 登录会复用；没有登录才进入登录流程。Mac 不安装 PyTorch、不本地训练。账号需要可用的 HF Jobs GPU 配额、余额以及相应 token 权限。

默认使用 **1 张 L4（l4x1）**，一个作业最多 24 小时，程序在约 23 小时保存并暂停。**完整实验不保证一个作业跑完；没有自动续费、自动重提或自动启动第二个作业。** 默认结果仓库 `你的账号/devbaby-worldmodel-results`，与之前实验独立。

先看精确工作量、暂不创建付费作业：

```bash
python3 "$HOME/Downloads/DevBaby_WorldModel_Fixed/START.py" plan
```

正式配置：8 个训练种子，5 个重新训练的声音条件；每个种子 65,536 次共同的随机物理交互。四个发展阶段为 0 / 16,384 / 32,768 / 65,536。共有 1,762 个物理评测组，31,152 次任务试验；每次固定 128 个控制步，不按成功提前停止。多数时间可能花在反复规划和物理评测上，实际速度以云 GPU 日志为准。不要把小规模代码测试的运行时间当成正式实验时间。

查看状态、查看日志、手动续跑、下载小体积结果：

```bash
python3 "$HOME/Downloads/DevBaby_WorldModel_Fixed/START.py" status
python3 "$HOME/Downloads/DevBaby_WorldModel_Fixed/START.py" logs
python3 "$HOME/Downloads/DevBaby_WorldModel_Fixed/START.py" resume
python3 "$HOME/Downloads/DevBaby_WorldModel_Fixed/START.py" download
```

`resume` 只在旧作业已结束且实验未完成时提交一个新付费作业。运行中的作业会被复用。不要修改已经启动的代码或协议；恢复会检查哈希。重复输入启动命令不会另开相同作业；网络返回不明时保留启动记录，先执行 `status`，不要换 run ID 绕过检查。

下载包括检查点、原始经历和评测录像数组的全部数据：

```bash
python3 "$HOME/Downloads/DevBaby_WorldModel_Fixed/START.py" download --all
```

停止当前云作业：

```bash
python3 "$HOME/Downloads/DevBaby_WorldModel_Fixed/START.py" cancel
```

主动取消或平台硬中断最多丢失尚未上传的进度。正常时间预算结束会保存并上传。每约 15 分钟执行一次增量上传；完整物理评测组才上传，组内中断时新云机器会重做该组。恢复固定到最后一个完整发布的 Git commit，并核验文件 SHA-256，避免从上传了一半的检查点恢复。

## 这份代码实际做什么

| 项目 | 实现与边界 |
|---|---|
| 数据 | PyBullet 刚体物理；两路 64×64 RGB；动作、本体感受；16 kHz 合成语音/碰撞声；模拟器真值独立保存 |
| 零起点 | 图像、音频、记忆、动力学和行为克隆网络全部随机初始化；不加载语言模型、视觉模型、ASR 或神经 TTS |
| 探索 | 连续随机运动与随机开合抓取；不按物体坐标挑动作，不使用演示或奖励训练 |
| 语言 | 程序随机选择词句、声音和时机；词句与场景属性保持对应，错配声音作为对照。不是每个词完全独立随机、彻底无规律的噪声 |
| 世界模型 | 当前感觉形成递归隐状态；给定动作进行未来 RGB 和本体感受预测；多步训练至 32 步，评测至 64 步 |
| 物体物理 | 冻结模型后，独立标注数据拟合诊断读出，评测位置、旋转、速度、角速度、接触、颜色身份存在性。它们不是主模型训练标签，也不是规划输入 |
| 规划 | 只提供最终目标画面和从画面差异计算的权重；CEM 搜索原始动作块，无任务名称、目标坐标、手工子目标或模拟器真值 |
| 新任务组合 | 移位、抬起、两物体堆叠、两/三物体排列；训练没有任务示范。这里的“新”是随机经历之外的目标组合，不是未知形状或新身体 |
| 声音贡献 | 完整声音、静音、仅碰撞声、仅养育者语音、独立经历错配声音；重新训练对照，另有同一模型推理时去声/错声干预 |
| 长期规划 | 8 / 32 / 64 步；每次 CEM 迭代固定总隐状态转移预算，候选数随长度变化，不宣称精确 FLOP 或搜索难度相同 |
| 学习能力 | 未见动力学下增加 0 / 256 / 1,024 / 4,096 次随机交互；比较零经验模型与成熟模型的成功率及增长速度 |
| 对照 | 同数据目标条件行为克隆、随机动作、使用真值的工程参考控制器；真值参考从不进入训练，也不保证达到最优性能 |

标注与模型输入在文件结构和加载接口中分开。训练器只读取 `observations.npz` 的白名单字段；不读取 transcript、坐标、分割掩码或任务标签。模型可以使用图像中可见的指示标记；声音对照保留相同视觉条件。

这是一个**单模拟器、简化身体的世界模型实验**。固定的近距离抓取机构和姿态伺服属于身体设计，不是模型自己学出的手指动作。它能检验此范围内的预测、规划和泛化，不构成开放世界能力或意识证据。随机探索可能覆盖不足；图像预测也可能变好而操作仍失败。代码不会把这种结果改写为成功。

## 看哪些文件

下载后的命令会打印实际目录，里面的 `report.html` 可以直接双击打开。

- `physical_learning.png`：物理成功率随经验的变化、新物理条件下的适应曲线。
- `curve_intervals.csv`：按任务/条件的成功率与交叉重采样置信区间。
- `learning_speed.csv`、`speed_intervals.csv`：每 1,000 次交互带来的成功率变化；负数表示退步。
- `adaptation_speed.csv`：新环境中的学习速度，按原有经验分别统计。
- `learning_efficiency.csv`：归一化学习曲线面积，以及首次观测到 50% 成功率的阶段；未达到会标记右删失，不伪造时间。
- `contrasts.csv`：预先规定的六个主比较，完整后才进行整个检验族的 Holm 校正。
- `predictions.csv`：1 / 2 / 4 / 8 / 16 / 32 / 64 步物体与画面预测诊断，含保持不动/恒速参考及读出校准误差。
- `coverage_seed*.json`：随机探索中接触、抓取、物体运动的实际覆盖率。
- `property_slices.csv`：按材质、形状、动作延迟分组的探索性成功率和样本数。
- `trial_results.csv`：每个场景成功与否、最终距离、首次连续成功时间、规划转移数和耗时。
- `summary.json`、`state.json`：是否完整、缺哪些比较、现在到哪一阶段。云平台显示 COMPLETED 不等于研究全部完成；必须看 `state.status`。

主成功定义：最后连续三个控制步，所有被要求保留/移动的物体均离目标小于 7.5 cm；抬起必须仍抓住目标，其他任务必须松手，堆叠还必须有上下物体接触。曾经成功与最终成功分开记录。

## 本地开发测试（可选）

启动云实验不需要做下面这些。若要复核代码，建议 Linux / Python 3.11；Python 3.12 的 PyBullet 可能需要本机编译器。

```bash
cd "$HOME/Downloads/DevBaby_WorldModel"
python3 -m pip install torch==2.6.0
python3 -m pip install -r requirements-test.txt
python3 -m pytest -q tests
python3 -m devbaby.wm_run --protocol smoke_protocol.json --output smoke_results --device cpu
```

`smoke_protocol.json` 只验证流程，减少了种子、训练量、任务时长，报告强制标为开发测试并禁止正式显著性结论。它不证明网络具有任务能力。正式运行固定使用 `protocol.json`。

详细方法与限制见 `METHODS.md`，数据字段见 `DATA_SCHEMA.md`，实际验证记录见 `VALIDATION.md`。

完整数据下载后，可以把一个经历目录导出成带声音的双视角 MP4：

```bash
python3 -m devbaby.wm_media --episode /完整路径/data/train/s0/000000 --output episode.mp4
```

评测经历在 `physical_panels/<编号>/sensory.zip` 中，先解压再传入其中的试验目录。视频使用实际记录的合成混合音轨；原始三个音轨仍保留在 WAV 中。
