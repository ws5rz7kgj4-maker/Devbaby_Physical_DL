# Data schema

`data/<split>/s<seed>/<episode>/` contains:

- `observations.npz`: only `rgb` uint8 [T+1,2,64,64,3]; `proprio` float32 [T+1,10]; `audio`, `impact_audio`, `speech_audio` float32 [T+1,32,16]; `actions` float32 [T,5]. `actions[t]` is issued after observation t and generates observation t+1, potentially through the delayed actuator.
- `audio.wav`: 16 kHz int16 [T*2000,3], channels mixture/impacts/speech. Corresponding log-mel features at observation t+1 summarize the preceding interval; initial observation has silent audio. Quantization/clipping can make separately stored channels differ by an LSB after mixing.
- `annotations/truth.npz`: `state` [T+1,4,18] (position3, rotation matrix9, velocity3, angular velocity3); `present` [T+1,4]; `contacts` [T+1,10]; `masks` [T+1,2,64,64]. Color identity follows `COLORS` insertion order in `world.py`; mask 0 is background, 1..4 correspond to that order. Contacts are hand/object4 plus six unordered object pairs.
- `annotations/frames.jsonl`: timestamp, issued/applied action, true bodies, poses, velocities, events, cameras, contacts and language metadata.
- `annotations/scene.json`: material, shape, dimensions, actuator parameters, simulator seed, cameras and utterance records. The learner sees synthesized sound, not text.
- `complete.json`: episode completion marker and identity. Partially recorded episodes are not admitted to cloud publication.

`physical_panels/<hash>/panel.json` stores the exact specification and per-trial results. `sensory.zip` contains all those trials' raw sensory arrays, WAV, labels, target images, private scoring goals and result rows. The zip is not a compressed video; RGB frames preserve the exact observations. No new interaction data is silently discarded because a policy failed. A partial live episode interrupted by timeout is rerun rather than claimed complete.

`checkpoints/<model-id>.pt` is a trusted self-generated PyTorch checkpoint, including optimizer/RNG state. Do not load arbitrary untrusted `.pt` files. World-model IDs encode model seed, arm and experience age. Adaptation checkpoint IDs additionally encode extra interactions. Files below `checkpoints/<series>/training.pt` are mutable resume points; age checkpoints are immutable within a fixed run.

`probes/<model-id>.npz` contains the frozen diagnostic ridge readout normalization and coefficients. `diagnostics/*.json` contains held-out prediction measurements. Probes and annotations are deliberately not imported into `wm_control.py` or `wm_data.py`.

All split seeds derive from a protocol namespace plus purpose, seed and episode index. Physical test scene seeds exclude model seed, arm and planning horizon so comparisons reuse identical initial scenes. Training, probe-fit, prediction, developmental, adaptation-train, adaptation-evaluation, audio-donor and final-test purposes have disjoint seed derivations. Reusing a source seed by a numerical hash collision is extremely unlikely but the system does not claim cryptographic proof of disjoint physical states; randomized physical configurations may overlap in ordinary ways.
