#!/usr/bin/env python3
"""One-command world-model experiment launcher; no local Torch installation.

Only launch/run/repair/resume may create a paid Job. The default is launch. Repeated
commands reuse the recorded Job; uncertain submission outcomes never auto-retry.
Hugging Face tokens remain in the normal HF login cache and Jobs secrets.
"""
from __future__ import annotations

import argparse
from contextlib import contextmanager
import hashlib
import importlib.metadata
import io
import json
import os
from pathlib import Path, PurePosixPath
import re
import shlex
import subprocess
import sys
import time
import zipfile

ROOT = Path(__file__).resolve().parent
LAUNCHER_HUB_VERSION = "1.7.2"  # Adds public Job labels; isolated from runtime 0.36.
IMAGE = "pytorch/pytorch:2.6.0-cuda12.4-cudnn9-devel"
TERMINAL = {"COMPLETED", "ERROR", "CANCELED", "CANCELLED", "DELETED", "TIMEOUT", "TIMED_OUT"}
RESERVED = {"HOME", "PATH", "PORT", "JOB_ID", "HF_JOB_ID", "CPU_CORES", "MEMORY", "ACCELERATOR", "CODEX_HOME"}
REPORT_FILES = ('report.html','summary.json','curves.csv','trial_results.csv','predictions.csv','contrasts.csv',
    'learning_speed.csv','adaptation_speed.csv','physical_learning.png','state.json','protocol.lock.json',
    'runtime.json','failure.txt','plan.json','identity.json','fit_seal.json','repair_provenance.json','gpu_preflight.json',
    'curve_intervals.csv','speed_intervals.csv','learning_efficiency.csv','property_slices.csv',
    *('coverage_seed'+str(i)+'.json' for i in range(8)))
BOOTSTRAP = r"""
import hashlib, os, pathlib, subprocess, sys, zipfile
from huggingface_hub import hf_hub_download
archive=hf_hub_download(os.environ['WM_CODE_REPO'],os.environ['WM_CODE_PATH'],repo_type='dataset',revision=os.environ['WM_CODE_REVISION'])
if hashlib.sha256(pathlib.Path(archive).read_bytes()).hexdigest()!=os.environ['WM_CODE_SHA256']:raise RuntimeError('Source hash mismatch')
root=pathlib.Path('/tmp/devbaby-wm-code');root.mkdir(exist_ok=True)
with zipfile.ZipFile(archive) as z:
    for info in z.infolist():
        if not (root/info.filename).resolve().is_relative_to(root.resolve()) or (info.external_attr>>16)&0o170000==0o120000:raise RuntimeError('Unsafe archive')
    z.extractall(root)
subprocess.run([sys.executable,'-u',str(root/'cloud.py'),'--repo',os.environ['WM_CODE_REPO'],'--manifest',os.environ['WM_MANIFEST_PATH'],'--revision',os.environ['WM_CODE_REVISION']],cwd=root,check=True)
"""

def atomic(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(path.name + f".{os.getpid()}.tmp")
    with tmp.open("w", encoding="utf-8") as f:
        json.dump(value, f, indent=2, ensure_ascii=False)
        f.write("\n"); f.flush(); os.fsync(f.fileno())
    os.replace(tmp, path)


def digest_bytes(data):
    return hashlib.sha256(data).hexdigest()


def read_json(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))


def ensure_launcher_environment():
    """Use an isolated launcher venv but share the existing HF token cache."""
    if sys.version_info[:2] < (3, 10):
        raise RuntimeError("Please install Python 3.11, then run python3 START.py")
    venv = ROOT/".venv-worldmodel-launch"
    python = venv/("Scripts/python.exe" if os.name == "nt" else "bin/python")
    if Path(sys.prefix).resolve() == venv.resolve():
        if importlib.metadata.version("huggingface_hub") != LAUNCHER_HUB_VERSION:
            raise RuntimeError("Launcher dependency changed; recreate .venv-worldmodel-launch")
        return
    if not python.exists():
        subprocess.run([sys.executable, "-m", "venv", str(venv)], check=True)
    check = subprocess.run([str(python), "-c", "from importlib.metadata import version; assert version('huggingface_hub') == " + repr(LAUNCHER_HUB_VERSION)], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    if check.returncode:
        subprocess.run([str(python), "-m", "pip", "install", "--disable-pip-version-check", "huggingface_hub==" + LAUNCHER_HUB_VERSION], check=True)
    raise SystemExit(subprocess.call([str(python), str(Path(__file__).resolve()), *sys.argv[1:]], cwd=ROOT))


def api_client():
    from huggingface_hub import HfApi, get_token
    token = get_token()
    if not token:
        hf = Path(sys.executable).parent/("hf.exe" if os.name == "nt" else "hf")
        subprocess.run([str(hf), "auth", "login"], check=True)
        token = get_token()
    if not token:
        raise RuntimeError("HF login did not produce a token; no Job submitted.")
    return HfApi(token=token), token


def remote_json(api, repo, filename, revision):
    from huggingface_hub import hf_hub_download
    return read_json(hf_hub_download(repo_id=repo, repo_type="dataset", filename=filename,
                                      revision=revision, token=api.token))


def valid_relative(name):
    path = PurePosixPath(name)
    return bool(name) and not path.is_absolute() and ".." not in path.parts and "\\" not in name


@contextmanager
def exclusive_lock(path):
    path = Path(path); path.parent.mkdir(parents=True, exist_ok=True)
    try:
        fd = os.open(path, os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0o600)
    except FileExistsError:
        raise RuntimeError(f"Submission lock exists: {path}. Another terminal may be submitting. Inspect status/HF Jobs before removing a stale lock.") from None
    with os.fdopen(fd, "w") as f:
        f.write(str(os.getpid()))
    try:
        yield
    finally:
        path.unlink(missing_ok=True)


def job_view(job):
    return {"job_id": job.id, "url": job.url,
            "status": getattr(job.status, "stage", str(job.status)).upper()}


def reconcile(api, owner, record):
    if record.get("job_id"):
        return job_view(api.inspect_job(job_id=record["job_id"], namespace=owner))
    if record.get("phase") == "submitting":
        key = record["submission_key"]
        matches = []
        for job in api.list_jobs(namespace=owner):
            labels = getattr(job, "labels", {}) or {}
            env = getattr(job, "environment", {}) or {}
            if labels.get("devbaby_wm_key") == key or env.get("WM_SUBMISSION_KEY") == key:
                matches.append(job)
        if len(matches) == 1:
            return job_view(matches[0])
        if len(matches) > 1:
            raise RuntimeError("More than one Job matched this submission key. Inspect HF Jobs; no new Job submitted.")
        raise RuntimeError("Previous submission outcome is unknown. No automatic retry or new charge was created. Run status again after checking HF Jobs; preserve the local record.")
    return None


def record_location(args, required=True):
    if args.record:
        path = Path(args.record).expanduser().resolve()
    else:
        latest = ROOT/".wm_launch_records/latest.json"
        if not latest.exists():
            if required:
                raise FileNotFoundError("No world-model launch record. Run launch first, or pass --record /absolute/path.json")
            return None
        path = Path(read_json(latest)["record"])
    if required and not path.exists():
        raise FileNotFoundError(path)
    return path


def record_paths(result_repo, run_id):
    directory = ROOT/".wm_launch_records"
    key = digest_bytes((result_repo+"/"+run_id).encode())[:24]
    return directory/f"{key}.json", directory/f"{key}.lock"


def save_record(path, record):
    atomic(path, record)
    atomic(ROOT/".wm_launch_records/latest.json", {"record": str(Path(path).resolve())})


def make_environment(repo, source_path, revision, digest, manifest_path, key):
    env = {"WM_CODE_REPO": repo, "WM_CODE_PATH": source_path,
           "WM_CODE_REVISION": revision, "WM_CODE_SHA256": digest,
           "WM_MANIFEST_PATH": manifest_path, "WM_SUBMISSION_KEY": key,
           "PYTHONUNBUFFERED": "1", "OMP_NUM_THREADS": "4"}
    if RESERVED & set(env):
        raise ValueError("Reserved platform variable in environment")
    return env


def show_job(record):
    value = {k: record[k] for k in ["job_id", "url", "status", "run_id", "result_repo"] if k in record}
    if record.get("result_repo") and record.get("run_id"):
        value["results_url"] = f"https://huggingface.co/datasets/{record['result_repo']}/tree/main/runs/{record['run_id']}"
    print(json.dumps(value, indent=2, ensure_ascii=False))


def download_patterns(base, all_files=False):
    # fnmatch '*' spans '/' on HF; default paths must therefore be exact names.
    return [base+"/*"] if all_files else [base+"/"+name for name in REPORT_FILES]


def inspect_resume_output(api, repo, run_id, revision):
    """A terminal setup failure may safely resume only if its output is empty."""
    prefix = f"runs/{run_id}/"
    if api.file_exists(repo_id=repo, repo_type="dataset", filename=prefix+"state.json", revision=revision):
        state = remote_json(api, repo, prefix+"state.json", revision)
        if not state:
            raise RuntimeError("Uploaded world-model state is empty")
        return True, state
    existing = [name for name in api.list_repo_files(repo_id=repo, repo_type="dataset", revision=revision)
                if name.startswith(prefix)]
    if existing:
        raise RuntimeError("Result files exist without world-model state; refusing to discard possible checkpoints. Inspect the pinned result dataset.")
    return False, {"status": "setup_failed_before_output"}


def submit(api, token, owner, args, resume=False):
    protocol, protocol_sha = validate_local()
    source, code_sha = source_bytes()
    if resume:
        path = record_location(args)
        old = read_json(path)
        result_repo, run_id = old["result_repo"], old["run_id"]
        _, lock = record_paths(result_repo, run_id)
    else:
        result_repo = args.result_repo or f"{owner}/devbaby-worldmodel-results"
        run_id = args.run_id or "worldmodel-" + code_sha[:12]
        path, lock = record_paths(result_repo, run_id)
    if not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9._-]{0,95}", run_id):
        raise ValueError("Invalid run ID")
    with exclusive_lock(lock):
        old = read_json(path) if path.exists() else None
        if old:
            if old.get("code_sha256") != code_sha or old.get("protocol_sha256") != protocol_sha:
                raise RuntimeError("Code/protocol changed since this run was launched. Resume requires the original package; a fresh experiment needs a new --run-id.")
            view = reconcile(api, owner, old)
            if view:
                old.update(view); old["phase"] = "submitted"; save_record(path, old)
                if not resume or view["status"] not in TERMINAL:
                    show_job(old); print("Existing Job reused; no new Job submitted."); return old
            if resume and not view:
                raise RuntimeError("Cannot resume a run with no reconciled original Job")
        elif resume:
            raise RuntimeError("Resume needs a previous launch record")
        if resume:
            commits=api.list_repo_commits(repo_id=result_repo,repo_type='dataset')
            safe=[c for c in commits if c.title in {f'WorldModel {run_id}: publish state and file index',f'WorldModel {run_id}: setup'}]
            result_revision=safe[0].commit_id if safe else api.repo_info(repo_id=result_repo,repo_type='dataset').sha
            resume_has_output, state = inspect_resume_output(api, result_repo, run_id, result_revision)
            if state.get("status") in {"completed", "complete"}:
                print("World-model experiment is complete; no new Job submitted."); return old
            if not resume_has_output:
                print("Previous terminal Job stopped before uploading any run files; explicit resume will retry setup using the same pinned source and run ID.")
            attempt = int(old.get("attempt", 0)) + 1
            flavor = old["flavor"]
        else:
            result_revision = None; resume_has_output = False; attempt = 0; flavor = args.flavor
        data_import = (old or {}).get('data_import') if resume else None
        if args.action == 'repair':
            data_import = repair_source(api, owner, protocol_sha)
        if not flavor.startswith(("t4-", "a10g-", "a100-", "a100x", "l4-", "l4x", "l40s-", "l40sx", "h100-", "h100x")):
            raise ValueError("Choose a GPU flavor; default is one l4x1")
        show_budget(protocol)
        api.create_repo(repo_id=result_repo, repo_type="dataset", private=True, exist_ok=True)
        if not api.repo_info(repo_id=result_repo, repo_type="dataset").private:
            raise RuntimeError("World-model result repository is public. Choose a new private --result-repo.")
        # Remote state blocks overwrites even after losing a local launcher directory.
        if not resume and api.file_exists(repo_id=result_repo, repo_type="dataset", filename=f"runs/{run_id}/state.json"):
            raise RuntimeError("Remote world-model run already exists. Recover its local record and use resume; no overwrite or new Job.")
        submission_key = digest_bytes(f"{result_repo}/{run_id}/{attempt}".encode())[:32]
        # Reconcile remotely before first submit as well (e.g. launcher folder copied).
        for job in api.list_jobs(namespace=owner):
            env = getattr(job, "environment", {}) or {}
            labels = getattr(job, "labels", {}) or {}
            if labels.get("devbaby_wm_key") == submission_key or env.get("WM_SUBMISSION_KEY") == submission_key:
                recovered = {**(old or {}), "run_id": run_id, "result_repo": result_repo,
                             "owner": owner, "code_sha256": code_sha, "protocol_sha256": protocol_sha,
                             "flavor": flavor, "attempt": attempt, "data_import": data_import,
                             "phase": "submitted", "submission_key": submission_key, **job_view(job)}
                save_record(path, recovered); show_job(recovered)
                print("Matching remote Job recovered; no new Job submitted."); return recovered
        manifest = {"schema": "devbaby-worldmodel-launch-v1", "run_id": run_id, "result_repo": result_repo,
                    "code_sha256": code_sha, "protocol_sha256": protocol_sha,
                    "image": IMAGE, "flavor": flavor, "hard_timeout_seconds": 86400,
                    "job_budget_seconds": 82800, "resume": resume, "resume_revision": result_revision,
                    "resume_has_output": resume_has_output,
                    "attempt": attempt, "submission_key": submission_key,
                    "data_import": data_import}
        source_path = f"worldmodel_source/{code_sha}.zip"
        manifest_path = f"launches/{run_id}/attempt_{attempt:03d}.json"
        from huggingface_hub import CommitOperationAdd
        commit = api.create_commit(repo_id=result_repo, repo_type="dataset",
                    operations=[CommitOperationAdd(path_in_repo=source_path, path_or_fileobj=source),
                                CommitOperationAdd(path_in_repo=manifest_path, path_or_fileobj=json.dumps(manifest, indent=2).encode()),
                                CommitOperationAdd(path_in_repo=f"launches/{run_id}/protocol.json", path_or_fileobj=(ROOT/"protocol.json").read_bytes())],
                    commit_message=f"Freeze world-model experiment {run_id} attempt {attempt}")
        env = make_environment(result_repo, source_path, commit.oid, code_sha, manifest_path, submission_key)
        record = {**manifest, "owner": owner, "phase": "submitting", "code_revision": commit.oid,
                  "manifest_path": manifest_path, "source_path": source_path,
                  "previous_jobs": (old or {}).get("previous_jobs", []) + ([old["job_id"]] if resume else [])}
        # Durable state MUST precede the API request (network failure may hide success).
        save_record(path, record)
        command = ["bash", "-lc", "python -m pip install --disable-pip-version-check huggingface_hub==0.36.0 && python -u -c " + shlex.quote(BOOTSTRAP)]
        try:
            job = api.run_job(image=IMAGE, command=command, flavor=flavor, timeout="24h", namespace=owner,
                              env=env, secrets={"HF_TOKEN": token},
                              labels={"devbaby_wm_key": submission_key, "devbaby_run": run_id.replace(".", "-")})
        except Exception as exc:
            # Never print an API exception body: it may contain the submission payload.
            print(f"Submission response unavailable ({type(exc).__name__}). Its outcome may be unknown; no retry was made.")
            print(f"Saved record: {path}\nRun: python3 START.py status")
            raise RuntimeError("Unknown submission outcome; use status reconciliation, not a new run ID") from None
        record.update(job_view(job)); record["phase"] = "submitted"
        save_record(path, record); show_job(record)
        return record


def manage(api, owner, args):
    path = record_location(args)
    record = read_json(path)
    owner = record.get("owner", owner)
    view = reconcile(api, owner, record)
    if not view:
        raise RuntimeError("No submitted Job in launch record")
    record.update(view); record["phase"] = "submitted"; save_record(path, record)
    if args.action == "status":
        show_job(record)
        try:
            revision = api.repo_info(repo_id=record["result_repo"], repo_type="dataset").sha
            state = remote_json(api, record["result_repo"], f"runs/{record['run_id']}/state.json", revision)
            print(json.dumps({"experiment_state": state}, indent=2, ensure_ascii=False))
        except Exception as exc:
            print(f"Experiment state not uploaded/available yet ({type(exc).__name__}).")
    elif args.action == "logs":
        for line in api.fetch_job_logs(job_id=record["job_id"], namespace=owner, follow=args.follow):
            print(line, end="" if str(line).endswith("\n") else "\n", flush=True)
    elif args.action == "cancel":
        if view["status"] in TERMINAL:
            print("Job is already terminal; no cancellation needed.")
        else:
            api.cancel_job(job_id=record["job_id"], namespace=owner)
            print("Cancellation requested. Already-uploaded checkpoints remain available for explicit resume.")
    elif args.action == "download":
        from huggingface_hub import snapshot_download
        repo = record["result_repo"]; base = f"runs/{record['run_id']}"
        revision = api.repo_info(repo_id=repo, repo_type="dataset").sha
        directory = Path(args.output or ROOT/"worldmodel_results").expanduser().resolve()
        # Default intentionally excludes tensors/raw experience; --all includes everything.
        patterns = download_patterns(base, all_files=args.all)
        snapshot_download(repo_id=repo, repo_type="dataset", revision=revision, token=api.token,
                          allow_patterns=patterns, local_dir=str(directory))
        print(f"Downloaded pinned revision {revision} to {directory/base}")

def repair_source(api, owner, protocol_sha):
    from devbaby.wm_repair import SOURCE_RUN,SOURCE_JOB,validate_source,fingerprint
    if owner != 'swenlio':
        raise RuntimeError('This repair imports the failed swenlio experiment; log into that account.')
    job = api.inspect_job(job_id=SOURCE_JOB, namespace=owner)
    if job_view(job)['status'] not in TERMINAL:
        raise RuntimeError('Original Job is still active; no duplicate repair submitted')
    repo = owner+'/devbaby-worldmodel-results'
    safe = [c for c in api.list_repo_commits(repo_id=repo, repo_type='dataset')
            if c.title == f'WorldModel {SOURCE_RUN}: publish state and file index']
    if not safe:
        raise RuntimeError('No completed source publication; no GPU Job submitted')
    revision = safe[0].commit_id
    prefix = 'runs/'+SOURCE_RUN+'/'
    index = remote_json(api, repo, prefix+'.wm_sync_index.json', revision)
    identity = remote_json(api, repo, prefix+'identity.json', revision)
    state = remote_json(api, repo, prefix+'state.json', revision)
    validate_source(index, identity, state, repo, SOURCE_RUN, protocol_sha)
    return dict(schema='devbaby-data-only-repair-v1',repo=repo,run_id=SOURCE_RUN,
                job_id=SOURCE_JOB,revision=revision,index_fingerprint=fingerprint(index),
                source_identity=identity,weights_policy='restart_from_random_initialization')

def source_bytes(root=None):
    root=Path(root or ROOT);buf=io.BytesIO()
    top={'START.py','cloud.py','protocol.json','smoke_protocol.json','requirements-runtime.txt','requirements-launcher.txt'}
    with zipfile.ZipFile(buf,'w',zipfile.ZIP_DEFLATED) as z:
        for f in sorted(root.rglob('*')):
            rel=f.relative_to(root)
            if not f.is_file() or f.is_symlink() or any(x.startswith('.') or x=='__pycache__' for x in rel.parts):continue
            if not (rel.parts[0] in {'devbaby','tests'} and f.suffix=='.py' or len(rel.parts)==1 and (f.name in top or f.suffix=='.md')):continue
            entry=zipfile.ZipInfo(rel.as_posix(),date_time=(2026,1,1,0,0,0));entry.compress_type=zipfile.ZIP_DEFLATED
            z.writestr(entry,f.read_bytes())
    data=buf.getvalue();return data,digest_bytes(data)

def validate_local(root=None):
    root=Path(root or ROOT)
    for name in ('protocol.json','devbaby/wm_run.py','devbaby/wm_report.py','cloud.py','requirements-runtime.txt'):
        if not (root/name).is_file():raise RuntimeError('Incomplete package: '+name)
    for f in [root/'START.py',root/'cloud.py',*sorted((root/'devbaby').glob('*.py'))]:compile(f.read_text(),str(f),'exec')
    from devbaby.wm_config import load_protocol
    p,_=load_protocol(root/'protocol.json')
    return p,digest_bytes((root/'protocol.json').read_bytes())

def experiment_plan(protocol):
    from devbaby.wm_plan import plan_summary
    return plan_summary(protocol)
def show_budget(protocol):
    print(json.dumps(experiment_plan(protocol),indent=2,ensure_ascii=False))
    print('Each explicit launch/resume starts at most one paid 24-hour Job. Full study may require several jobs. No automatic retries.')

def parser():
    p=argparse.ArgumentParser(description='Independent synthetic DevBaby world-model experiment')
    p.add_argument('action',nargs='?',default='launch',choices=['launch','run','repair','plan','check','status','logs','download','cancel','resume'])
    p.add_argument('--result-repo');p.add_argument('--run-id');p.add_argument('--flavor',default='l4x1')
    p.add_argument('--record');p.add_argument('--output');p.add_argument('--follow',action='store_true');p.add_argument('--all',action='store_true')
    return p

def main(argv=None):
    args=parser().parse_args(argv);os.chdir(ROOT)
    if args.action=='plan':
        p,sha=validate_local();_,code=source_bytes()
        print(json.dumps(dict(action='plan_only_no_paid_job',protocol_sha256=sha,code_sha256=code,
            default_run_id='worldmodel-'+code[:12],flavor=args.flavor,plan=experiment_plan(p)),indent=2,ensure_ascii=False));return
    ensure_launcher_environment();api,token=api_client();owner=api.whoami()['name']
    if args.action=='check':
        p,_=validate_local();print('Account:',owner);show_budget(p);print('Check completed. No Job submitted.')
    elif args.action in {'launch','run','repair','resume'}:submit(api,token,owner,args,resume=args.action=='resume')
    else:manage(api,owner,args)

if __name__=='__main__':
    try:main()
    except KeyboardInterrupt:print('Interrupted. Check status before repeating a submission.');raise SystemExit(130)
    except Exception as exc:
        print('ERROR: '+(str(exc) if isinstance(exc,(ValueError,RuntimeError,FileNotFoundError)) else type(exc).__name__),file=sys.stderr)
        raise SystemExit(1)
