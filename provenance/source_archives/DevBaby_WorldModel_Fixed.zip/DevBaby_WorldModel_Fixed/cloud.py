"""Cloud bootstrap; restore a completed publication and verify every file."""
from pathlib import Path,PurePosixPath
import argparse
import hashlib
import json
import os
import subprocess
import sys
import time

ROOT=Path(__file__).resolve().parent

def restore(manifest,out):
    if not manifest.get('resume_has_output'):return
    from huggingface_hub import hf_hub_download,snapshot_download
    repo=manifest['result_repo'];revision=manifest['resume_revision'];prefix='runs/'+manifest['run_id']+'/'
    try:
        index=json.loads(Path(hf_hub_download(repo,prefix+'.wm_sync_index.json',repo_type='dataset',revision=revision)).read_text())
    except Exception:
        # Setup-only commits have no model state. Never hide corruption/network
        # errors if an index exists in the pinned snapshot.
        from huggingface_hub import HfApi
        if HfApi().file_exists(repo,prefix+'.wm_sync_index.json',repo_type='dataset',revision=revision):raise
        names=['state.json','launch_manifest.json']
        index=None
    else:
        if index['repo']!=repo or index['run_id']!=manifest['run_id']:raise ValueError('Wrong resume index')
        names=list(index['files'])
    for name in names:
        path=PurePosixPath(name)
        if path.is_absolute() or '..' in path.parts or '\\' in name:raise ValueError('Unsafe resume path')
    cache=Path('/tmp/devbaby-wm-restore')
    snapshot_download(repo,repo_type='dataset',revision=revision,allow_patterns=[prefix+n for n in names],local_dir=cache,max_workers=4)
    out.mkdir(parents=True,exist_ok=True)
    for name in names:
        source=cache/prefix/name
        if not source.is_file():raise FileNotFoundError(name)
        if index:
            meta=index['files'][name]
            if source.stat().st_size!=meta['bytes'] or sha(source)!=meta['sha256']:raise ValueError('Resume checksum mismatch: '+name)
        destination=out/name;destination.parent.mkdir(parents=True,exist_ok=True);source.replace(destination)
    if index:(out/'.wm_sync_index.json').write_text(json.dumps(index))

def sha(path):
    h=hashlib.sha256()
    with Path(path).open('rb') as f:
        for b in iter(lambda:f.read(1<<20),b''):h.update(b)
    return h.hexdigest()

def main():
    started=time.monotonic();q=argparse.ArgumentParser();q.add_argument('--repo',required=True);q.add_argument('--manifest',required=True);q.add_argument('--revision',required=True);a=q.parse_args()
    from huggingface_hub import hf_hub_download,HfApi
    m=json.loads(Path(hf_hub_download(a.repo,a.manifest,repo_type='dataset',revision=a.revision)).read_text())
    if m['schema']!='devbaby-worldmodel-launch-v1':raise ValueError('Unknown manifest schema')
    if sha(ROOT/'protocol.json')!=m['protocol_sha256']:raise ValueError('Protocol hash mismatch')
    if not (3,10)<=sys.version_info[:2]<=(3,11):raise RuntimeError('Use supplied PyTorch 2.6 CUDA image with Python 3.10/3.11')
    out=Path('/tmp/devbaby-worldmodel-output');restore(m,out);out.mkdir(parents=True,exist_ok=True)
    (out/'launch_manifest.json').write_text(json.dumps(m,indent=2))
    if not (out/'state.json').exists():(out/'state.json').write_text(json.dumps(dict(status='setup',phase='setup')))
    api=HfApi()
    if not m.get('resume'):
        if api.file_exists(m['result_repo'],f'runs/{m["run_id"]}/state.json',repo_type='dataset'):raise RuntimeError('Remote run exists')
        api.upload_folder(repo_id=m['result_repo'],repo_type='dataset',folder_path=out,path_in_repo='runs/'+m['run_id'],allow_patterns=['state.json','launch_manifest.json'],commit_message=f'WorldModel {m["run_id"]}: setup')
    subprocess.run([sys.executable,'-m','pip','install','--disable-pip-version-check','-r',str(ROOT/'requirements-runtime.txt')],check=True)
    import torch
    if not torch.cuda.is_available():raise RuntimeError('GPU unavailable in paid worker; refusing CPU formal run')
    from devbaby.wm_repair import restore_experience
    restore_experience(m,out)
    from devbaby.wm_run import run
    remaining=m['job_budget_seconds']-(time.monotonic()-started)
    if remaining<60:raise RuntimeError('Setup exhausted time budget; no training started')
    run(ROOT/'protocol.json',out,'cuda',remaining,m['result_repo'],m['run_id'])
if __name__=='__main__':main()
