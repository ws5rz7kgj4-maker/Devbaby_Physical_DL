# DevBaby 补充实验包

这个包检验的是**新物理情境中的任务成功率、随经验增长的表现，以及适应新环境时的进步或退步**。复用原实验的模型与模拟记录，补做机制诊断、明确动作历史基线、适应策略对照和新场景测试。所有新经验仍由模拟器和程序语音生成。

这是一套固定的补充实验，不保证结果一定支持假说，也不保证一次 24 小时云任务内完成。到时间上限保存状态，由你决定是否续跑。不会自动再开付费任务。

## Mac 上启动

下载 `DevBaby_Supplement.zip` 到「下载」文件夹，然后把下面两行复制进终端。无需先进入目录，也无需手工安装 PyTorch。

```bash
unzip -o "$HOME/Downloads/DevBaby_Supplement.zip" -d "$HOME/Downloads"
python3 "$HOME/Downloads/DevBaby_Supplement/SUPPLEMENT.py"
```

第一行解压；第二行会创建独立启动环境、复用已有 Hugging Face 登录、查找并验证原实验数据，然后提交一台 GPU 的任务。默认 `t4-small`，单次云任务硬上限 24 小时，程序约 23 小时到期后保存退出，为同步预留时间。**第二行会产生 Hugging Face GPU 费用。** 请在 HF 账户中保证有 Jobs 权限、合适的写入 token 和余额。

程序不会重新训练原来的 Baby 模型；新的动作历史基线会从随机参数开始训练。原模型或原始训练数据不全时会明确报错，不会偷偷改成重新训练或缩减实验。

如果你想先看计划、核验原文件而不启动 GPU：

```bash
python3 "$HOME/Downloads/DevBaby_Supplement/SUPPLEMENT.py" plan
python3 "$HOME/Downloads/DevBaby_Supplement/SUPPLEMENT.py" check
```

`plan` 完全本地运行；`check` 只登录及读取 HF。若自动查找不到原数据仓库，显式指定：

```bash
python3 "$HOME/Downloads/DevBaby_Supplement/SUPPLEMENT.py" --source-repo swenlio/原结果仓库名
```

不要把上面的占位仓库名直接复制执行。也不要把 token 发到聊天里。

## 查看、下载、续跑

```bash
python3 "$HOME/Downloads/DevBaby_Supplement/SUPPLEMENT.py" status
python3 "$HOME/Downloads/DevBaby_Supplement/SUPPLEMENT.py" logs --follow
python3 "$HOME/Downloads/DevBaby_Supplement/SUPPLEMENT.py" download
```

下载结果默认在解压目录的 `supplement_results/runs/实验编号/`。主要看 `report.html`、`summary.json`、`curves.csv`、`contrasts.csv`。需要全部原始声音、视觉记录、轨迹和模型时使用 `download --all`。

如果状态为时间上限到达或云任务中断，使用同一个未修改的解压包：

```bash
python3 "$HOME/Downloads/DevBaby_Supplement/SUPPLEMENT.py" resume
```

`resume` 在确认旧任务已结束、已有保存状态后才提交新的付费任务。重复普通启动命令会显示已有任务，不会重复提交。若提交时网络断开，先运行 `status` 核对；程序保留提交记录，不能在结果不明时自动重试。需要主动停止时执行 `cancel`。

## 固定研究设计

完整参数在 `supplement_protocol.json`，执行前会与代码、原数据版本一起固定。

| 问题 | 实验 |
|---|---|
| 训练后是否进步 | 0、16,384、32,768 次原始交互的模型，在新验证场景比较成功率 |
| 是否能适应新物理条件 | 新动力学、固定延迟 3 步和 6 步；额外经验 0、128、512、2,048 次 |
| 哪种更新方式更好 | 不更新、原学习率全更新、十分之一学习率、只更新世界记忆及预测头、50% 旧经验回放、动作历史基线 |
| 是否忘记旧任务 | 适应后重新在独立的原分布场景测 reach/touch/grasp-lift |
| 延迟强度如何影响成功率 | 同一组初始场景上比较 0、1、2、3、4、6 步延迟；8 Hz 时分别为 0、0.125、0.25、0.375、0.5、0.75 秒 |
| 是否能处理新任务 | 推物体到目标区域，在新的支撑台面及多种物理条件下测试 |
| 退步可能来自哪里 | 训练片段记忆重置、动作时间对齐、参数/梯度变化、一至八步预测误差与旧任务保持 |

8 个原训练种子全部保留。主要适应对照使用成熟模型；原始全更新同时测较早年龄。动作历史基线使用相同原始经验、相同更新次数，但传感输入、参数数量和有效预测目标数不同，会在结果中披露。

验证每个任务/条件使用 12 个新场景；封存最终测试使用 32 个新场景，跨模型和方法配对。场景随机种子与模型种子独立；固定延迟强度比较共享初始场景。重复条件能共享完全相同模型和控制器的物理轨迹时复用记录，不重复消耗控制计算。

主要统计是最终适应预算下的物理成功率，任务和物理条件等权；6 个预先指定对比统一进行 Holm 校正。区间同时重采样模型种子和场景，避免把同一模型的多次试验当成独立模型。其他机制或阶段性观察按探索性结果解释。样本量是固定预算选择，不是事先功效分析的结论。

正式计划记录 4,918 个条件单元；去重后执行 3,550 个物理面板，共 59,360 次任务试验。新增 151,552 次优化更新和 49,152 次模拟训练交互。`plan` 会显示详细计数；这些是工作量，不是运行时长或显著性保证。

## 文件和解释边界

- `SUPPLEMENT.py`：Mac/终端入口，管理 HF 任务。
- `supplement_cloud.py`：固定版本下载、完整性验证和云端恢复。
- `devbaby/supplement.py`：训练、诊断、封存测试、续跑总流程。
- `devbaby/supplement_world.py`：模拟世界、动作队列、场景及属性标注。
- `devbaby/supplement_control.py`：原控制器兼容扩展和明确动作历史基线。
- `devbaby/supplement_learning.py`：适应对照和预测诊断。
- `devbaby/supplement_report.py`：统计分析、成功率曲线和报告。
- `tests/test_supplement_*.py`：新增检查；原实验测试也保留。
- `SUPPLEMENT_METHODS.md`：方法定义、解释限制和复现细节。
- `LEGACY_*.md`、`formal_protocol.json`：原版本说明和协议，仅供追溯；启动补充实验请使用本页命令。

推物体仍在同一个 PyBullet 模拟器内，不是第二个独立模拟平台。任务目标、抓取机制、规划代价和推物体动作分解由实验者提供。声音仍参与原模型的经验，但当前主要假说不是语言理解；本包不能据此证明意识或自主思维。动作历史基线是公开写明的工程对照，不冒充已发表算法的严格复现。研究是否足以投稿，要根据补充实验的实际结果、诊断和目标期刊要求再判断。
