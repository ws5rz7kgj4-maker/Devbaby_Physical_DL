"""Locked, resumable supplemental physical-generalization experiment.

No jobs are submitted by this module. All training completes before final tests.
Simulator annotations are written for auditing but never enter Replay/model input.
"""
import argparse
from dataclasses import asdict, replace
import gc
import hashlib
import json
import math
import os
from pathlib import Path
import random
import shutil
import time
import traceback
import zipfile

import numpy as np
import torch

from .audio import Speech
from .config import Config
from .data import Replay
from .model import Baby
from .supplement_control import HistoryDynamics, history_loss, controller_factory
from .supplement_learning import (configure_adaptation, adaptation_step,
    parameter_hashes, sensory_prediction_diagnostics, temporal_alignment_audit)
from .supplement_world import collect_episode, run_trial
from .utils import atomic_json, derived_seed, seed_all, sha256


def read(path):
    return json.loads(Path(path).read_text())


def digest(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(',', ':')).encode()).hexdigest()


def code_digest():
    root = Path(__file__).resolve().parent.parent
    files = sorted([*root.glob('devbaby/*.py'), root/'supplement_cloud.py'])
    return digest({str(p.relative_to(root)): sha256(p) for p in files if p.exists()})


class BudgetReached(Exception):
    pass


class BoundedReplay(Replay):
    """Bound RAM cache without changing the uniform sampling population."""
    def __init__(self, *args, cache_size=32, **kwargs):
        self.cache_size = cache_size
        super().__init__(*args, **kwargs)

    def read(self, path):
        result = super().read(path)
        while len(self.cache) > self.cache_size:
            self.cache.popitem(last=False)
        return result


def save_model(path, model, cfg, optimizer=None, replay=None, old_replay=None, **progress):
    kind='history' if isinstance(model,HistoryDynamics) else 'baby'
    if progress.pop('kind',kind)!=kind:raise ValueError('Checkpoint model-kind mismatch')
    value = dict(model=model.state_dict(), config=asdict(cfg),
                 kind=kind,
                 optimizer=optimizer.state_dict() if optimizer is not None else None,
                 replay_rng=replay.rng.bit_generator.state if replay is not None else None,
                 old_replay_rng=old_replay.rng.bit_generator.state if old_replay is not None else None,
                 torch_rng=torch.get_rng_state(), numpy_rng=np.random.get_state(),
                 python_rng=random.getstate(),
                 cuda_rng=torch.cuda.get_rng_state_all() if torch.cuda.is_available() else None,
                 **progress)
    if isinstance(model, HistoryDynamics):
        value.update(history=model.history, width=model.width)
    path = Path(path); path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix('.tmp')
    torch.save(value, temporary); temporary.replace(path)


def restore_rng(ck, replay=None, old_replay=None):
    required = {'torch_rng','numpy_rng','python_rng','cuda_rng'}
    if not required.issubset(ck):
        raise ValueError('Resume checkpoint lacks RNG state')
    if replay is not None and ck.get('replay_rng') is None:
        raise ValueError('Resume checkpoint lacks training replay RNG')
    if old_replay is not None and ck.get('old_replay_rng') is None:
        raise ValueError('Resume checkpoint lacks old replay RNG')
    if replay is not None and ck.get('replay_rng') is not None:
        replay.rng.bit_generator.state = ck['replay_rng']
    if old_replay is not None and ck.get('old_replay_rng') is not None:
        old_replay.rng.bit_generator.state = ck['old_replay_rng']
    torch.set_rng_state(ck['torch_rng'].cpu())
    np.random.set_state(ck['numpy_rng']); random.setstate(ck['python_rng'])
    if torch.cuda.is_available() and ck.get('cuda_rng') is not None:
        torch.cuda.set_rng_state_all([x.cpu() for x in ck['cuda_rng']])


def load_model(path, device):
    # Only trusted checkpoints from the user's pinned source/results repository.
    ck = torch.load(path, map_location=device, weights_only=False)
    cfg = Config(**ck['config']).validate()
    if ck.get('kind') == 'history':
        model = HistoryDynamics(cfg, ck['history'], ck['width']).to(device)
    else:
        model = Baby(cfg).to(device)
    model.load_state_dict(ck['model']); model.eval()
    return model, cfg, ck


def append_training_trace(path, update, samples, stats, **context):
    path = Path(path); path.parent.mkdir(parents=True, exist_ok=True)
    row = dict(update=update, samples=samples, stats=stats, **context)
    with path.open('a', encoding='utf-8') as stream:
        stream.write(json.dumps(row, ensure_ascii=False, allow_nan=False)+'\n')


def trim_training_trace(path, restored_update):
    """Discard uncommitted updates while validating the committed audit chain."""
    path = Path(path)
    if not path.exists():
        if restored_update:
            raise ValueError('Checkpoint exists without its committed training trace')
        return
    temporary = path.with_suffix('.trim.tmp'); last = 0
    try:
        with path.open(encoding='utf-8') as source, temporary.open('w', encoding='utf-8') as target:
            for line in source:
                if not line.strip():continue
                try:row=json.loads(line)
                except json.JSONDecodeError:
                    if not line.endswith('\n'):break  # interrupted final append
                    raise ValueError('Corrupt committed training trace')
                step=row.get('update')
                if not isinstance(step,int) or step!=last+1:
                    raise ValueError('Training trace has duplicate or missing updates')
                last=step
                if step<=restored_update:target.write(line if line.endswith('\n') else line+'\n')
        if last<restored_update:
            raise ValueError('Training trace ends before its checkpoint')
        temporary.replace(path)
    finally:
        if temporary.exists():temporary.unlink()


def validate_resume_checkpoint(ck, cfg, context):
    if ck.get('config') != asdict(cfg) or ck.get('optimizer') is None:
        raise ValueError('Resume checkpoint configuration/optimizer mismatch')
    if any(ck.get(key) != value for key,value in context.items()):
        raise ValueError('Resume checkpoint experiment/arm/origin identity mismatch')
    if not isinstance(ck.get('update'),int) or ck['update']<0:
        raise ValueError('Invalid resume update counter')


def verify_completion(path, snapshots):
    """A complete marker cannot substitute for missing or changed weights."""
    marker=Path(path)
    if not marker.exists():return False
    expected=read(marker).get('snapshot_sha256')
    actual={str(key):sha256(value) for key,value in snapshots.items() if Path(value).is_file()}
    if len(actual)!=len(snapshots) or expected!=actual:
        raise ValueError('Completed training artifact missing or changed')
    return True


def validate_protocol(p):
    if not p['seeds'] or len(set(p['seeds'])) != len(p['seeds']):
        raise ValueError('Unique independent model seeds required')
    if p['budgets'] != sorted(set(p['budgets'])) or p['budgets'][0] != 0:
        raise ValueError('Budgets must increase from zero')
    if len(p['source_ages']) != len(p['source_blocks']):
        raise ValueError('Age/block mapping invalid')
    if (not p['source_ages'] or p['source_ages'][0]!=0 or p['source_blocks'][0]!=0 or
        p['source_ages']!=sorted(set(p['source_ages'])) or p['source_blocks']!=sorted(set(p['source_blocks']))):
        raise ValueError('Source ages and blocks must increase from zero')
    if p['mature_source_age'] != max(p['source_ages']):
        raise ValueError('Mature age must be the final developmental checkpoint')
    if not p['namespace'] or p['namespace'] in {'physical-sealed-final-v1','physical-adaptation-test-v1'}:
        raise ValueError('A new test namespace is required')
    for k in ('development_trials','validation_trials','final_trials','retention_trials','diagnostic_episodes'):
        if int(p[k]) < 1:
            raise ValueError('Positive panel sizes required')
    for k in ('history_updates_per_block','history_length','history_width','history_cache_episodes',
              'adaptation_updates_per_episode','job_seconds','sync_seconds'):
        if not math.isfinite(float(p[k])) or float(p[k])<=0:
            raise ValueError(f'Positive {k} required')
    if not p['diagnostic_horizons'] or any(not isinstance(h,int) or h<1 for h in p['diagnostic_horizons']):
        raise ValueError('Diagnostic horizons must be positive integers')
    if not set(p['arms']).issubset({'frozen','full_update','low_lr','frozen_encoder','replay_mix','history'}):
        raise ValueError('Unknown adaptation arm')
    if not p.get('development_only'):
        if p['seeds'] != list(range(8)) or p['source_ages'] != [0,16384,32768]:
            raise ValueError('Formal protocol requires all original 8 seeds and 3 ages')
        if p['arms'] != ['frozen','full_update','low_lr','frozen_encoder','replay_mix','history']:
            raise ValueError('Formal arm family was changed')
    return p


class Experiment:
    def __init__(self, source, output, protocol, device, repo=None, run_id='supplement-local', resume=False):
        self.p = validate_protocol(read(protocol))
        self.source, self.root = Path(source).resolve(), Path(output).resolve()
        self.device, self.repo, self.run_id = torch.device(device), repo, run_id
        if not self.p.get('development_only') and self.device.type != 'cuda':
            raise RuntimeError('Formal experiment requires CUDA; use a marked development protocol for CPU checks')
        if self.device.type == 'cuda' and not torch.cuda.is_available():
            raise RuntimeError('CUDA GPU is unavailable; refusing a silent CPU run')
        self.started = time.monotonic(); self.deadline = self.started+self.p['job_seconds']
        global_deadline=os.environ.get('DEVBABY_SUPPLEMENT_DEADLINE_UNIX')
        if global_deadline is not None:
            unix_deadline=float(global_deadline)
            if not math.isfinite(unix_deadline):raise ValueError('Invalid global deadline')
            self.deadline=min(self.deadline,self.started+max(0.0,unix_deadline-time.time()))
        self.last_sync = 0.0
        self._checkpoint_hash_cache = {}
        self.root.mkdir(parents=True, exist_ok=True)
        source_identity = read(self.source/'supplement_source_identity.json') if (self.source/'supplement_source_identity.json').exists() else {}
        if not self.p.get('development_only'):
            if not source_identity:
                raise ValueError('Pinned source identity is missing; run through SUPPLEMENT.py')
            source_protocol = read(self.source/'protocol.json')
            if source_protocol.get('sha256') != self.p['source_protocol_sha256']:
                raise ValueError('Original experiment protocol hash differs')
        self.source_cfgs={};source_fingerprints={}
        for seed in self.p['seeds']:
            config_path=self.source/f'members/full-s{seed}/config.json'
            cfg=Config.load(config_path)
            if cfg.seed!=seed or cfg.ablation!='none':
                raise ValueError('Source config seed/full-model identity differs')
            if cfg.physics_steps!=self.p.get('physics_steps',cfg.physics_steps):
                raise ValueError('Source control horizon differs from the locked physical evaluation protocol')
            if self.p['history_length']>cfg.clip_steps or max(self.p['diagnostic_horizons'])>cfg.episode_steps:
                raise ValueError('Source clips/episodes are too short for the locked history/horizons')
            if not self.p.get('development_only') and self.p['history_updates_per_block']!=cfg.updates_per_block:
                raise ValueError('Formal history update budget differs from source training')
            source_fingerprints[str(config_path.relative_to(self.source))]=sha256(config_path)
            for age,block in zip(self.p['source_ages'],self.p['source_blocks']):
                if age!=block*cfg.episodes_per_block*cfg.episode_steps:
                    raise ValueError('Source ages do not match real interaction counts')
                path=self.source_checkpoint(seed,age,cfg)
                if not path.is_file():raise FileNotFoundError(f'Missing original weights; no automatic retraining: {path}')
                ck=torch.load(path,map_location='cpu',weights_only=False)
                if (ck.get('config')!=asdict(cfg) or ck.get('update')!=block*cfg.updates_per_block or
                    ck.get('interactions')!=age or ck.get('kind','baby')!='baby'):
                    raise ValueError(f'Source checkpoint payload does not match seed/age/update/config: {path}')
                del ck
                source_fingerprints[str(path.relative_to(self.source))]=sha256(path)
            if any(b%cfg.episode_steps for b in self.p['budgets']):
                raise ValueError('Adaptation budgets require complete episodes')
            self.source_cfgs[seed]=cfg
        self.lock = dict(protocol=self.p, code_sha256=code_digest(), source=source_identity,
                         source_fingerprints=source_fingerprints)
        self.lock['sha256'] = digest(self.lock)
        lock_path = self.root/'supplement_protocol.lock.json'
        if lock_path.exists():
            if read(lock_path) != self.lock:
                raise ValueError('Protocol/code/source changed; use a new experiment ID and test namespace')
            if not resume:
                raise ValueError('Output already exists: use --resume')
        else:
            if resume and any(self.root.glob('checkpoints/**/*.pt')):
                raise ValueError('Cannot resume without the immutable protocol lock')
            atomic_json(lock_path, self.lock)
        self.state = dict(status='running',phase='preflight',protocol_sha256=self.lock['sha256'],
                          development_only=bool(self.p.get('development_only')),training_complete=False)
        if (self.root/'supplement_state.json').exists():
            self.state.update(read(self.root/'supplement_state.json'))
            self.state['status'] = 'running'
        self.speech = Speech(self.root/'speech_cache')
        torch.set_num_threads(next(iter(self.source_cfgs.values())).threads)
        atomic_json(self.root/'runtime.json', dict(torch=torch.__version__,numpy=np.__version__,
            device=str(self.device),gpu=torch.cuda.get_device_name(self.device) if self.device.type=='cuda' else None,
            source_identity=source_identity,model_parameters='recorded per checkpoint',
            deterministic_note='RNG restored at update/episode boundaries; bitwise cross-device equality is not asserted'))

    def check(self):
        if time.monotonic() >= self.deadline:
            raise BudgetReached()

    def sync(self, force=False):
        if not force and time.monotonic()-self.last_sync < self.p['sync_seconds']:
            return
        self.state['elapsed_this_job_seconds'] = time.monotonic()-self.started
        atomic_json(self.root/'supplement_state.json',self.state)
        if self.repo:
            from .supplement_sync import sync_run
            sync_run(self.root,self.repo,self.run_id)
        self.last_sync = time.monotonic()

    def phase(self,name):
        self.state['phase']=name
        print(json.dumps(dict(phase=name,elapsed_seconds=round(time.monotonic()-self.started))),flush=True)
        self.sync(force=True)

    def source_checkpoint(self, seed, age, cfg=None):
        cfg = cfg or self.source_cfgs[seed]
        block = self.p['source_blocks'][self.p['source_ages'].index(age)]
        return self.source/f'members/full-s{seed}/checkpoints/model_{block*cfg.updates_per_block:08d}.pt'

    def history_checkpoint(self, seed, age):
        return self.root/f'checkpoints/history/s{seed}/age_{age:08d}.pt'

    def checkpoint(self,seed,age,arm,domain,budget):
        if arm=='frozen' or budget==0:
            return self.history_checkpoint(seed,age) if arm=='history' else self.source_checkpoint(seed,age)
        return self.root/f'checkpoints/adaptation/s{seed}/age_{age:08d}/{domain}/{arm}/budget_{budget:06d}.pt'

    def history_training(self,seed):
        cfg = self.source_cfgs[seed]
        folder = self.root/f'checkpoints/history/s{seed}'; folder.mkdir(parents=True,exist_ok=True)
        done = folder/'complete.json'
        snapshots={age:self.history_checkpoint(seed,age) for age in self.p['source_ages']}
        if verify_completion(done,snapshots):
            return
        seed_all(derived_seed(self.p['namespace'],seed,'history-init'))
        model = HistoryDynamics(cfg,self.p['history_length'],self.p['history_width']).to(self.device)
        optimizer = torch.optim.AdamW(model.parameters(),lr=cfg.learning_rate,weight_decay=1e-4)
        replay = BoundedReplay(cfg,self.source/f'members/full-s{seed}/data/episodes',
                               derived_seed(seed,'history-replay'),cache_size=self.p['history_cache_episodes'])
        context=dict(protocol_sha256=self.lock['sha256'],seed=seed,phase='history',kind='history')
        last=folder/'last.pt'; update=0; trace_path=folder/'training_trace.jsonl'
        # The initial random state is reproducible from the locked seed and is
        # saved before a resumed trained state is loaded.
        if not self.history_checkpoint(seed,0).exists():
            save_model(self.history_checkpoint(seed,0),model,cfg,update=0,interactions=0)
        if last.exists():
            ck=torch.load(last,map_location=self.device,weights_only=False)
            validate_resume_checkpoint(ck,cfg,context)
            model.load_state_dict(ck['model']);optimizer.load_state_dict(ck['optimizer']);update=ck['update']
            restore_rng(ck,replay)
        per_block=self.p['history_updates_per_block']
        total=max(self.p['source_blocks'])*per_block
        if update>total:raise ValueError('History resume exceeds the locked training budget')
        if last.exists() and ck.get('interactions')!=math.ceil(update/per_block)*cfg.episodes_per_block*cfg.episode_steps:
            raise ValueError('History checkpoint interactions/update counters disagree')
        trim_training_trace(trace_path,update)
        # A crash can occur between committing last.pt and its age snapshot.
        # Only an exactly matching boundary can be recovered from last.pt;
        # substituting later weights for an earlier developmental age is forbidden.
        for age,block in zip(self.p['source_ages'][1:],self.p['source_blocks'][1:]):
            boundary=block*per_block
            if boundary<=update and not snapshots[age].exists():
                if boundary!=update:raise ValueError('Missing earlier history age checkpoint')
                save_model(snapshots[age],model,cfg,update=update,interactions=age)
        while update<total:
            self.check()
            block=update//per_block+1
            limit=block*cfg.episodes_per_block
            replay.refresh(episode_limit=limit)
            if len(replay.paths)!=min(limit,cfg.replay_episodes):
                raise ValueError(f'Incomplete source experience for seed {seed}, block {block}')
            batch,trace=replay.sample(self.device)
            model.train();optimizer.zero_grad(set_to_none=True)
            loss,stats=history_loss(model,batch)
            if not bool(torch.isfinite(loss)):
                raise FloatingPointError('History baseline loss is not finite')
            loss.backward();torch.nn.utils.clip_grad_norm_(model.parameters(),5,error_if_nonfinite=True);optimizer.step()
            update+=1
            append_training_trace(trace_path,update,trace,stats,block=block,source_episodes=limit)
            age_boundary=update%per_block==0 and block in self.p['source_blocks']
            if update % 64==0 or update==total or age_boundary:
                save_model(last,model,cfg,optimizer,replay,update=update,interactions=limit*cfg.episode_steps,**context)
                atomic_json(folder/'progress.json',dict(update=update,source_episodes=limit,stats=stats,
                    parameters=sum(x.numel() for x in model.parameters()),valid_targets_per_clip=cfg.clip_steps-self.p['history_length']+1))
                self.sync()
            if age_boundary:
                age=limit*cfg.episode_steps
                if not snapshots[age].exists():save_model(snapshots[age],model,cfg,update=update,interactions=age)
        atomic_json(done,dict(updates=update,interactions=max(self.p['source_ages']),
                             snapshot_sha256={str(age):sha256(path) for age,path in snapshots.items()}))
        del model,optimizer,replay;gc.collect();self.sync()

    def prepare_experience(self,seed,domain):
        cfg=self.source_cfgs[seed];base=self.root/f'experience/s{seed}/{domain}'
        for ep in range(max(self.p['budgets'])//cfg.episode_steps):
            self.check()
            collect_episode(cfg,self.speech,base/f'{ep:07d}',
                derived_seed(self.p['namespace'],'train',seed,domain,ep),domain,
                namespace=self.p['namespace'],split='train')
            self.sync()
        return base

    def adapt(self,seed,age,domain,arm):
        if arm=='frozen':return
        cfg=self.source_cfgs[seed]
        folder=self.root/f'checkpoints/adaptation/s{seed}/age_{age:08d}/{domain}/{arm}'
        folder.mkdir(parents=True,exist_ok=True)
        snapshots={budget:self.checkpoint(seed,age,arm,domain,budget) for budget in self.p['budgets'][1:]}
        if verify_completion(folder/'complete.json',snapshots):return
        seed_all(derived_seed(self.p['namespace'],seed,domain,'adapt-optimizer'))
        origin=self.checkpoint(seed,age,arm,domain,0)
        model,_,_=load_model(origin,self.device)
        optimizer=(torch.optim.AdamW(model.parameters(),lr=cfg.learning_rate,weight_decay=1e-4)
                   if arm=='history' else configure_adaptation(model,arm,cfg.learning_rate))
        replay=BoundedReplay(cfg,self.root/f'experience/s{seed}/{domain}',derived_seed(seed,domain,'adapt-replay'))
        old=BoundedReplay(cfg,self.source/f'members/full-s{seed}/data/episodes',derived_seed(seed,domain,'old-replay'))
        old.refresh(episode_limit=age//cfg.episode_steps)
        initial_hash=parameter_hashes(model)
        context=dict(protocol_sha256=self.lock['sha256'],seed=seed,phase='adaptation',arm=arm,
                     source_age=age,domain=domain,origin_sha256=sha256(origin),
                     kind='history' if arm=='history' else 'baby')
        ep=0;update=0;last=folder/'last.pt';trace_path=folder/'training_trace.jsonl'
        if last.exists():
            ck=torch.load(last,map_location=self.device,weights_only=False)
            validate_resume_checkpoint(ck,cfg,context)
            model.load_state_dict(ck['model']);optimizer.load_state_dict(ck['optimizer'])
            ep,update=ck['episode'],ck['update'];initial_hash=ck['initial_hash']
            if (not isinstance(ep,int) or ep<0 or ep>max(self.p['budgets'])//cfg.episode_steps or
                update!=ep*self.p['adaptation_updates_per_episode']):
                raise ValueError('Adaptation checkpoint episode/update counters disagree')
            restore_rng(ck,replay,old)
        trim_training_trace(trace_path,update)
        for budget in self.p['budgets'][1:]:
            target=budget//cfg.episode_steps;target_file=self.checkpoint(seed,age,arm,domain,budget)
            if ep>target:
                if not target_file.exists():raise ValueError('Missing earlier adaptation checkpoint')
                continue
            while ep<target:
                self.check();replay.refresh(episode_limit=ep+1)
                for _ in range(self.p['adaptation_updates_per_episode']):
                    if arm=='history':
                        batch,samples=replay.sample(self.device);optimizer.zero_grad(set_to_none=True)
                        model.train();loss,stats=history_loss(model,batch)
                        if not bool(torch.isfinite(loss)):raise FloatingPointError('Nonfinite history adaptation')
                        loss.backward();torch.nn.utils.clip_grad_norm_(model.parameters(),5,error_if_nonfinite=True);optimizer.step()
                    else:
                        stats,samples=adaptation_step(model,optimizer,replay,self.device,arm,old,audit=update==0)
                    update+=1
                    append_training_trace(trace_path,update,samples,stats,episode=ep,arm=arm,domain=domain)
                ep+=1
                save_model(last,model,cfg,optimizer,replay,old,episode=ep,update=update,initial_hash=initial_hash,**context)
                atomic_json(folder/'progress.json',dict(episode=ep,update=update,budget=ep*cfg.episode_steps,last_stats=stats,last_samples=samples))
                self.sync()
            if not target_file.exists():
                save_model(target_file,model,cfg,update=update,interactions=age,budget=budget)
                final_hash=parameter_hashes(model)
                atomic_json(folder/f'audit_{budget:06d}.json',dict(initial=initial_hash,final=final_hash,
                    changed=[k for k in initial_hash if initial_hash[k]!=final_hash[k]],arm=arm,updates=update))
        atomic_json(folder/'complete.json',dict(update=update,budget=max(self.p['budgets']),origin_sha256=sha256(origin),
                    snapshot_sha256={str(b):sha256(path) for b,path in snapshots.items()}))
        del model,optimizer,replay,old;gc.collect();self.sync()

    def diagnostic(self,seed,age,domain,arm,budget):
        folder=self.root/f'diagnostics/s{seed}/{domain}/age_{age:08d}/{arm}_{budget:06d}'
        result=folder/'metrics.json'
        if result.exists():return
        self.check();cfg=self.source_cfgs[seed];paths=[]
        for ep in range(self.p['diagnostic_episodes']):
            directory=self.root/f'diagnostic_experience/s{seed}/{domain}/{ep:07d}'
            collect_episode(cfg,self.speech,directory,derived_seed(self.p['namespace'],'diagnostic',seed,domain,ep),
                domain,namespace=self.p['namespace'],split='diagnostic')
            paths.append(directory/'observations.npz')
        model,cfg,_=load_model(self.checkpoint(seed,age,arm,domain,budget),self.device)
        metrics=sensory_prediction_diagnostics(model,paths,self.device,horizons=self.p['diagnostic_horizons'])
        metrics['alignment']=temporal_alignment_audit(model,paths[0],self.device)
        metrics['metadata']=dict(seed=seed,source_age=age,domain=domain,arm=arm,budget=budget,split='diagnostic')
        atomic_json(result,metrics);del model;gc.collect();self.sync()

    def checkpoint_sha256(self,path):
        path=Path(path);stat=path.stat();key=str(path.resolve())
        identity=(stat.st_size,stat.st_mtime_ns)
        previous=self._checkpoint_hash_cache.get(key)
        if previous is None or previous[0]!=identity:
            previous=(identity,sha256(path));self._checkpoint_hash_cache[key]=previous
        return previous[1]

    def evaluate_cell(self,metadata,n,checkpoint=None):
        self.check()
        if metadata['split']=='final' and not self.state.get('training_complete'):
            raise RuntimeError('Sealed test attempted before training completion')
        key=digest(metadata)[:24];folder=self.root/'evaluations'/key
        result=folder/'result.json'
        checkpoint_hash=self.checkpoint_sha256(checkpoint) if checkpoint is not None else None
        if result.exists():
            old=read(result)
            if (old.get('metadata')!=metadata or old.get('n_trials')!=n or
                old.get('checkpoint_sha256')!=checkpoint_hash):
                raise ValueError('Completed evaluation identity changed')
            if old.get('sensory_archive') and not (self.root/old['sensory_archive']).is_file():
                raise ValueError('Completed evaluation sensory archive is missing')
            return
        # A cell label may name a different arm/budget but execute identical
        # frozen weights. Share that physical experiment, including recordings.
        # Reference policies are explicitly included because all have no weights.
        policy=metadata['model']
        identity=dict(checkpoint_sha256=checkpoint_hash,policy=policy,split=metadata['split'],
                      domain=metadata['domain'],task=metadata['task'],seed=metadata['seed'],n_trials=n)
        panel=self.root/'physical_panels'/digest(identity)[:24];panel_result=panel/'panel.json'
        if panel_result.exists():
            cached=read(panel_result)
            if cached.get('identity')!=identity or not cached.get('complete'):
                raise ValueError('Physical panel cache identity changed')
        else:
            model=None;cfg=self.source_cfgs[metadata['seed']]
            if checkpoint is not None:model,cfg,_=load_model(checkpoint,self.device)
            factory=(lambda seed: controller_factory('world' if policy=='baby' else policy,model,cfg,self.device,seed))
            trials=[]
            for trial in range(n):
                self.check();path=panel/'trials'/f'{trial:05d}.json'
                if path.exists():row=read(path)
                else:
                    row=run_trial(cfg,self.speech,metadata['domain'],metadata['task'],trial,
                        self.p['namespace'],factory,model_seed=metadata['seed'],
                        policy=policy,split=metadata['split'],output_dir=panel/'sensory',
                        record_sensory=self.p['record_evaluation_sensory'])
                    if 'sensory_directory' in row:
                        row['sensory_directory']=str(Path(row['sensory_directory']).relative_to(self.root))
                    atomic_json(path,row)
                if (row.get('trial')!=trial or row.get('policy')!=policy or
                    row.get('split')!=metadata['split'] or row.get('model_seed')!=metadata['seed']):
                    raise ValueError('Partial trial cache identity changed')
                trials.append(row);self.sync()
            sensory=panel/'sensory';archive=panel/'sensory.zip'
            if sensory.exists():
                if not archive.exists():
                    temp=panel/'sensory.tmp'
                    with zipfile.ZipFile(temp,'w',zipfile.ZIP_DEFLATED,compresslevel=3) as z:
                        for path in sorted(sensory.rglob('*')):
                            if path.is_file():z.write(path,str(path.relative_to(panel)))
                    temp.replace(archive)
                elif not zipfile.is_zipfile(archive):
                    raise ValueError('Existing sensory archive is invalid')
                # Archive is committed before deletion. If interrupted here,
                # the existing archive is retained on resume.
                shutil.rmtree(sensory)
            cached=dict(complete=True,identity=identity,trials=trials,n_trials=n,
                        sensory_archive=str(archive.relative_to(self.root)) if archive.exists() else None)
            atomic_json(panel_result,cached)
            shutil.rmtree(panel/'trials',ignore_errors=True)
            del model;gc.collect()
        if self.p['record_evaluation_sensory'] and (not cached.get('sensory_archive') or
            not (self.root/cached['sensory_archive']).is_file()):
            raise ValueError('Completed physical panel lacks its sensory archive')
        atomic_json(result,dict(complete=True,metadata=metadata,trials=cached['trials'],n_trials=n,
            checkpoint_sha256=checkpoint_hash,sensory_archive=cached['sensory_archive'],
            panel_directory=str(panel.relative_to(self.root))))
        self.sync()

    def schedule(self):
        p=self.p;mature=p['mature_source_age'];tasks=p['adaptation_tasks']
        for seed in p['seeds']:
            for age in p['source_ages']:
                for kind in ('baby','history'):
                    cp=self.source_checkpoint(seed,age) if kind=='baby' else self.history_checkpoint(seed,age)
                    for domain in p['development_domains']:
                        for task in tasks:
                            yield dict(phase='development',split='validation',seed=seed,model=kind,arm='frozen',source_age=age,budget=0,domain=domain,task=task),p['development_trials'],cp
            for domain in p['adaptation_domains']:
                for age in p['source_ages']:
                    arms=p['arms'] if age==mature else ['frozen','full_update']
                    for arm in arms:
                        for budget in p['budgets']:
                            for task in tasks:
                                yield dict(phase='adaptation',split='validation',seed=seed,model='history' if arm=='history' else 'baby',arm=arm,source_age=age,budget=budget,domain=domain,task=task),p['validation_trials'],self.checkpoint(seed,age,arm,domain,budget)
                for arm in p['arms']:
                    budget=max(p['budgets']);cp=self.checkpoint(seed,mature,arm,domain,budget)
                    for task in tasks:
                        yield dict(phase='adaptation',split='final',seed=seed,model='history' if arm=='history' else 'baby',arm=arm,source_age=mature,budget=budget,domain=domain,task=task),p['final_trials'],cp
                        yield dict(phase='retention',split='final',seed=seed,model='history' if arm=='history' else 'baby',arm=arm,source_age=mature,budget=budget,domain='iid',training_domain=domain,task=task),p['retention_trials'],cp
            for kind in ('baby','history'):
                cp=self.source_checkpoint(seed,mature) if kind=='baby' else self.history_checkpoint(seed,mature)
                for domain in p['delay_domains']:
                    for task in tasks:
                        yield dict(phase='delay_sweep',split='final',seed=seed,model=kind,arm='frozen',source_age=mature,budget=0,domain=domain,task=task),p['final_trials'],cp
                for domain in p['push_domains']:
                    yield dict(phase='push',split='final',seed=seed,model=kind,arm='frozen',source_age=mature,budget=0,domain=domain,task='push'),p['final_trials'],cp
        # Fixed controllers have no fitted model seed. Paired scene uncertainty
        # is reported; their sole seed is never treated as eight trained models.
        for kind in ('feedback','random','oracle'):
            for domain in sorted(set(p['development_domains']+p['delay_domains'])):
                for task in tasks:
                    yield dict(phase='reference',split='final',seed=p['seeds'][0],model=kind,arm='frozen',source_age=0,budget=0,domain=domain,task=task),p['final_trials'],None
            for domain in p['push_domains']:
                yield dict(phase='reference',split='final',seed=p['seeds'][0],model=kind,arm='frozen',source_age=0,budget=0,domain=domain,task='push'),p['final_trials'],None

    def run(self):
        from .supplement_report import build_report
        try:
            if self.state.get('training_complete'):
                # Once a final panel may have been exposed, missing training
                # artifacts are an integrity error, not permission to refit.
                for seed in self.p['seeds']:
                    folder=self.root/f'checkpoints/history/s{seed}'
                    if not verify_completion(folder/'complete.json',
                        {age:self.history_checkpoint(seed,age) for age in self.p['source_ages']}):
                        raise ValueError('Training-complete state lacks completed history weights')
                    for domain in self.p['adaptation_domains']:
                        for age in self.p['source_ages']:
                            for arm in (self.p['arms'] if age==self.p['mature_source_age'] else ['full_update']):
                                if arm=='frozen':continue
                                folder=self.root/f'checkpoints/adaptation/s{seed}/age_{age:08d}/{domain}/{arm}'
                                if not verify_completion(folder/'complete.json',
                                    {b:self.checkpoint(seed,age,arm,domain,b) for b in self.p['budgets'][1:]}):
                                    raise ValueError('Training-complete state lacks completed adaptation weights')
            self.phase('history_baseline_training')
            for seed in self.p['seeds']:self.history_training(seed)
            self.phase('adaptation_training')
            for seed in self.p['seeds']:
                for domain in self.p['adaptation_domains']:
                    self.prepare_experience(seed,domain)
                    for age in self.p['source_ages']:
                        for arm in (self.p['arms'] if age==self.p['mature_source_age'] else ['full_update']):
                            self.adapt(seed,age,domain,arm)
            self.state['training_complete']=True;self.phase('mechanism_diagnostics')
            for seed in self.p['seeds']:
                for domain in self.p['adaptation_domains']:
                    for arm in [a for a in self.p['arms'] if a!='history']:
                        self.diagnostic(seed,self.p['mature_source_age'],domain,arm,0 if arm=='frozen' else max(self.p['budgets']))
            cells=list(self.schedule())
            atomic_json(self.root/'planned_evaluations.json',dict(cells=len(cells),trials=sum(n for _,n,_ in cells),
                schedule=[dict(metadata=m,n_trials=n) for m,n,_ in cells]))
            for split in ('validation','final'):
                self.phase(split+'_evaluation')
                if split=='final' and not self.state['training_complete']:
                    raise RuntimeError('Sealed test attempted before training completion')
                for metadata,n,cp in cells:
                    if metadata['split']==split:self.evaluate_cell(metadata,n,cp)
            self.phase('report')
            build_report(self.root,self.p,complete=True)
            self.state.update(status='completed',phase='completed')
            self.sync(force=True)
            return self.state
        except BudgetReached:
            self.state['status']='time_budget_reached'
            build_report(self.root,self.p,complete=False)
            self.sync(force=True)
            return self.state
        except Exception:
            self.state['status']='failed'
            (self.root/'failure.txt').write_text(traceback.format_exc())
            self.sync(force=True)
            raise


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--source-root',required=True);parser.add_argument('--output',required=True)
    parser.add_argument('--protocol',default='supplement_protocol.json');parser.add_argument('--device',default='cuda')
    parser.add_argument('--hf-repo');parser.add_argument('--run-id',default='supplement-local');parser.add_argument('--resume',action='store_true')
    args=parser.parse_args()
    experiment=Experiment(args.source_root,args.output,args.protocol,args.device,args.hf_repo,args.run_id,args.resume)
    result=experiment.run();print(json.dumps(result,indent=2),flush=True)


if __name__=='__main__':main()
