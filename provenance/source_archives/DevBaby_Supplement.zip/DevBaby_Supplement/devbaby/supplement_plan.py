"""Pure-standard-library work accounting, safe to run before a paid GPU Job.

Counts mirror Experiment.schedule(), including aliases of identical frozen and
zero-budget checkpoints. No models, GPU libraries, network calls, or Jobs are
loaded here. Counts are a work inventory, never a wall-time or price estimate.
"""
from collections import defaultdict
import json
from pathlib import Path


def _source_configs(protocol, configs):
    formal = json.loads((Path(__file__).resolve().parent.parent / "configs/formal.json").read_text())
    result = {}
    for seed in protocol["seeds"]:
        supplied = None if configs is None else configs.get(seed, configs.get(str(seed)))
        if configs is not None and supplied is None:
            raise ValueError(f"Missing source configuration for seed {seed}")
        cfg = {**formal, **(supplied or {})}
        for key in ("episodes_per_block", "episode_steps", "updates_per_block", "batch_size", "clip_steps",
                    "physics_steps", "planner_horizon", "planner_candidates", "planner_iterations"):
            if int(cfg[key]) < 1:
                raise ValueError(f"Source configuration {key} must be positive")
        for age, block in zip(protocol["source_ages"], protocol["source_blocks"]):
            if age != block * cfg["episodes_per_block"] * cfg["episode_steps"]:
                raise ValueError(f"Source age/block/interaction mismatch for seed {seed}")
        if any(budget % cfg["episode_steps"] for budget in protocol["budgets"]):
            raise ValueError("Adaptation budgets require whole source-length episodes")
        if cfg["clip_steps"] < protocol["history_length"]:
            raise ValueError("History predictor requires a full context window within every training clip")
        result[seed] = cfg
    return result


def checkpoint_identity(metadata):
    """Logical file identity; positive-budget adaptation files are not merged.

    The runner verifies actual checkpoint payloads and uses immutable checkpoint
    hashes. This symbolic identity mirrors which *file path* its schedule uses.
    It does not infer that two separately fitted models have equivalent weights.
    """
    kind = metadata["model"]
    if kind in ("feedback", "random", "oracle"):
        return None
    seed, age, arm, budget = (metadata[key] for key in ("seed", "source_age", "arm", "budget"))
    if arm == "frozen" or budget == 0:
        return ("history_source" if kind == "history" else "baby_source", seed, age)
    domain = metadata.get("training_domain", metadata["domain"])
    return ("adaptation", kind, seed, age, domain, arm, budget)


def scheduled_panels(p):
    """Yield (metadata, number_of_trials, logical_checkpoint_identity)."""
    mature, tasks = p["mature_source_age"], p["adaptation_tasks"]

    def row(metadata, n):
        return metadata, int(n), checkpoint_identity(metadata)

    for seed in p["seeds"]:
        for age in p["source_ages"]:
            for kind in ("baby", "history"):
                for domain in p["development_domains"]:
                    for task in tasks:
                        yield row(dict(phase="development", split="validation", seed=seed, model=kind,
                                       arm="frozen", source_age=age, budget=0, domain=domain, task=task),
                                  p["development_trials"])
        for domain in p["adaptation_domains"]:
            for age in p["source_ages"]:
                arms = p["arms"] if age == mature else ["frozen", "full_update"]
                for arm in arms:
                    for budget in p["budgets"]:
                        for task in tasks:
                            yield row(dict(phase="adaptation", split="validation", seed=seed,
                                           model="history" if arm == "history" else "baby", arm=arm,
                                           source_age=age, budget=budget, domain=domain, task=task),
                                      p["validation_trials"])
            for arm in p["arms"]:
                for task in tasks:
                    metadata = dict(phase="adaptation", split="final", seed=seed,
                                    model="history" if arm == "history" else "baby", arm=arm,
                                    source_age=mature, budget=max(p["budgets"]), domain=domain, task=task)
                    yield row(metadata, p["final_trials"])
                    yield row({**metadata, "phase": "retention", "domain": "iid", "training_domain": domain},
                              p["retention_trials"])
        for kind in ("baby", "history"):
            for domain in p["delay_domains"]:
                for task in tasks:
                    yield row(dict(phase="delay_sweep", split="final", seed=seed, model=kind, arm="frozen",
                                   source_age=mature, budget=0, domain=domain, task=task), p["final_trials"])
            for domain in p["push_domains"]:
                yield row(dict(phase="push", split="final", seed=seed, model=kind, arm="frozen",
                               source_age=mature, budget=0, domain=domain, task="push"), p["final_trials"])
    for kind in ("feedback", "random", "oracle"):
        for domain in sorted(set(p["development_domains"] + p["delay_domains"])):
            for task in tasks:
                yield row(dict(phase="reference", split="final", seed=p["seeds"][0], model=kind, arm="frozen",
                               source_age=0, budget=0, domain=domain, task=task), p["final_trials"])
        for domain in p["push_domains"]:
            yield row(dict(phase="reference", split="final", seed=p["seeds"][0], model=kind, arm="frozen",
                           source_age=0, budget=0, domain=domain, task="push"), p["final_trials"])


def execution_identity(metadata, n_trials, checkpoint):
    """Matching initial weights, policy RNG/scene panel and trial count only.

    Policy kind must be included: feedback/random/oracle all have checkpoint=None.
    Budget/phase/arm labels never make a new execution when these inputs match.
    """
    return (checkpoint, metadata["model"], metadata["split"], metadata["domain"], metadata["task"],
            metadata["seed"], n_trials)


def plan(protocol, source_configs=None):
    """Return JSON-serializable full-suite counts, independent of resume progress.

    source_configs optionally maps seed to a verified original configuration
    dict. Otherwise use the packaged original formal configuration explicitly.
    The caller should display this before submitting a paid Job. The counts are
    for the full fixed experiment, not work remaining after a resumed checkpoint.
    """
    p = protocol
    if not p["seeds"] or len(set(p["seeds"])) != len(p["seeds"]):
        raise ValueError("Unique model seeds are required")
    if len(p["source_ages"]) != len(p["source_blocks"]):
        raise ValueError("Source age/block lists must align")
    if not p["budgets"] or p["budgets"] != sorted(set(p["budgets"])) or p["budgets"][0] != 0:
        raise ValueError("Adaptation budgets must increase from zero")
    if p["mature_source_age"] != max(p["source_ages"]):
        raise ValueError("Mature source age must be the final developmental checkpoint")
    configs = _source_configs(p, source_configs)
    scheduled = list(scheduled_panels(p))
    phases = defaultdict(lambda: dict(scheduled_cells=0, scheduled_trials=0,
                                     unique_execution_panels_first_use=0, unique_execution_trials_first_use=0))
    unique = {}
    for metadata, n, checkpoint in scheduled:
        if n < 1:
            raise ValueError("Every evaluation panel must contain a positive number of trials")
        phase = phases[metadata["phase"]]
        phase["scheduled_cells"] += 1
        phase["scheduled_trials"] += n
        identity = execution_identity(metadata, n, checkpoint)
        if identity not in unique:
            unique[identity] = (metadata, n, checkpoint)
            phase["unique_execution_panels_first_use"] += 1
            phase["unique_execution_trials_first_use"] += n

    by_arm = defaultdict(lambda: dict(chains=0, optimizer_updates=0, batch_clips=0,
                                     scored_body_transition_presentations=0,
                                     new_experience_clip_presentations=0, old_experience_clip_presentations=0))
    source_checkpoints, source_budget = [], []
    history_updates = history_targets = original_updates = original_targets = 0
    unique_source_episodes = unique_source_interactions = 0
    new_episodes = new_interactions = diagnostic_episodes = diagnostic_interactions = 0
    for seed, cfg in configs.items():
        history_valid = cfg["clip_steps"] - p["history_length"] + 1
        updates = max(p["source_blocks"]) * p["history_updates_per_block"]
        baby_updates = max(p["source_blocks"]) * cfg["updates_per_block"]
        history_updates += updates
        history_targets += updates * cfg["batch_size"] * history_valid
        original_updates += baby_updates
        original_targets += baby_updates * cfg["batch_size"] * cfg["clip_steps"]
        episodes = max(p["source_blocks"]) * cfg["episodes_per_block"]
        unique_source_episodes += episodes
        unique_source_interactions += episodes * cfg["episode_steps"]
        source_budget.append(dict(seed=seed, source_interactions=episodes*cfg["episode_steps"],
                                 baby_original_updates=baby_updates, history_source_updates=updates,
                                 batch_size=cfg["batch_size"], clip_steps=cfg["clip_steps"],
                                 baby_valid_targets_per_clip=cfg["clip_steps"], history_valid_targets_per_clip=history_valid,
                                 history_to_baby_valid_target_ratio=history_valid/cfg["clip_steps"]))
        for age, block in zip(p["source_ages"], p["source_blocks"]):
            expected_update = block*cfg["updates_per_block"]
            source_checkpoints.append(dict(seed=seed, source_age=age, block=block,
                                           expected_update=expected_update, expected_interactions=age,
                                           relative_path=f"members/full-s{seed}/checkpoints/model_{expected_update:08d}.pt"))
        fresh_episodes = max(p["budgets"]) // cfg["episode_steps"]
        new_episodes += len(p["adaptation_domains"])*fresh_episodes
        new_interactions += len(p["adaptation_domains"])*max(p["budgets"])
        diagnostic_episodes += len(p["adaptation_domains"])*p["diagnostic_episodes"]
        diagnostic_interactions += len(p["adaptation_domains"])*p["diagnostic_episodes"]*cfg["episode_steps"]
        for _domain in p["adaptation_domains"]:
            for age in p["source_ages"]:
                for arm in (p["arms"] if age == p["mature_source_age"] else ["full_update"]):
                    if arm == "frozen":
                        continue
                    stats = by_arm[arm]
                    chain_updates = fresh_episodes*p["adaptation_updates_per_episode"]
                    clips = chain_updates*cfg["batch_size"]
                    if arm == "replay_mix" and cfg["batch_size"] % 2:
                        raise ValueError("Replay mixing requires an even training batch size")
                    stats["chains"] += 1
                    stats["optimizer_updates"] += chain_updates
                    stats["batch_clips"] += clips
                    stats["scored_body_transition_presentations"] += clips*(history_valid if arm == "history" else cfg["clip_steps"])
                    stats["new_experience_clip_presentations"] += clips//2 if arm == "replay_mix" else clips
                    stats["old_experience_clip_presentations"] += clips//2 if arm == "replay_mix" else 0
    adaptation_updates = sum(row["optimizer_updates"] for row in by_arm.values())
    history_adaptation_updates = by_arm.get("history", {}).get("optimizer_updates", 0)
    control_steps = sum(n*configs[metadata["seed"]]["physics_steps"] for metadata, n, _ in unique.values())
    candidate_steps = sum(n*configs[m["seed"]]["physics_steps"]*configs[m["seed"]]["planner_horizon"]*
                          configs[m["seed"]]["planner_candidates"]*configs[m["seed"]]["planner_iterations"]
                          for m, n, _ in unique.values() if m["model"] in ("baby", "history"))
    scheduled_trials = sum(n for _, n, _ in scheduled)
    unique_trials = sum(n for _, n, _ in unique.values())
    return dict(
        schema="devbaby-supplement-work-plan-v1",
        source_config_basis="packaged_formal_configuration" if source_configs is None else "provided_verified_source_configurations",
        scheduled_cells=len(scheduled), scheduled_trials=scheduled_trials,
        unique_execution_panels=len(unique), unique_execution_trials=unique_trials,
        aliased_cells=len(scheduled)-len(unique), aliased_trials=scheduled_trials-unique_trials,
        counts_by_phase=dict(phases),
        training=dict(
            original_baby_retraining_updates=0,
            original_baby_completed_updates_reused=original_updates,
            original_baby_completed_body_target_presentations_reused=original_targets,
            original_checkpoints_reused=len(source_checkpoints),
            unique_original_episodes_reused=unique_source_episodes,
            unique_original_interactions_reused=unique_source_interactions,
            history_source_updates=history_updates,
            history_source_scored_body_transition_presentations=history_targets,
            history_adaptation_updates=history_adaptation_updates,
            baby_adaptation_updates=adaptation_updates-history_adaptation_updates,
            all_new_optimizer_updates=history_updates+adaptation_updates,
            unique_new_adaptation_episodes=new_episodes,
            unique_new_adaptation_interactions=new_interactions,
            diagnostic_only_episodes=diagnostic_episodes,
            diagnostic_only_interactions=diagnostic_interactions,
            diagnostic_model_domain_evaluations=len(p["seeds"])*len(p["adaptation_domains"])*len([a for a in p["arms"] if a != "history"]),
            adaptation_by_arm=dict(by_arm), per_seed_source_budget=source_budget,
            expected_source_checkpoint_payloads=source_checkpoints,
        ),
        evaluation=dict(unique_control_steps=control_steps, learned_candidate_body_prediction_steps=candidate_steps,
                        sensory_recording=bool(p.get("record_evaluation_sensory", True)),
                        recording_bytes_estimate=None),
        limits=dict(cooperative_seconds_per_job=p["job_seconds"], hard_timeout_seconds_per_job=86400,
                    estimated_wall_seconds=None, runtime_guaranteed=False,
                    remaining_work_after_resume="not inferred; these are full-suite counts",
                    note="The 23-hour cooperative / 24-hour hard limits cap one paid Job, not the full suite. Completion may require explicit paid resume; there is no automatic retry."),
        budget_notes=[
            "Original Baby weights are reused. Only the explicit-history baseline is trained from scratch on the same chronological original experience pool.",
            "History and Baby have equal available interactions and matched source update counts under the formal protocol, but different sensors, parameter counts, objectives and valid target counts; this is not compute- or representation-matched training.",
            "History uses only proprioception and issued commands. Its first H-1 clip positions are context only; for H=8,T=16 it scores 9 body targets versus Baby's 16.",
            "All adaptation arms share the same new episodes; reusing them across model ages/arms does not create extra independent interactions. Replay-mix trains on half new/half original clips at fixed batch size.",
            "Frozen and zero-budget aliases share physical executions only when checkpoint, policy, split, domain, task, model seed, and panel size all match. Aliased records are not independent evidence.",
            "Diagnostic and evaluation interactions are held out from training. Candidate body prediction counts measure planning workload, not FLOPs or wall time.",
        ],
    )


def main(argv=None):
    import argparse
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--protocol", default="supplement_protocol.json")
    args = parser.parse_args(argv)
    print(json.dumps(plan(json.loads(Path(args.protocol).read_text())), indent=2))


if __name__ == "__main__":
    main()
