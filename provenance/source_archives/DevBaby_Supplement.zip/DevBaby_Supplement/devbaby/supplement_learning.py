"""Controlled adaptation and sensory-only diagnostics for the supplement.

The update objective deliberately stays identical to ``model.losses`` in the
original random-exploration experiment.  In particular, no previous-model
progress target, success label, simulator parameter, or transcript is supplied
to training.  Evaluation trajectories must be generated in a separate namespace
by the experiment runner; this module never adds them to replay.

The original clip-state convention is measured, not silently changed.  The
original forward pass resets its GRU and replaces the first previous action of
every sampled clip with zero, including clips beginning inside an episode.
Executed control instead has the real previous issued action and episode
history.  ``sensory_prediction_diagnostics`` measures both conventions.
"""

from copy import deepcopy
import hashlib
import math
from pathlib import Path

import numpy as np
import torch

from .data import OBS_KEYS
from .model import losses
from .world import ACTION_DIM, PROPRIO_DIM


ADAPTATION_ARMS = ("frozen", "full_update", "low_lr", "frozen_encoder", "replay_mix")
PLASTIC_MODULES = frozenset(("memory", "dynamics", "body"))


def frozen_reference(model):
    """Independent immutable-origin copy for retention evaluation.

    The caller keeps this copy separate from the adapted model.  Copying does
    not initialize a new network and therefore does not consume a random draw.
    """
    reference = deepcopy(model)
    reference.eval()
    reference.requires_grad_(False)
    for parameter in reference.parameters():
        parameter.grad = None
    return reference


def configure_adaptation(model, arm, base_lr=None, weight_decay=1e-4):
    """Set trainable parameters and construct the specified AdamW optimizer.

    Call this before loading a resumed optimizer state: parameter ordering is
    always ``named_parameters`` order, so it is stable across restarts.  The
    runner must save both replay generators for ``replay_mix`` as well as its
    existing global RNG and optimizer checkpoint state.
    """
    if arm not in ADAPTATION_ARMS:
        raise ValueError(f"Unknown adaptation arm {arm!r}; expected {ADAPTATION_ARMS}")
    base_lr = model.cfg.learning_rate if base_lr is None else float(base_lr)
    if not math.isfinite(base_lr) or base_lr <= 0:
        raise ValueError("base_lr must be finite and positive")
    if not math.isfinite(weight_decay) or weight_decay < 0:
        raise ValueError("weight_decay must be finite and nonnegative")
    for name, parameter in model.named_parameters():
        trainable = arm != "frozen" and (
            arm != "frozen_encoder" or name.split(".", 1)[0] in PLASTIC_MODULES
        )
        parameter.requires_grad_(trainable)
        parameter.grad = None
    model._supplement_arm = arm
    if arm == "frozen":
        model.eval()
        return None
    model.train()
    lr = base_lr * (0.1 if arm == "low_lr" else 1.0)
    return torch.optim.AdamW(
        [parameter for parameter in model.parameters() if parameter.requires_grad],
        lr=lr,
        weight_decay=weight_decay,
    )


def parameter_hashes(model):
    """SHA256 of each parameter, including its shape and dtype (no RNG use)."""
    hashes = {}
    for name, parameter in model.named_parameters():
        value = parameter.detach().cpu().contiguous()
        digest = hashlib.sha256()
        digest.update(str(tuple(value.shape)).encode("ascii"))
        digest.update(str(value.dtype).encode("ascii"))
        digest.update(value.view(torch.uint8).numpy().tobytes())
        hashes[name] = digest.hexdigest()
    return hashes


def parameter_digest(model):
    digest = hashlib.sha256()
    for name, value in sorted(parameter_hashes(model).items()):
        digest.update(name.encode("utf-8"))
        digest.update(value.encode("ascii"))
    return digest.hexdigest()


def gradient_audit(model):
    """Return JSON-safe module counts and current gradient norms.

    A trainable module can legitimately have no gradient.  For example, the
    original random-exploration objective does not train the progress head.
    This audit distinguishes no gradient from a computed zero gradient.
    """
    groups = {}
    frozen_with_gradient = []
    for name, parameter in model.named_parameters():
        group = groups.setdefault(name.split(".", 1)[0], {
            "parameters": 0, "trainable_parameters": 0,
            "parameters_with_gradient": 0, "gradient_squared_l2": 0.0,
            "nonfinite_gradient_elements": 0,
        })
        group["parameters"] += parameter.numel()
        group["trainable_parameters"] += parameter.numel() if parameter.requires_grad else 0
        if parameter.grad is not None:
            gradient = parameter.grad.detach()
            group["parameters_with_gradient"] += parameter.numel()
            group["nonfinite_gradient_elements"] += int((~torch.isfinite(gradient)).sum())
            group["gradient_squared_l2"] += float(gradient.double().square().sum())
            if not parameter.requires_grad:
                frozen_with_gradient.append(name)
    for group in groups.values():
        squared = group.pop("gradient_squared_l2")
        group["gradient_l2"] = math.sqrt(squared) if math.isfinite(squared) else None
    return {
        "groups": groups,
        "all_finite": all(g["nonfinite_gradient_elements"] == 0 for g in groups.values()),
        "frozen_parameters_with_gradient": frozen_with_gradient,
        "trainable_names": [n for n, p in model.named_parameters() if p.requires_grad],
    }


def _validate_batch(batch):
    if set(batch) != OBS_KEYS:
        raise ValueError("Training batches must contain only rgb/audio/proprio/actions")
    if not all(isinstance(value, torch.Tensor) for value in batch.values()):
        raise TypeError("Training batch values must be tensors")
    actions = batch["actions"]
    if actions.ndim != 3 or actions.shape[-1] != ACTION_DIM:
        raise ValueError("actions must have shape [batch, steps, ACTION_DIM]")
    b, t = actions.shape[:2]
    shapes = {
        "rgb": (b, t + 1, 3, 64, 64),
        "audio": (b, t + 1, 32, 16),
        "proprio": (b, t + 1, PROPRIO_DIM),
    }
    if b < 1 or t < 1 or any(tuple(batch[key].shape) != shape for key, shape in shapes.items()):
        raise ValueError("Observation/action lengths or sensory shapes do not match")


def _sample_trace(trace, count, source):
    samples = [item for item in trace if "episode" in item and "start" in item]
    if len(samples) < count:
        raise ValueError("Replay trace is missing sampled episode/start identities")
    selected = [dict(item, source=source) for item in samples[:count]]
    # Preserve any acoustic permutation metadata: a selected clip may receive
    # sound from another sampled clip under the legacy shuffle_audio ablation.
    selected.extend(dict(item, source=source) for item in trace if "episode" not in item)
    return selected


def sample_adaptation_batch(new_replay, device, arm, old_replay=None):
    """Draw a fixed-sized batch; replay_mix uses exactly half old/half new.

    Each Replay keeps its own RNG.  No new global or uncheckpointed generator is
    introduced.  Full batches are drawn from both replays, then half is used;
    unused samples incur no gradient or additional optimizer update.
    """
    if arm not in ADAPTATION_ARMS or arm == "frozen":
        raise ValueError("Sampling requires an updating adaptation arm")
    if arm == "replay_mix" and old_replay is None:
        raise ValueError("replay_mix requires a disjoint old-experience replay")
    batch, trace = new_replay.sample(device)
    _validate_batch(batch)
    size = batch["actions"].shape[0]
    if arm != "replay_mix":
        return batch, _sample_trace(trace, size, "new_experience")
    if size % 2:
        raise ValueError("replay_mix needs an even batch size for exactly 50/50 exposure")
    old, old_trace = old_replay.sample(device)
    _validate_batch(old)
    if any(old[key].shape != batch[key].shape for key in OBS_KEYS):
        raise ValueError("Old/new replay batch shapes differ")
    half = size // 2
    mixed = {key: torch.cat((batch[key][:half], old[key][:half]), dim=0) for key in OBS_KEYS}
    return mixed, (
        _sample_trace(trace, half, "new_experience")
        + _sample_trace(old_trace, half, "old_experience")
    )


def adaptation_step(model, optimizer, new_replay, device, arm, old_replay=None,
                    max_grad_norm=5.0, audit=False):
    """One original-objective update, or an explicit no-op frozen control.

    The returned trace records sampled observations and source membership only.
    Evaluation annotations and previous-model progress targets are not accepted.
    """
    if arm not in ADAPTATION_ARMS:
        raise ValueError(f"Unknown adaptation arm: {arm}")
    if getattr(model, "_supplement_arm", None) != arm:
        raise ValueError("Call configure_adaptation with this arm before updating")
    if arm == "frozen":
        if optimizer is not None:
            raise ValueError("The frozen arm must not have an optimizer")
        return {"arm": arm, "updated": False, "grad_norm": 0.0}, []
    if optimizer is None:
        raise ValueError("Updating arms require an optimizer")
    if not math.isfinite(max_grad_norm) or max_grad_norm <= 0:
        raise ValueError("max_grad_norm must be finite and positive")
    trainable = [parameter for parameter in model.parameters() if parameter.requires_grad]
    optimized = [parameter for group in optimizer.param_groups for parameter in group["params"]]
    if len(optimized) != len(trainable) or {id(p) for p in optimized} != {id(p) for p in trainable}:
        raise ValueError("Optimizer parameters differ from configured trainable parameters")
    batch, trace = sample_adaptation_batch(new_replay, device, arm, old_replay)
    model.train()
    optimizer.zero_grad(set_to_none=True)
    # Explicit None prevents accidentally changing the original objective.
    loss, stats = losses(model, batch, previous_model=None)
    if not bool(torch.isfinite(loss)):
        raise FloatingPointError("Adaptation loss is not finite")
    loss.backward()
    norm = torch.nn.utils.clip_grad_norm_(trainable, max_grad_norm, error_if_nonfinite=True)
    stats = dict(stats, arm=arm, updated=True, grad_norm=float(norm))
    if audit:
        stats["gradient_audit"] = gradient_audit(model)
    optimizer.step()
    return stats, trace


def read_sensory_episode(path):
    """Read the four-key observation schema; reject embedded hidden labels."""
    with np.load(Path(path), allow_pickle=False) as archive:
        if set(archive.files) != OBS_KEYS:
            raise ValueError("Sensory trajectory schema contains extra or missing keys")
        episode = {key: archive[key] for key in OBS_KEYS}
    actions = episode["actions"]
    if actions.ndim != 2 or actions.shape[-1] != ACTION_DIM:
        raise ValueError("Invalid action shape")
    steps = len(actions)
    expected = {"rgb": (steps + 1, 64, 64, 3), "audio": (steps + 1, 32, 16),
                "proprio": (steps + 1, PROPRIO_DIM)}
    if steps < 1 or any(episode[key].shape != shape for key, shape in expected.items()):
        raise ValueError("Trajectory must contain T issued actions and T+1 observations")
    if episode["rgb"].dtype != np.uint8:
        raise ValueError("RGB observations must use the original uint8 schema")
    if any(not np.isfinite(episode[key]).all() for key in ("audio", "proprio", "actions")):
        raise ValueError("Nonfinite sensory trajectory")
    return episode


def _tensor_episode(episode, device):
    tensors = {key: torch.as_tensor(value, device=device).float() for key, value in episode.items()}
    tensors["rgb"] = tensors["rgb"].permute(0, 3, 1, 2) / 255
    return tensors


def _encoded_history(model, episode):
    visual = model.visual(episode["rgb"])
    audio = episode["audio"]
    if model.cfg.ablation == "no_audio":
        audio = torch.zeros_like(audio)
    hearing = model.hearing(audio)
    actions = episode["actions"]
    previous = torch.cat((torch.zeros_like(actions[:1]), actions), dim=0)
    inputs = torch.cat((visual, hearing, episode["proprio"], model._actions(previous)), dim=-1)
    history, _ = model._memory(inputs.unsqueeze(0))
    return history[0], visual, hearing, previous


def _error_sums(predicted, target):
    if not bool(torch.isfinite(predicted).all() and torch.isfinite(target).all()):
        raise FloatingPointError("Nonfinite held-out body prediction or sensory target")
    squared = (predicted - target).double().square()
    return {"n_predictions": len(squared), "body_squared_error": float(squared.sum()),
            "position_squared_error": float(squared[:, :3].sum()),
            "grasp_squared_error": float(squared[:, 9].sum())}


def _error_metrics(sums):
    n = sums["n_predictions"]
    if not n:
        return {"n_predictions": 0, "body_mse": None, "position_mse": None,
                "position_rmse_m": None, "grasp_mse": None}
    position_mse = sums["position_squared_error"] / (3 * n)
    return {"n_predictions": n, "body_mse": sums["body_squared_error"] / (PROPRIO_DIM * n),
            "position_mse": position_mse, "position_rmse_m": math.sqrt(position_mse),
            "grasp_mse": sums["grasp_squared_error"] / n}


def _add_sums(total, sums):
    for key, value in sums.items():
        total[key] = total.get(key, 0) + value


def _clip_context_errors(model, episode, history, visual, hearing, previous, starts, length):
    # Only mid-episode clips can exhibit a false zero previous action.
    starts = starts[starts > 0]
    if not len(starts):
        return {}
    offsets = torch.arange(length, device=starts.device)
    index = starts[:, None] + offsets[None]
    pr = episode["proprio"][index]
    issued = model._actions(episode["actions"][index])
    inputs = torch.cat((visual[index], hearing[index], pr, model._actions(previous[index])), dim=-1)
    true_reset, _ = model._memory(inputs)
    zero_inputs = inputs.clone()
    zero_inputs[:, 0, -ACTION_DIM:] = 0
    zero_reset, _ = model._memory(zero_inputs)
    variants = {"episode_history": history[index], "clip_reset_true_previous": true_reset,
                "clip_reset_zero_previous": zero_reset}
    result = {}
    for name, hidden in variants.items():
        predictions = pr + model.body(torch.cat((hidden, issued), dim=-1))
        result[name] = {}
        for offset in range(length):
            sums = _error_sums(predictions[:, offset], episode["proprio"][index[:, offset] + 1])
            hidden_mse = float((hidden[:, offset] - history[index[:, offset]]).double().square().mean())
            result[name][str(offset + 1)] = dict(_error_metrics(sums), hidden_mse_vs_episode=hidden_mse)
    return result


@torch.no_grad()
def temporal_alignment_audit(model, episode_path, device, steps=None):
    """Numerically compare forward's issued-action pairing with online observe.

    This confirms equality when the clip begins at episode time zero.  It does
    not claim that a delayed actuator applies the currently issued action.
    The simulator delay changes the hidden transition, not the issued-action
    timestamp stored in observations.npz.
    """
    episode = read_sensory_episode(episode_path)
    steps = min(len(episode["actions"]), model.cfg.clip_steps if steps is None else int(steps))
    if steps < 1:
        raise ValueError("steps must be positive")
    episode = {key: value[:steps + (key != "actions")] for key, value in episode.items()}
    tensors = _tensor_episode(episode, device)
    batch = {key: value.unsqueeze(0) for key, value in tensors.items()}
    was_training = model.training
    try:
        model.eval()
        forward = model(batch)
        state = None
        hidden = []
        previous = np.zeros(ACTION_DIM, np.float32)
        for index in range(steps):
            observation = {key: episode[key][index] for key in ("rgb", "audio", "proprio")}
            h, state = model.observe(observation, previous, device, state)
            hidden.append(h[0])
            previous = episode["actions"][index]
        online = torch.stack(hidden)
        predictions = tensors["proprio"][:-1] + model.body(torch.cat((online, model._actions(tensors["actions"])), -1))
        return {
            "steps": steps,
            "forward_vs_online_hidden_max_abs": float((forward["h"][0] - online).abs().max()),
            "forward_vs_online_body_max_abs": float((forward["pred_body"][0] - predictions).abs().max()),
            "issued_action_pairing": "actions[t] conditions the prediction of observation[t+1] from observation[t]",
            "previous_action_pairing": "observation[t] is encoded with actions[t-1]; zero is correct only at episode start",
            "delay_interpretation": "issued action is timestamped at issue; applied action may be older under actuator delay",
        }
    finally:
        model.train(was_training)


@torch.no_grad()
def sensory_prediction_diagnostics(model, episode_paths, device, horizons=(1, 2, 4, 8),
                                   max_starts_per_episode=16):
    """Teacher-forced and CEM-matched free-run body errors on held-out replay.

    At horizon h, teacher forcing uses the true sensory history up to t+h-1
    and predicts t+h. Free-run starts with history only up to t, then feeds its
    own predicted visual latent and proprioception to the GRU. As in the
    original CEM planner, the most recent acoustic embedding is held constant.
    Both receive the same recorded future *issued actions*. No future sensory
    observation enters free-run. The returned trajectories enable clustered
    analysis; prediction windows within one trajectory are not independent.

    Every horizon uses exactly the same deterministic start indices. No RNG
    state, model parameter, model gradient, or training replay is modified.
    """
    horizons = tuple(sorted(set(int(h) for h in horizons)))
    if not horizons or horizons[0] < 1 or max_starts_per_episode < 1:
        raise ValueError("Positive horizons and max_starts_per_episode are required")
    paths = [Path(path) for path in episode_paths]
    if not paths:
        raise ValueError("At least one held-out sensory trajectory is required")
    if len({str(path.resolve()) for path in paths}) != len(paths):
        raise ValueError("Duplicate held-out sensory trajectory")
    longest = horizons[-1]
    total = {kind: {str(h): {} for h in horizons} for kind in ("teacher_forced", "free_run")}
    per_episode = []
    was_training = model.training
    try:
        model.eval()
        for path in paths:
            raw = read_sensory_episode(path)
            steps = len(raw["actions"])
            if steps < longest:
                raise ValueError(f"Trajectory {path} has {steps} actions, fewer than horizon {longest}")
            episode = _tensor_episode(raw, device)
            history, visual, hearing, previous = _encoded_history(model, episode)
            indices = np.linspace(0, steps - longest,
                                  min(max_starts_per_episode, steps - longest + 1), dtype=int)
            starts = torch.as_tensor(indices, device=device)
            h = history[starts].clone()
            pr = episode["proprio"][starts].clone()
            current_hearing = hearing[starts]
            metrics = {"teacher_forced": {}, "free_run": {}}
            for offset in range(longest):
                action = model._actions(episode["actions"][starts + offset])
                ha = torch.cat((h, action), dim=-1)
                predicted_visual = model.dynamics(ha)
                pr = pr + model.body(ha)
                horizon = offset + 1
                if horizon in horizons:
                    target = episode["proprio"][starts + horizon]
                    tf_current = episode["proprio"][starts + offset]
                    tf_hidden = history[starts + offset]
                    tf_prediction = tf_current + model.body(torch.cat((tf_hidden, action), -1))
                    for kind, prediction in (("teacher_forced", tf_prediction), ("free_run", pr)):
                        sums = _error_sums(prediction, target)
                        _add_sums(total[kind][str(horizon)], sums)
                        metrics[kind][str(horizon)] = _error_metrics(sums)
                if horizon < longest:
                    inputs = torch.cat((predicted_visual, current_hearing, pr, action), -1).unsqueeze(1)
                    next_hidden, _ = model._memory(inputs, h.unsqueeze(0))
                    h = next_hidden[:, 0]
            context = _clip_context_errors(model, episode, history, visual, hearing, previous,
                                           starts, longest)
            per_episode.append({"episode": str(path), "starts": indices.tolist(), "metrics": metrics,
                                "clip_context": context})
        return {
            "schema_version": 1,
            "horizons": list(horizons),
            "n_episodes": len(paths),
            "metrics": {kind: {h: _error_metrics(sums) for h, sums in by_horizon.items()}
                        for kind, by_horizon in total.items()},
            "per_episode": per_episode,
            "teacher_forced_definition": "terminal one-step prediction using true intermediate sensory history",
            "free_run_definition": "recursive predicted visual latent/proprioception; initial sound embedding held fixed, matching original CEM",
            "action_definition": "identical recorded issued actions in both rollouts; no future observations in free-run",
            "context_definition": "true episode history versus reset GRU with true/zero first previous action; teacher-forced sensory inputs thereafter",
            "interpretation": "prediction diagnostics are mechanistic secondary outcomes; executed task success is the primary endpoint",
        }
    finally:
        model.train(was_training)
