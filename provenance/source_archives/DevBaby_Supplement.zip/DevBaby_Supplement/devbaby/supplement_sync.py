"""Incremental, bounded HF result publication with dependency-first ordering.

This module never creates Jobs. Each upload batch is idempotent. The final commit
publishes experiment state and its file index together; a failed batch leaves the
previous state and index intact. New data precede checkpoints, which precede
completion markers. Completed physical panels are synced as an archive plus full
trace JSON; an interrupted panel is intentionally recomputed on a fresh worker.
"""
from __future__ import annotations

import hashlib
import json
from pathlib import Path
import time

from .utils import atomic_json

INDEX = '.supplement_sync_index.json'
STATE = 'supplement_state.json'
DIRECTORIES = {'experience', 'diagnostic_experience', 'checkpoints', 'diagnostics',
               'physical_panels', 'evaluations'}


def _sha(path):
    h = hashlib.sha256()
    with path.open('rb') as file:
        for chunk in iter(lambda: file.read(1 << 20), b''):
            h.update(chunk)
    return h.hexdigest()


def _phase(path, relative):
    """Return upload dependency layer, or None for deliberately local files."""
    parts = relative.parts
    if path.is_symlink() or not path.is_file():
        return None
    if any(part.startswith('.') or part == '__pycache__' for part in parts):
        return None
    if path.suffix in {'.tmp', '.pyc', '.lock'} or '.tmp.' in path.name:
        return None
    if len(parts) == 1:
        if path.name == STATE:
            return 100
        if path.suffix not in {'.json', '.csv', '.html', '.png', '.txt', '.md'}:
            return None
        if path.name in {'source_locator.json', 'launch_manifest.json',
                         'supplement_protocol.lock.json', 'runtime.json'}:
            return 0
        return 90
    if parts[0] not in DIRECTORIES:
        return None
    if parts[0] in {'experience', 'diagnostic_experience'}:
        # One complete recorded episode is the smallest training-data unit.
        if len(parts) < 5:
            return None
        episode = path.parents[len(parts)-5]
        if not (episode/'complete.json').is_file():
            return None
        return 20 if path.name == 'complete.json' else 10
    if parts[0] == 'checkpoints':
        if path.suffix == '.jsonl':
            return 30
        if path.suffix == '.pt':
            return 40
        if path.name == 'complete.json':
            return 60
        return 50
    if parts[0] == 'diagnostics':
        return 65
    if parts[0] == 'physical_panels':
        if len(parts) != 3 or parts[2] not in {'sensory.zip', 'panel.json'}:
            return None
        marker = path.parent/'panel.json'
        if not marker.is_file() or json.loads(marker.read_text()).get('complete') is not True:
            return None
        return 70 if path.name == 'sensory.zip' else 75
    if parts[0] == 'evaluations':
        return 80 if len(parts) == 3 and path.name == 'result.json' else None
    return None


def _files(root):
    result = []
    for path in sorted(root.rglob('*')):
        relative = path.relative_to(root)
        layer = _phase(path, relative)
        if layer is not None:
            result.append((layer, relative.as_posix(), path))
    return sorted(result)


def _batches(rows, max_files, max_bytes):
    batch, size, phase = [], 0, None
    for row in rows:
        layer, relative, path, metadata = row
        if batch and (layer != phase or len(batch) >= max_files or size+metadata['bytes'] > max_bytes):
            yield batch
            batch, size = [], 0
        batch.append(row); size += metadata['bytes']; phase = layer
    if batch:
        yield batch


def sync_run(root, repo, run_id, *, api=None, max_files=100, max_bytes=50*1024**2):
    """Sync changed files and publish state last; return local transfer counts.

    Files unchanged in size/mtime use the already validated digest. After a
    worker restore, changed timestamps trigger a fresh content hash; equal bytes
    still skip uploads. A local index is written only after the final remote
    commit succeeds. A lost HTTP response can repeat an idempotent data commit,
    but can never trigger a paid Job.
    """
    if max_files < 2 or max_bytes < 1:
        raise ValueError('Use at least two files per commit and a positive byte budget')
    if not repo:
        return {'uploaded_files': 0, 'uploaded_bytes': 0, 'commits': 0}
    root = Path(root).resolve()
    if not (root/STATE).is_file():
        raise FileNotFoundError('Write supplement_state.json before syncing')
    from huggingface_hub import CommitOperationAdd, HfApi
    api = api or HfApi()
    index_path = root/INDEX
    previous = json.loads(index_path.read_text()) if index_path.exists() else {}
    if previous and (previous.get('repo') != repo or previous.get('run_id') != run_id):
        raise ValueError('Sync index belongs to a different result run')
    old = previous.get('files', {})
    files = dict(old)
    changed = []
    for layer, relative, path in _files(root):
        stat = path.stat(); prior = old.get(relative, {})
        same_stat = prior.get('bytes') == stat.st_size and prior.get('mtime_ns') == stat.st_mtime_ns
        fingerprint = prior.get('sha256') if same_stat else _sha(path)
        metadata = {'sha256': fingerprint, 'bytes': stat.st_size, 'mtime_ns': stat.st_mtime_ns}
        files[relative] = metadata
        if prior.get('sha256') != fingerprint:
            changed.append((layer, relative, path, metadata))
    state_row = next((row for row in changed if row[1] == STATE), None)
    payload = dict(schema='devbaby-supplement-sync-v1', repo=repo, run_id=run_id, files=files)
    if not changed and payload == previous:
        return {'uploaded_files': 0, 'uploaded_bytes': 0, 'commits': 0}
    prefix = 'runs/'+run_id+'/'
    commits = 0

    def commit(operations, label):
        nonlocal commits
        # Repeating a content-addressed result commit is safe on lost responses.
        for attempt in range(3):
            try:
                api.create_commit(repo_id=repo, repo_type='dataset', operations=operations,
                                  commit_message=f'Supplement {run_id}: {label}')
                commits += 1
                return
            except Exception:
                if attempt == 2:
                    raise
                time.sleep(.2*(2**attempt))

    for batch in _batches([row for row in changed if row[1] != STATE], max_files, max_bytes):
        operations = []
        for _, relative, path, metadata in batch:
            stat = path.stat()
            if stat.st_size != metadata['bytes'] or stat.st_mtime_ns != metadata['mtime_ns']:
                raise RuntimeError('Result changed during synchronous upload: '+relative)
            operations.append(CommitOperationAdd(path_in_repo=prefix+relative, path_or_fileobj=path))
        commit(operations, f'{len(operations)} changed files')
    # Always republish the state with the index after changed dependencies, even
    # when its content did not change. Both become visible in one Git commit.
    state_bytes = (root/STATE).read_bytes()
    if hashlib.sha256(state_bytes).hexdigest() != files[STATE]['sha256']:
        raise RuntimeError('Experiment state changed during synchronous upload')
    commit([CommitOperationAdd(path_in_repo=prefix+STATE, path_or_fileobj=state_bytes),
            CommitOperationAdd(path_in_repo=prefix+INDEX,
                               path_or_fileobj=json.dumps(payload,sort_keys=True).encode())],
           'publish state and file index')
    atomic_json(index_path,payload)
    return {'uploaded_files': len(changed), 'uploaded_bytes': sum(row[3]['bytes'] for row in changed),
            'commits': commits}
