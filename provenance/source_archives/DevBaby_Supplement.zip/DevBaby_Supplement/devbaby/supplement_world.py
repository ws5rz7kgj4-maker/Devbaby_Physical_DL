"""Supplemental, seed-paired physical panels; the original World is unchanged.

This is a second task/workspace in the SAME PyBullet point-effector simulator,
not a second simulator or an anatomical infant. Controllers get sensory data
and a fixed task specification. Simulator properties, annotations and scoring
stay outside their API. Delay means a FIFO actuator-command delay, not delayed
speech and not a delay label given to the agent.
"""
from collections import deque
from dataclasses import asdict, dataclass, replace
from pathlib import Path
import json
import numpy as np
from scipy.io import wavfile

from .data import OBS_KEYS, RandomExplorer
from .physical import make_goal as legacy_goal, reference_action
from .utils import atomic_json, derived_seed
from .world import ACTION_DIM, TRAIN_COMBOS, World

SCHEMA_VERSION = "supplement-world-v1"
SPLITS = ("train", "diagnostic", "validation", "final")
TASKS = ("reach", "touch", "grasp_lift", "push")
DOMAINS = ("iid", "new_dynamics", "delay_0", "delay_1", "delay_2", "delay_3",
           "delay_4", "delay_6", "new_layout", "joint_physics")
SENSORY_KEYS = frozenset(("rgb", "audio", "proprio"))


@dataclass(frozen=True)
class DomainSpec:
    name: str
    condition: str = "iid"
    delay_steps: int = 0
    scene_family: str = "iid"

    def __post_init__(self):
        if self.delay_steps < 0 or int(self.delay_steps) != self.delay_steps:
            raise ValueError("delay_steps must be a nonnegative integer")
        if self.condition not in {"iid", "new_dynamics", "new_layout", "joint_physics"}:
            raise ValueError("Unknown underlying physical condition")


_DOMAIN_SPECS = {
    "iid": DomainSpec("iid"),
    "new_dynamics": DomainSpec("new_dynamics", "new_dynamics", 0, "dynamics"),
    "new_layout": DomainSpec("new_layout", "new_layout", 0, "layout"),
    "joint_physics": DomainSpec("joint_physics", "joint_physics", 3, "joint"),
    **{f"delay_{d}": DomainSpec(f"delay_{d}", "iid", d, "iid")
       for d in (0, 1, 2, 3, 4, 6)},
}


def get_domain(name):
    if isinstance(name, DomainSpec):
        return name
    aliases = {"dynamics": "new_dynamics", "new_delay": "delay_3",
               "layout": "new_layout", "joint": "joint_physics", "train": "iid"}
    name = aliases.get(name, name)
    if name not in _DOMAIN_SPECS:
        raise ValueError(f"Unknown domain {name!r}; choose from {DOMAINS}")
    return _DOMAIN_SPECS[name]


def panel_seed(namespace, domain, task, trial, split="final"):
    """Scenes depend on panel identity, never on model seed/condition/checkpoint.

    IID and each pure fixed-delay dose deliberately use identical initial
    scenes. Separate explicit splits cannot share seeds even with the same
    namespace and index. A namespace is a frozen experiment identifier.
    """
    if split not in SPLITS or task not in TASKS or trial < 0:
        raise ValueError("Invalid panel split, task or nonnegative trial index")
    return derived_seed(SCHEMA_VERSION, namespace, split,
                        get_domain(domain).scene_family, task, trial)


def make_panel(namespace, split="final", domains=DOMAINS, tasks=TASKS, trials=24):
    if trials < 1:
        raise ValueError("Each panel needs at least one scene")
    return [dict(namespace=namespace, split=split, domain=get_domain(d).name,
                 task=t, trial=i, scene_seed=panel_seed(namespace, d, t, i, split))
            for d in domains for t in tasks for i in range(trials)]


@dataclass(frozen=True)
class SupplementGoal:
    task: str
    position: tuple
    contact_position: tuple
    initial_object_position: tuple = ()
    object_target_position: tuple = ()
    push_direction: tuple = ()


class SupplementWorld(World):
    """Original dynamics with explicit fixed FIFO delays and a push tabletop.

    ``task='push'`` restricts the gripper open for every controller, including
    the oracle. This prohibits solving the push task by grasping. The actual
    issued command after that common action mask is what the learner records.
    """
    def __init__(self, cfg, speech, seed, spec="iid", objects=None,
                 caregiver=False, task="reach"):
        self.spec = get_domain(spec)
        if task not in TASKS:
            raise ValueError(f"Unknown task {task!r}")
        self.task = task
        self.table_height = 0.0
        # World retains a config reference; isolate it from caller mutations.
        super().__init__(replace(cfg), speech, seed, self.spec.condition,
                         objects=objects, caregiver=caregiver)

    def _build(self, requested):
        super()._build(requested)
        # Replace the parent's random 2/3 delay in joint with a specified dose.
        self.motor_delay = self.spec.delay_steps
        self.action_queue = deque(np.zeros(ACTION_DIM, np.float32)
                                  for _ in range(self.motor_delay))
        if self.task == "push":
            self._build_push_table()

    def _build_push_table(self):
        # Replace legacy floor props with a raised, narrower support surface.
        removed = set(self.props)
        for bid in removed:
            self.call("removeBody", bid)
        self.static_geometry = [g for g in self.static_geometry if g["id"] not in removed]
        self.props = []
        self.table_height = .05
        self.table = self._box([.42, .31, .025], [.55, 0, .025], [.31, .47, .43, 1])
        if self.spec.condition in {"new_layout", "joint_physics"}:
            # An off-axis barrier changes geometry without making every goal
            # impossible. Goal generation is confined to the clear central lane.
            self.props.append(self._box([.045, .07, .055], [.67, .225, .105],
                                        [.48, .36, .28, 1]))
        r = np.random.default_rng(derived_seed(self.seed, "push-table"))
        for i, obj in enumerate(self.objects):
            half_height = obj["size"] * (.85 if obj["shape"] == "cylinder" else 1.)
            pos = [float(r.uniform(.37, .45)), float(r.uniform(-.09, .09)),
                   self.table_height + half_height + .003]
            if i:
                pos[1] = -.22 + (i-1)*.11
                pos[0] = .84
            self.call("resetBasePositionAndOrientation", obj["id"], pos, [0, 0, 0, 1])
            self.call("resetBaseVelocity", obj["id"], [0, 0, 0], [0, 0, 0])
            obj["initial_position"] = pos
        hand = [float(r.uniform(.18, .24)), float(r.uniform(-.18, .18)), .24]
        self.call("resetBasePositionAndOrientation", self.hand, hand, [0, 0, 0, 1])
        self.call("resetBaseVelocity", self.hand, [0, 0, 0], [0, 0, 0])
        self.target = np.asarray(hand, dtype=float)
        for _ in range(60):
            self._physics_tick()
        self.previous_contacts = set()
        self.pending_audio[:] = 0
        self.events = []

    def step(self, action):
        requested = np.asarray(action, np.float32)
        if requested.shape != (ACTION_DIM,) or not np.isfinite(requested).all():
            raise ValueError("Action must have five finite components")
        issued = np.clip(requested, -1, 1).copy()
        if self.task == "push":
            issued[3] = -1
        obs, wav, annotation = super().step(issued)
        annotation["requested_action"] = requested.tolist()
        annotation["issued_action"] = issued.tolist()
        annotation["actuator_delay_steps"] = self.motor_delay
        return obs, wav, annotation

    def metadata(self):
        return {**super().metadata(), "schema": SCHEMA_VERSION,
                "domain_spec": asdict(self.spec), "task_family": self.task,
                "support_height_m": self.table_height,
                "workspace": "raised_push_table" if self.task == "push" else "original_floor",
                "push_gripper_mask": self.task == "push",
                "independent_simulator": False}


def make_goal(world, task, seed):
    """Privileged setup only. Fixed spatial goals are explicit task inputs."""
    obj = np.asarray(world.call("getBasePositionAndOrientation", world.object_ids[0])[0])
    if task != "push":
        goal, initial_height = legacy_goal(world, task, seed)
        return SupplementGoal(goal.task, goal.position, goal.contact_position,
                              tuple(obj)), initial_height
    rng = np.random.default_rng(derived_seed(seed, "push-goal"))
    angle = float(rng.uniform(-.3, .3))
    direction = np.array([np.cos(angle), np.sin(angle), 0.])
    travel = float(rng.uniform(.19, .24))
    target = obj + direction * travel
    radius = world.objects[0]["size"]
    contact = obj - direction * (radius + .055)
    hand_target = target - direction * (radius + .030)
    return SupplementGoal(task, tuple(hand_target), tuple(contact), tuple(obj),
                          tuple(target), tuple(direction)), float(obj[2])


def sensory_only(obs):
    # An explicit allow-list remains effective if World later adds more fields.
    return {key: np.asarray(obs[key]).copy() for key in SENSORY_KEYS}


def privileged_action(world, obs, goal, phase):
    """Feasibility reference with privileged simulator state, never a baseline.

    Queue compensation uses the true actuator delay and target. Do not compare
    this controller to learned policies as an equal-information competitor.
    """
    if goal.task != "push":
        # Legacy reference mutates a one-element phase list and returns only
        # its action. Keep the supplemental reference's explicit state API.
        legacy_phase = [phase]
        action = reference_action(world, obs, goal, legacy_phase)
        return action, legacy_phase[0]
    obj = np.asarray(world.call("getBasePositionAndOrientation", world.object_ids[0])[0])
    final = np.asarray(goal.object_target_position)
    offset = final - obj
    offset[2] = 0
    distance = float(np.linalg.norm(offset))
    direction = offset / max(distance, 1e-8)
    if distance < .04:
        target = np.asarray(obs["proprio"][:3], dtype=float)
    else:
        contact = obj - direction * (world.objects[0]["size"] + .035)
        if phase == 0:
            target = contact.copy(); target[2] += .13
            if np.linalg.norm(np.asarray(obs["proprio"][:3])-target) < .05:
                phase = 1
        elif phase == 1:
            target = contact.copy()
            if np.linalg.norm(np.asarray(obs["proprio"][:3])-target) < .045:
                phase = 2
        else:
            target = contact + direction * min(.035, distance)
    queued = world.target.copy()
    for pending in world.action_queue:
        queued = np.clip(queued + pending[:3]*world.motor_step,
                         [-.1, -.62, .045], [1.1, .62, .65])
    action = np.zeros(ACTION_DIM, np.float32)
    action[:3] = np.clip((target-queued)/world.motor_step, -1, 1)
    action[3] = -1
    return action, phase


def _write_episode(directory, cfg, observations, actions, audio, annotations, metadata, summary):
    directory = Path(directory)
    directory.mkdir(parents=True, exist_ok=True)
    arrays = {key: np.stack([obs[key] for obs in observations]) for key in SENSORY_KEYS}
    arrays["actions"] = np.asarray(actions, np.float32)
    assert set(arrays) == OBS_KEYS
    with (directory/"observations.tmp").open("wb") as stream:
        np.savez_compressed(stream, **arrays)
    (directory/"observations.tmp").replace(directory/"observations.npz")
    pcm = np.clip(np.concatenate(audio)*32767, -32768, 32767).astype(np.int16)
    wavfile.write(directory/"audio.wav", cfg.sample_rate, pcm)
    hidden = directory/"annotations"
    hidden.mkdir(exist_ok=True)
    atomic_json(hidden/"scene_and_language.json", metadata)
    with (hidden/"frames.jsonl").open("w", encoding="utf-8") as stream:
        for row in annotations:
            stream.write(json.dumps(row, ensure_ascii=False, allow_nan=False)+"\n")
    atomic_json(directory/"complete.json", summary)


def collect_episode(cfg, speech, directory, seed, domain="iid", *, task="reach",
                    caregiver=True, split="train", namespace="supplement-v1"):
    """Random exploration, Replay-compatible data and annotations kept apart.

    Caller supplies an explicit seed; use panel_seed(..., split='train') for a
    training panel. Cache identity is verified, so a path cannot silently reuse
    another domain or collection configuration.
    """
    if split not in {"train", "diagnostic"}:
        raise ValueError("Random adaptation data may only use train/diagnostic splits")
    spec = get_domain(domain)
    directory = Path(directory)
    identity = dict(schema=SCHEMA_VERSION, seed=int(seed), domain=asdict(spec), task=task,
                    cfg=asdict(cfg), caregiver=bool(caregiver), split=split, namespace=namespace)
    marker = directory/"complete.json"
    if marker.exists() and (directory/"observations.npz").exists():
        old = json.loads(marker.read_text())
        if old.get("identity") != identity:
            raise ValueError(f"Episode cache identity mismatch: {directory}")
        return old
    explorer = RandomExplorer(derived_seed(seed, "supplement-random-policy"))
    requested = [("yellow", "block")] if task == "push" else None
    with SupplementWorld(cfg, speech, seed, spec, requested, caregiver, task) as world:
        obs = sensory_only(world.observe())
        observations, annotations = [obs], [world.annotation()]
        actions, audio = [], []
        for _ in range(cfg.episode_steps):
            obs, wav, ann = world.step(explorer(obs))
            obs = sensory_only(obs)
            observations.append(obs); annotations.append(ann)
            actions.append(ann["issued_action"]); audio.append(wav)
        metadata = {**world.metadata(), "utterances": world.utterances, "scene_seed": int(seed),
                    "collection_identity": identity}
    summary = dict(identity=identity, seed=int(seed), condition=spec.name,
                   steps=len(actions), utterances=len(metadata["utterances"]),
                   impacts=sum(e["type"] == "impact" for a in annotations for e in a["events"]),
                   grasps=sum(e["type"] == "grasp" for a in annotations for e in a["events"]))
    _write_episode(directory, cfg, observations, actions, audio, annotations, metadata, summary)
    return summary


def run_trial(cfg, speech, domain, task, trial, namespace, controller_factory=None,
              *, model_seed=0, policy="learned", split="final", output_dir=None,
              record_sensory=False, steps=None):
    """Run a frozen controller on a held-out scene and return individual outcomes.

    ``controller_factory(controller_seed)`` must return ``controller(obs, goal)``.
    Factories receive no World reference. The controller seed is paired across
    domains/model variants; the scene seed is independent of model seed. The
    privileged reference is selected explicitly by ``policy='oracle'``.
    Evaluation does not perform learning; factories should disable gradients.
    """
    spec = get_domain(domain)
    seed = panel_seed(namespace, spec, task, trial, split)
    control_seed = derived_seed(namespace, split, "controller", model_seed, task, trial)
    steps = int(cfg.physics_steps if steps is None else steps)
    if steps < 3:
        raise ValueError("At least three control steps are required")
    if policy == "random":
        random = RandomExplorer(control_seed)
        controller = lambda obs, goal: random(obs)
    elif policy == "oracle":
        controller = None
    elif controller_factory is None:
        raise ValueError("A controller_factory is required for non-reference policies")
    else:
        controller = controller_factory(control_seed)
    combo = ("red", "block") if task == "push" else TRAIN_COMBOS[trial % len(TRAIN_COMBOS)]
    with SupplementWorld(cfg, speech, seed, spec, [combo], False, task) as world:
        obs = sensory_only(world.observe())
        goal, initial_height = make_goal(world, task, seed)
        goal_position = np.asarray(goal.position)
        initial_obj = np.asarray(world.call("getBasePositionAndOrientation", world.object_ids[0])[0])
        observations, annotations = [obs], [world.annotation()]
        actions, applied, audio = [], [], []
        success_frames, distances, contacts, obj_positions, proprio = [], [], [], [], []
        phase = 0
        for _ in range(steps):
            if controller is None:
                action, phase = privileged_action(world, obs, goal, phase)
            else:
                action = controller(sensory_only(obs), goal)
            obs, wav, ann = world.step(action)
            obs = sensory_only(obs)
            hand = np.asarray(obs["proprio"][:3])
            obj = np.asarray(world.call("getBasePositionAndOrientation", world.object_ids[0])[0])
            contact = bool(world.call("getContactPoints", bodyA=world.hand, bodyB=world.object_ids[0]))
            distance = float(np.linalg.norm(hand-goal_position))
            if task == "reach":
                success = distance < .08
            elif task == "touch":
                success = contact
            elif task == "grasp_lift":
                success = (world.held_id == world.object_ids[0] and
                           obj[2] >= initial_height+.14 and distance < .13)
            else:
                distance = float(np.linalg.norm(obj[:2]-np.asarray(goal.object_target_position)[:2]))
                on_table = abs(float(obj[2])-initial_height) < .045
                success = distance < .065 and on_table and world.constraint is None
            success_frames.append(bool(success)); distances.append(distance); contacts.append(contact)
            obj_positions.append(obj.tolist()); proprio.append(obs["proprio"].tolist())
            actions.append(ann["issued_action"]); applied.append(ann["applied_action"])
            if record_sensory:
                observations.append(obs); audio.append(wav); annotations.append(ann)
        if task == "touch":
            success = any(all(success_frames[j:j+3]) for j in range(steps-2))
        else:
            success = all(success_frames[-3:])
        metadata = {**world.metadata(), "utterances": world.utterances, "scene_seed": int(seed),
                    "goal": asdict(goal), "goal_is_fixed_task_input": True}
        result = dict(schema=SCHEMA_VERSION, namespace=namespace, split=split,
                      domain=spec.name, task=task, trial=int(trial), seed=seed,
                      scene_seed=seed, controller_seed=control_seed, model_seed=int(model_seed),
                      policy=policy, privileged=policy == "oracle", success=bool(success),
                      goal=asdict(goal), initial_height=initial_height, steps=steps,
                      final_distance=distances[-1], min_distance=min(distances),
                      ever_success=any(success_frames), success_frames=success_frames,
                      distances=distances, object_contacts=contacts,
                      observed_proprio=proprio, issued_actions=actions, applied_actions=applied,
                      object_positions_scoring_only=obj_positions,
                      object_displacement=float(np.linalg.norm(np.asarray(obj_positions[-1])-initial_obj)),
                      scene=metadata)
    if record_sensory and output_dir is not None:
        directory = (Path(output_dir)/split/spec.name/task/
                     f"scene_{trial:05d}_{policy}_seed_{model_seed}")
        _write_episode(directory, cfg, observations, actions, audio, annotations, metadata,
                       dict(scene_seed=seed, model_seed=int(model_seed), policy=policy,
                            steps=steps, success=bool(success), split=split))
        result["sensory_directory"] = str(directory)
    return result


def feasibility_report(cfg, speech, namespace="supplement-feasibility-v1", *,
                       domains=DOMAINS, tasks=TASKS, trials=12, steps=None,
                       policies=("oracle", "feedback", "random")):
    """Diagnostic-only reference outcomes; never tune on final scenes."""
    from .supplement_control import FeedbackController
    if any(policy not in {"oracle", "feedback", "random"} for policy in policies):
        raise ValueError("Feasibility policies are oracle, feedback and random")
    rows = [run_trial(cfg, speech, d, t, i, namespace,
                      (lambda seed: FeedbackController(cfg, seed)) if policy == "feedback" else None,
                      policy=policy,
                      split="diagnostic", steps=steps)
            for d in domains for t in tasks for i in range(trials)
            for policy in policies]
    summary = []
    for domain in domains:
        for task in tasks:
            for policy in policies:
                selected = [r for r in rows if r["domain"] == get_domain(domain).name
                            and r["task"] == task and r["policy"] == policy]
                summary.append(dict(domain=get_domain(domain).name, task=task, policy=policy,
                                    n=len(selected), success_rate=float(np.mean([r["success"] for r in selected]))))
    return dict(namespace=namespace, split="diagnostic", trials=rows,
                summary=summary,
                caution="Privileged oracle feasibility is not an equal-information baseline.")


def main():
    """Standalone mechanical feasibility check; no GPU and no model needed."""
    import argparse
    from .config import Config
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--out", required=True)
    parser.add_argument("--config")
    parser.add_argument("--trials", type=int, default=4)
    parser.add_argument("--steps", type=int, default=64)
    parser.add_argument("--domains", default=",".join(DOMAINS))
    parser.add_argument("--tasks", default=",".join(TASKS))
    parser.add_argument("--namespace", default="supplement-feasibility-v1")
    args = parser.parse_args()
    if args.trials < 1:
        parser.error("--trials must be positive")
    cfg = Config.load(args.config) if args.config else Config(motor_domain_randomization=True)
    # Caregiver is disabled during evaluation; contact audio is synthesized by
    # the physics world, so no speech engine is needed for this mechanical check.
    report = feasibility_report(cfg, None, args.namespace, domains=args.domains.split(","),
                                tasks=args.tasks.split(","), trials=args.trials, steps=args.steps)
    atomic_json(args.out, report)
    print(json.dumps(report["summary"], indent=2))


if __name__ == "__main__":
    main()
