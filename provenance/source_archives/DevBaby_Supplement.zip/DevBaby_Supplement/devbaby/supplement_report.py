"""Paired physical-success analysis for the supplemental experiment.

Scenes are shared across models. Training seeds, rather than rollouts, are the
independent model-replication units. The sealed panel is never used to select a
checkpoint or a hyperparameter here.
"""
from __future__ import annotations

import csv
import html
import itertools
import json
from collections import defaultdict
from pathlib import Path

import numpy as np

from .utils import atomic_json, derived_seed

PRIMARY_CONTRASTS = (
    ("full_update", "frozen"),
    ("replay_mix", "full_update"),
    ("frozen_encoder", "full_update"),
    ("low_lr", "full_update"),
    ("history", "full_update"),
    ("history", "frozen"),
)
META_FIELDS = ("phase", "split", "seed", "model", "arm", "source_age", "budget", "domain", "task")
GROUP_FIELDS = META_FIELDS + ("training_domain",)


def sign_flip_p(differences):
    """Exact two-sided paired sign-flip test, with its symmetry assumption."""
    d = np.asarray(differences, dtype=float)
    if len(d) < 2:
        return None
    if len(d) > 20:
        raise ValueError("Exact sign-flip enumeration is limited to 20 model seeds")
    actual = abs(float(d.mean()))
    count = sum(abs(float(np.mean(d * signs))) >= actual - 1e-12
                for signs in itertools.product((-1, 1), repeat=len(d)))
    return count / (2 ** len(d))


def holm(p_values):
    """Holm correction retains the full predeclared family size."""
    result = [None] * len(p_values)
    valid = sorted((float(p), i) for i, p in enumerate(p_values) if p is not None)
    previous = 0.0
    for rank, (p, i) in enumerate(valid):
        previous = max(previous, min(1.0, p * (len(p_values) - rank)))
        result[i] = previous
    return result


def crossed_bootstrap(matrices, *, draws=5000, seed=1931, scene_panels=None):
    """Equal-cell mean CI; resample shared seed IDs and scenes within each cell.

    Each matrix has dimensions model seed x scene. Matrices must use the same
    ordered seeds. Scene resampling is paired between arms BEFORE this function
    receives their difference matrices, and the same scene indices are used for
    every sampled model within a domain/task cell. Identical scene-ID panels
    (e.g. paired delay strengths) also share scene resamples across cells.
    This respects crossed seeds
    and shared test scenes; it is not a rollout-level binomial interval.
    """
    matrices = [np.asarray(m, dtype=float) for m in matrices]
    if not matrices or matrices[0].shape[0] < 2:
        return [None, None]
    n = matrices[0].shape[0]
    if any(m.ndim != 2 or m.shape[0] != n or m.shape[1] < 1 for m in matrices):
        raise ValueError("Bootstrap requires aligned, nonempty seed-by-scene matrices")
    rng = np.random.default_rng(seed)
    seeds = rng.integers(0, n, size=(draws, n))
    values = np.zeros(draws, dtype=float)
    scene_draws = {}
    if scene_panels is not None and len(scene_panels) != len(matrices):
        raise ValueError("Scene panels must align with bootstrap matrices")
    for index, matrix in enumerate(matrices):
        panel_key = tuple(scene_panels[index]) if scene_panels is not None else index
        if panel_key not in scene_draws:
            scene_draws[panel_key] = rng.integers(0, matrix.shape[1], size=(draws, matrix.shape[1]))
        scenes = scene_draws[panel_key]
        # Chunking bounds memory if a user increases the sealed panel size.
        for start in range(0, draws, 200):
            stop = min(start + 200, draws)
            sample = matrix[seeds[start:stop, :, None], scenes[start:stop, None, :]]
            values[start:stop] += sample.mean(axis=(1, 2)) / len(matrices)
    return [float(x) for x in np.quantile(values, [.025, .975])]


def curve_statistics(x, y, thresholds=(.5, .75, .9)):
    """Checkpoint finite differences and observed, censored threshold times."""
    x = np.asarray(x, dtype=float)
    y = np.asarray(y, dtype=float)
    if len(x) != len(y) or not len(x) or np.any(np.diff(x) <= 0):
        raise ValueError("Curve checkpoints must have strictly increasing x values")
    rates = [None] + [float(v) for v in 100000 * np.diff(y) / np.diff(x)]
    if len(x) > 1:
        # Explicit trapezoids work with both NumPy 1.26 (runtime) and 2.x.
        area = lambda z: np.sum((z[:-1] + z[1:]) * np.diff(x) / 2)
        auc = float(area(y) / (x[-1] - x[0]))
        gain_auc = float(area(y - y[0]) / (x[-1] - x[0]))
    else:
        auc = gain_auc = None
    threshold_rows = {}
    for threshold in thresholds:
        reached = np.flatnonzero(y >= threshold)
        first = int(reached[0]) if len(reached) else None
        sustained = next((i for i in range(len(x)) if np.all(y[i:] >= threshold)), None)
        threshold_rows[str(threshold)] = {
            "first_observed_interactions": None if first is None else float(x[first]),
            "sustained_observed_interactions": None if sustained is None else float(x[sustained]),
            "right_censored": first is None,
            "already_reached_at_start": bool(y[0] >= threshold),
            "last_observed_interactions": float(x[-1]),
        }
    return {"normalized_auc": auc, "normalized_gain_auc": gain_auc,
            "growth_pp_per_1000_interactions": rates,
            "thresholds": threshold_rows}


def _load_records(root):
    records, ignored, seen = [], [], {}
    for path in sorted((Path(root) / "evaluations").rglob("*.json")):
        value = json.loads(path.read_text(encoding="utf-8"))
        if not isinstance(value, dict) or "trials" not in value:
            continue
        finished = value.get("complete") is True or value.get("status") in ("complete", "completed")
        if not finished:
            ignored.append(str(path.relative_to(root)))
            continue
        metadata = value.get("metadata", {k: value[k] for k in META_FIELDS if k in value})
        for trial in value["trials"]:
            # Trial "seed" is the physical scene seed in run_trial, never the
            # independently trained model seed. Cell metadata owns all grouping.
            row = dict(metadata)
            if any(k not in row for k in META_FIELDS):
                raise ValueError(f"Missing analysis metadata in {path}")
            if "model_seed" in trial and int(trial["model_seed"]) != int(metadata["seed"]):
                raise ValueError(f"Trial model_seed disagrees with cell metadata in {path}")
            for field in ("domain", "task", "split"):
                if field in trial and trial[field] != metadata[field]:
                    raise ValueError(f"Trial {field} disagrees with cell metadata in {path}")
            success = trial.get("success")
            if success not in (True, False, 0, 1):
                raise ValueError(f"Physical success must be binary in {path}")
            if "scene_seed" not in trial:
                raise ValueError(f"A paired scene identifier is required in {path}")
            row["training_domain"] = metadata.get("training_domain", "none")
            row.update(scene_seed=str(trial["scene_seed"]), trial=int(trial.get("trial", 0)),
                       success=float(success))
            row["seed"] = int(row["seed"])
            row["budget"] = int(row["budget"])
            row["source_age"] = int(row["source_age"])
            key = tuple(row[k] for k in GROUP_FIELDS) + (row["scene_seed"],)
            if key in seen:
                raise ValueError(f"Duplicate scene result in {path} and {seen[key]}; refusing double counting")
            seen[key] = path
            records.append(row)
    return records, ignored


def _trial_count(protocol, domain, task):
    value = protocol.get("final_trials", protocol.get("final_trials_per_task_domain"))
    if isinstance(value, dict):
        value = value.get(domain, value.get("default"))
        if isinstance(value, dict):
            value = value.get(task, value.get("default"))
    return int(value) if value is not None else None


def _paired_matrices(records, protocol, first, second):
    seeds = list(map(int, protocol.get("seeds", [])))
    domains = protocol.get("adaptation_domains", [])
    tasks = protocol.get("adaptation_tasks", [])
    budgets = protocol.get("budgets", [])
    age = protocol.get("mature_source_age")
    if age is None and protocol.get("source_ages"):
        age = max(protocol["source_ages"])
    if not seeds or not domains or not tasks or not budgets or age is None:
        return [], [], ["Protocol lacks seeds, adaptation domains/tasks, budgets, or mature_source_age"]
    selected = [r for r in records if r["phase"] == "adaptation" and r["split"] == "final"
                and r["source_age"] == int(age) and r["budget"] == max(budgets)
                and r["arm"] in (first, second)]
    lookup = defaultdict(dict)
    for row in selected:
        key = (row["arm"], row["domain"], row["task"], row["seed"])
        if row["scene_seed"] in lookup[key]:
            raise ValueError("Two model types share an inferential arm label; use unique arm names")
        lookup[key][row["scene_seed"]] = row["success"]
    errors, matrices, panels = [], [], []
    for domain in domains:
        for task in tasks:
            cells = [lookup[(arm, domain, task, seed)] for arm in (first, second) for seed in seeds]
            panel = set(cells[0])
            if not panel or any(set(cell) != panel for cell in cells):
                errors.append(f"{first} vs {second}: incomplete/unpaired scenes in {domain}/{task}")
                continue
            expected = _trial_count(protocol, domain, task)
            if expected is not None and len(panel) != expected:
                errors.append(f"{domain}/{task}: {len(panel)} scenes, expected {expected}")
                continue
            order = sorted(panel)
            a = np.array([[lookup[(first, domain, task, seed)][scene] for scene in order] for seed in seeds])
            b = np.array([[lookup[(second, domain, task, seed)][scene] for scene in order] for seed in seeds])
            matrices.append(a - b)
            panels.append(order)
    return matrices, panels, errors


def primary_contrasts(records, protocol, complete=False):
    """All six contrasts are either evaluated together or withheld together."""
    prepared, reasons = [], []
    for first, second in PRIMARY_CONTRASTS:
        matrices, panels, errors = _paired_matrices(records, protocol, first, second)
        reasons.extend(errors)
        prepared.append((first, second, matrices, panels))
    if not complete:
        reasons.append("The overall experiment is not marked complete")
    if protocol.get("development_only", False):
        reasons.append("Development-only execution is not a formal result")
    if len(protocol.get("seeds", [])) < 2:
        reasons.append("At least two independent trained model seeds are required for inference")
    if reasons:
        return [], sorted(set(reasons))
    results = []
    for first, second, matrices, panels in prepared:
        differences = np.mean([m.mean(axis=1) for m in matrices], axis=0)
        interval = crossed_bootstrap(matrices, draws=int(protocol.get("bootstrap_replicates", protocol.get("bootstrap_draws", 5000))),
                                     seed=derived_seed("supplement-contrast", first, second), scene_panels=panels)
        results.append({"contrast": f"{first} - {second}", "first": first, "second": second,
                        "mean_difference_pp": float(differences.mean() * 100),
                        "crossed_seed_scene_ci95_pp": [None if v is None else v * 100 for v in interval],
                        "per_seed_differences_pp": (differences * 100).tolist(),
                        "n_model_seeds": len(differences), "n_domain_task_cells": len(matrices),
                        "scenes_per_cell": [m.shape[1] for m in matrices],
                        "exact_paired_sign_flip_p": sign_flip_p(differences)})
    adjusted = holm([r["exact_paired_sign_flip_p"] for r in results])
    for row, p in zip(results, adjusted):
        row["holm_p"] = p
        row["positive_evidence"] = bool(p is not None and p < .05 and row["mean_difference_pp"] > 0)
    return results, []


def _write_csv(path, rows, fields):
    with open(path, "w", newline="", encoding="utf-8") as stream:
        writer = csv.DictWriter(stream, fieldnames=fields, extrasaction="ignore")
        writer.writeheader()
        for row in rows:
            writer.writerow({k: json.dumps(v, ensure_ascii=False) if isinstance(v, (list, dict)) else v
                             for k, v in row.items()})


def _curves(records):
    groups = defaultdict(list)
    for row in records:
        key = tuple(row[k] for k in GROUP_FIELDS)
        groups[key].append(row)
    rows = []
    for key, values in sorted(groups.items(), key=lambda item: str(item[0])):
        rows.append({**dict(zip(GROUP_FIELDS, key)), "n_scenes": len(values),
                     "success_rate": float(np.mean([v["success"] for v in values])),
                     "scene_panel": sorted(v["scene_seed"] for v in values)})
    trajectories = defaultdict(list)
    for row in rows:
        development = row["phase"] in ("development", "developmental")
        axis = "source_age" if development else "budget"
        identity = tuple((k, row[k]) for k in GROUP_FIELDS if k != axis)
        trajectories[(identity, axis)].append(row)
    stats_rows = []
    for (identity, axis), points in trajectories.items():
        points.sort(key=lambda r: r[axis])
        stats = curve_statistics([r[axis] for r in points], [r["success_rate"] for r in points])
        paired = all(p["scene_panel"] == points[0]["scene_panel"] for p in points)
        for point, slope in zip(points, stats["growth_pp_per_1000_interactions"]):
            point["axis"] = axis
            point["growth_pp_per_1000_interactions"] = slope if paired else None
            point["same_scene_panel_across_checkpoints"] = paired
        stats_rows.append({**dict(identity), "axis": axis, "checkpoints": [r[axis] for r in points],
                           "same_scene_panel_across_checkpoints": paired, **stats})
    return rows, stats_rows



def _learning_progress(rows, protocol):
    """Balanced adaptation curves expose improvement separately from head start."""
    selected = [r for r in rows if r["phase"] == "adaptation" and r["split"] == "validation"]
    cohorts = sorted({(r["model"], r["arm"], r["source_age"]) for r in selected})
    domains, tasks = protocol.get("adaptation_domains", []), protocol.get("adaptation_tasks", [])
    budgets = list(protocol.get("budgets", []))
    if not domains or not tasks or not budgets:
        return [], []
    lookup = {(r["model"], r["arm"], r["source_age"], r["seed"], r["domain"], r["task"], r["budget"]): r
              for r in selected}
    complete, missing = [], []
    for model, arm, age in cohorts:
        for seed in protocol.get("seeds", []):
            values, paired = [], True
            absent = 0
            for budget in budgets:
                cells = []
                for domain in domains:
                    for task in tasks:
                        key = (model, arm, age, seed, domain, task, budget)
                        cell = lookup.get(key)
                        if cell is None:
                            absent += 1
                        else:
                            cells.append(cell["success_rate"])
                            paired &= cell["same_scene_panel_across_checkpoints"]
                values.append(float(np.mean(cells)) if len(cells) == len(domains) * len(tasks) else None)
            identity = dict(model=model, arm=arm, source_age=age, seed=seed)
            if absent:
                missing.append({**identity, "missing_domain_task_budget_cells": absent})
                continue
            statistics = curve_statistics(budgets, values)
            if not paired:
                statistics["growth_pp_per_1000_interactions"] = [None] * len(budgets)
            complete.append({**identity, "budgets": budgets, "success_rates": values,
                             "same_scene_panel_across_checkpoints": paired,
                             "n_domain_task_cells": len(domains) * len(tasks), **statistics})
    return complete, missing


def _plot(root, rows):
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    fig, axes = plt.subplots(2, 3, figsize=(16, 9), constrained_layout=True)
    titles = [("Developmental physical success", "Base-training interactions"),
              ("Delay strength", "Command delay (control steps)"),
              ("New-domain adaptation", "Additional random interactions"),
              ("Original-domain retention", "Additional random interactions"),
              ("New push task", "Additional random interactions"),
              ("Adaptation growth", "Additional random interactions")]
    for index, ax in enumerate(axes.flat):
        title, xlabel = titles[index]
        ax.set(title=title, xlabel=xlabel, ylabel="Success (%)" if index != 5 else "pp / 1,000 interactions")
        if index != 5:
            ax.set_ylim(0, 100)
        ax.grid(alpha=.2)
        selected = []
        for row in rows:
            phase, task, domain = row["phase"], row["task"], str(row["domain"])
            if index == 0 and phase in ("development", "developmental"):
                selected.append((row, row["source_age"]))
            elif index == 1 and phase in ("ood", "delay", "delay_sweep", "reference") and domain.startswith("delay_"):
                try:
                    selected.append((row, int(domain.split("_")[-1])))
                except ValueError:
                    pass
            elif index in (2, 5) and phase == "adaptation" and row["split"] == "validation" and task != "push":
                selected.append((row, row["budget"]))
            elif index == 3 and phase == "retention":
                selected.append((row, row["budget"]))
            elif index == 4 and (phase == "push" or task == "push"):
                selected.append((row, row["budget"]))
        if index in (3, 4) and selected:
            bars = defaultdict(list)
            for row, _ in selected:
                bars[f"{row['model']}/{row['arm']}"].append(row["success_rate"] * 100)
            names = sorted(bars)
            ax.bar(range(len(names)), [np.mean(bars[name]) for name in names], color="#357e9d")
            ax.set_xticks(range(len(names)), names, rotation=30, ha="right", fontsize=7)
            ax.set_xlabel("System / adaptation arm (descriptive endpoint means)")
            continue
        lines = defaultdict(lambda: defaultdict(list))
        # Aggregate equally over existing model seeds, task/domain cells. The CSV
        # exposes every cell; a missing panel is marked globally as partial.
        for row, x in selected:
            if index == 5:
                value = row.get("growth_pp_per_1000_interactions")
                if value is None:
                    continue
            else:
                value = row["success_rate"] * 100
            label = f"{row['model']}/{row['arm']} · age {row['source_age']} · {row['split']}"
            if index == 0:
                label = f"{row['model']}/{row['arm']} · {row['split']}"
            lines[label][x].append(value)
        for label, points in sorted(lines.items()):
            x = sorted(points)
            ax.plot(x, [np.mean(points[v]) for v in x], ".-", label=label, linewidth=1.5)
        if lines:
            ax.legend(fontsize=6, loc="best")
        else:
            ax.text(.5, .5, "No completed cells yet", ha="center", va="center", transform=ax.transAxes)
        if index == 5:
            ax.axhline(0, color="gray", linewidth=.8)
    fig.savefig(Path(root) / "supplement_curves.png", dpi=150)
    plt.close(fig)


def _html_table(rows, fields):
    if not rows:
        return "<p>尚无可报告结果。</p>"
    header = "".join(f"<th>{html.escape(label)}</th>" for _, label in fields)
    content = []
    for row in rows:
        cells = []
        for field, _ in fields:
            value = row.get(field)
            if isinstance(value, float):
                value = f"{value:.4g}"
            elif isinstance(value, (list, dict)):
                value = json.dumps(value, ensure_ascii=False)
            cells.append(f"<td>{html.escape(str(value))}</td>")
        content.append("<tr>" + "".join(cells) + "</tr>")
    return "<table><thead><tr>" + header + "</tr></thead><tbody>" + "".join(content) + "</tbody></table>"



def _diagnostics(root):
    rows, alignment = [], []
    for path in sorted((Path(root) / "diagnostics").rglob("metrics.json")):
        value = json.loads(path.read_text(encoding="utf-8"))
        metadata = value.get("metadata", {})
        for mode, by_horizon in value.get("metrics", {}).items():
            for horizon, metrics in by_horizon.items():
                rows.append({**metadata, "mode": mode, "horizon": int(horizon), **metrics})
        if "alignment" in value:
            alignment.append({**metadata, **value["alignment"]})
    groups = defaultdict(list)
    for row in rows:
        if row.get("mode") == "free_run" and row.get("horizon") == 8:
            groups[(row.get("domain"), row.get("arm"))].append(row)
    compact = []
    for (domain, arm), values in sorted(groups.items()):
        distances = [r["position_rmse_m"] for r in values if r.get("position_rmse_m") is not None]
        compact.append({"domain": domain, "arm": arm, "n_model_seeds": len(values),
                        "mean_position_rmse_mm": float(np.mean(distances) * 1000) if distances else None})
    return rows, alignment, compact


def build_report(root, protocol, complete=False):
    """Write reproducible descriptive files and, only when complete, inference."""
    root = Path(root)
    root.mkdir(parents=True, exist_ok=True)
    records, ignored = _load_records(root)
    rows, trajectories = _curves(records)
    contrasts, withheld = primary_contrasts(records, protocol, complete=complete)
    learning, missing_learning = _learning_progress(rows, protocol)
    diagnostics, alignment, compact_diagnostics = _diagnostics(root)
    summary = {
        "status": "completed" if complete else "partial",
        "development_only": bool(protocol.get("development_only", False)),
        "completed_evaluation_cells": len(rows), "completed_rollouts": len(records),
        "ignored_incomplete_files": ignored, "primary_tests": contrasts,
        "inference_withheld_reasons": withheld, "curve_statistics": trajectories,
        "learning_progress": learning, "incomplete_learning_curves": missing_learning,
        "mechanism_diagnostics": compact_diagnostics, "temporal_alignment_audits": alignment,
        "physical_outcome": "Executed task success; no speech/language score enters this report.",
        "inference_unit": "Independent training seeds; crossed bootstrap resamples seeds and shared scenes within each domain/task.",
        "aggregation": "Each predeclared domain/task cell receives equal weight, then each model seed equal weight. Matching scene-ID panels across delay strengths share bootstrap scene draws.",
        "testing_assumption": "Exact two-sided sign-flip tests require exchangeable/symmetric paired seed differences under the null; Holm corrects the fixed six-contrast family. The p-values are conditional on this sampled scene panel; bootstrap intervals additionally describe sampling variability across scenes.",
        "growth_definition": "Finite differences in physical-success percentage points per 1,000 environment interactions; negative growth is retained. Higher initial success alone is not faster learning. Normalized gain AUC subtracts the starting success rate.",
        "threshold_definition": "First/sustained observed checkpoint reaching each threshold; no interpolation. Unreached thresholds are right-censored; starting above a threshold is explicitly marked.",
        "limitations": [
            "All data and physical scenes are simulated; simulator/contact/grasp abstractions limit external validity.",
            "Push is a new task in the same simulator with a supplied task decomposition and goal, not an independently validated infant world.",
            "The history baseline is a controlled baseline, not a claimed reproduction of a published state-of-the-art method.",
            "These measurements do not establish consciousness, language understanding, or improved general learning ability outside the tested distributions.",
            "The supplied spatial goal, task cost, and planner are part of the system; success is not autonomous discovery of goals.",
            "The sealed final panel is held out from training and parameter selection; visualizing it does not authorize retuning on it.",
            "No guarantee of statistical power or publication readiness follows from a completed run.",
        ],
    }
    atomic_json(root / "summary.json", summary)
    _write_csv(root / "curves.csv", rows, list(GROUP_FIELDS) + ["n_scenes", "success_rate", "axis", "growth_pp_per_1000_interactions", "same_scene_panel_across_checkpoints"])
    _write_csv(root / "contrasts.csv", contrasts, ["contrast", "mean_difference_pp", "crossed_seed_scene_ci95_pp", "n_model_seeds", "n_domain_task_cells", "exact_paired_sign_flip_p", "holm_p", "positive_evidence", "per_seed_differences_pp"])
    _write_csv(root / "learning_progress.csv", learning, ["model", "arm", "source_age", "seed", "budgets", "success_rates", "growth_pp_per_1000_interactions", "normalized_auc", "normalized_gain_auc", "same_scene_panel_across_checkpoints", "thresholds"])
    _write_csv(root / "diagnostics.csv", diagnostics, ["seed", "source_age", "domain", "arm", "budget", "split", "mode", "horizon", "n_predictions", "body_mse", "position_mse", "position_rmse_m", "grasp_mse"])
    _plot(root, rows)
    status = "运行完成" if complete else "部分结果：实验尚未完成"
    if protocol.get("development_only", False):
        status += " · 功能检查，不是正式研究结果"
    warning = "<ul>" + "".join(f"<li>{html.escape(v)}</li>" for v in withheld) + "</ul>" if withheld else ""
    tests = _html_table(contrasts, [("contrast", "预设对比"), ("mean_difference_pp", "成功率差（百分点）"),
                                   ("crossed_seed_scene_ci95_pp", "种子 × 场景 95% 区间"), ("holm_p", "Holm p")])
    diagnostic_table = _html_table(compact_diagnostics, [("domain", "情境"), ("arm", "更新条件"), ("n_model_seeds", "模型种子数"), ("mean_position_rmse_mm", "8 步递推位置 RMSE（mm）")])
    page = f'''<!doctype html><html lang="zh"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>DevBaby 补充实验</title>
<style>body{{font:16px/1.65 system-ui,sans-serif;max-width:1200px;margin:32px auto;padding:20px;color:#16293c;background:#f6f8fb}}h1,h2{{line-height:1.25}}.status,table{{background:white;padding:16px;border-radius:8px}}img{{width:100%;height:auto}}table{{border-collapse:collapse;width:100%;font-size:14px}}td,th{{padding:10px;text-align:left;border-bottom:1px solid #dce3eb}}a{{color:#075e99}}li{{margin:5px 0}}code{{background:#e8eef5}}</style></head><body>
<h1>物理交互泛化与学习进步</h1><p class="status">{html.escape(status)} · 已完成 {len(rows)} 个评估单元 / {len(records)} 次物理试验</p>
<p>主要指标是模型在新物理情境中实际执行任务的成功率。所有训练与评估数据均由模拟器生成；曲线不以语言或语音识别成绩替代物理成功率。</p>
<img src="supplement_curves.png" alt="发展、动作延迟、适应、保持、推动任务和增长速度曲线">
<p><a href="curves.csv">逐种子、任务与情境曲线 CSV</a> · <a href="contrasts.csv">预设比较 CSV</a> · <a href="learning_progress.csv">等权学习曲线与新增学习收益 CSV</a> · <a href="summary.json">完整统计与删失信息 JSON</a></p>
<h2>预设的最终比较</h2>{tests}{warning}
<p>比较使用成熟模型、固定追加交互预算和新的封存场景。每个情境与任务等权；独立训练种子是模型重复的统计单位。区间按种子及每个任务情境内的共享场景进行交叉自助抽样；同一次抽样对各对照使用相同场景。配对符号翻转检验以固定场景组为条件，并假设零假设下种子差值可交换且对称；六项比较统一进行 Holm 校正。</p>
<h2>怎样读取增长曲线</h2><p>增长速度是相邻观测点成功率的差，单位为“每 1,000 次环境交互增加的百分点”。负值保留。初始成功率高不等于学得更快；基线扣除后的曲线面积另行报告。阈值时间只使用实际观测点：未达到阈值记录为右删失，不填造一个达到时间。曲线图显示已完成单元的描述性均值；部分运行不能据此作完整比较。</p>
<h2>机制诊断（次要指标）</h2>{diagnostic_table}<p><a href="diagnostics.csv">全部预测误差 CSV</a> · 时间对齐检查保存在 summary.json。一步预测使用真实中间感知；递推预测只使用初始感知并继续预测，匹配规划器假设。两者不能当作同一种难度的预测任务。预测误差变化是机制线索，不能单独证明成功率变化的因果机制。</p>
<h2>研究边界</h2><ul>
<li>新增推动任务与几何变化仍属于同一个模拟器；不能据此宣称已经在独立婴儿仿真器中复现。</li>
<li>目标位置、规划器和任务代价由实验提供；动作历史网络是受控基线，不冒充已有论文方法的完整复现。</li>
<li>这些结果不证明意识、语言理解或一般学习能力的涌现。模拟成功率不能直接外推到真实婴儿或机器人。</li>
<li>封存测试用于最终检验；看到其结果后再调整模型，需要再次建立新的独立测试。</li>
<li>运行完整不保证统计功效、结果为正或论文录用。</li></ul></body></html>'''
    (root / "report.html").write_text(page, encoding="utf-8")
    return summary


def main():
    import argparse
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("root", type=Path)
    parser.add_argument("--protocol", type=Path, required=True)
    parser.add_argument("--complete", action="store_true", help="Only set after the locked experiment matrix is complete")
    args = parser.parse_args()
    build_report(args.root, json.loads(args.protocol.read_text()), complete=args.complete)


if __name__ == "__main__":
    main()
