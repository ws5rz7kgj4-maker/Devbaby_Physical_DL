#!/usr/bin/env python3
"""One-command supplemental experiment launcher; no local Torch installation.

Only launch/run/resume may create a paid Job. The default is launch. Repeated
commands reuse the recorded Job; uncertain submission outcomes never auto-retry.
Hugging Face tokens remain in the normal HF login cache and Jobs secrets.
"""
from __future__ import annotations

import argparse
from contextlib import contextmanager
import hashlib
import importlib.metadata
import io
import json
import os
from pathlib import Path, PurePosixPath
import re
import shlex
import subprocess
import sys
import time
import zipfile

ROOT = Path(__file__).resolve().parent
LAUNCHER_HUB_VERSION = "1.7.2"  # Adds public Job labels; isolated from runtime 0.36.
IMAGE = "pytorch/pytorch:2.6.0-cuda12.4-cudnn9-devel"
SOURCE_RUN = "formal-physical-eef2ff40"
SOURCE_JOB = "6adaef78c191903149a7ac03"
SOURCE_HASH = "eef2ff40383ff64a46d1a0bc186a3829fc6502ce09700d5e7120e53ae65d8840"
SOURCE_PROTOCOL = "6d7277597bf82f318cb8db9b111cdc2c5af3962135f3ea7c940dbbfdc66b5976"
TERMINAL = {"COMPLETED", "ERROR", "CANCELED", "CANCELLED", "DELETED", "TIMEOUT", "TIMED_OUT"}
RESERVED = {"HOME", "PATH", "PORT", "JOB_ID", "HF_JOB_ID", "CPU_CORES", "MEMORY", "ACCELERATOR", "CODEX_HOME"}
REPORT_FILES = ("report.html", "summary.json", "curves.csv", "contrasts.csv", "learning_progress.csv",
                "diagnostics.csv", "supplement_curves.png", "supplement_state.json",
                "supplement_protocol.lock.json", "runtime.json", "failure.txt", "planned_evaluations.json",
                "source_locator.json", "launch_manifest.json")

BOOTSTRAP = r'''
import hashlib, os, pathlib, subprocess, sys, zipfile
from huggingface_hub import hf_hub_download
if not (3,10) <= sys.version_info[:2] <= (3,11):
    raise RuntimeError('The fixed PyTorch 2.6 image must provide Python 3.10/3.11')
archive = hf_hub_download(os.environ['SUPPLEMENT_CODE_REPO'], os.environ['SUPPLEMENT_CODE_PATH'], repo_type='dataset', revision=os.environ['SUPPLEMENT_CODE_REVISION'])
if hashlib.sha256(pathlib.Path(archive).read_bytes()).hexdigest() != os.environ['SUPPLEMENT_CODE_SHA256']:
    raise RuntimeError('Uploaded source checksum mismatch')
root = pathlib.Path('/tmp/devbaby-supplement-code'); root.mkdir(exist_ok=True)
with zipfile.ZipFile(archive) as z:
    for info in z.infolist():
        if not (root/info.filename).resolve().is_relative_to(root.resolve()) or (info.external_attr >> 16) & 0o170000 == 0o120000:
            raise RuntimeError('Unsafe source archive')
    z.extractall(root)
subprocess.run([sys.executable, '-u', str(root/'supplement_cloud.py'), '--manifest-repo', os.environ['SUPPLEMENT_CODE_REPO'], '--manifest-path', os.environ['SUPPLEMENT_MANIFEST_PATH'], '--manifest-revision', os.environ['SUPPLEMENT_CODE_REVISION']], cwd=root, check=True)
'''


def atomic(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(path.name + f".{os.getpid()}.tmp")
    with tmp.open("w", encoding="utf-8") as f:
        json.dump(value, f, indent=2, ensure_ascii=False)
        f.write("\n"); f.flush(); os.fsync(f.fileno())
    os.replace(tmp, path)


def digest_bytes(data):
    return hashlib.sha256(data).hexdigest()


def read_json(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))


def source_bytes(root=None):
    """Stable archive; excludes credentials, launch records, results and caches."""
    root = Path(root or ROOT)
    allowed_dirs = {"devbaby", "configs", "tests"}
    allowed_top = {"SUPPLEMENT.py", "SUPPLEMENT_MAC.command", "supplement_cloud.py",
                   "supplement_protocol.json", "formal_protocol.json", "requirements-runtime.txt",
                   "requirements-launcher.txt", "pyproject.toml", "Dockerfile", "LICENSE"}
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as z:
        for file in sorted(root.rglob("*")):
            rel = file.relative_to(root)
            if any(p.startswith(".") or p == "__pycache__" for p in rel.parts):
                continue
            if rel.parts[0] not in allowed_dirs and rel.name not in allowed_top and not (len(rel.parts) == 1 and file.suffix == ".md"):
                continue
            if not file.is_file() or file.is_symlink() or file.suffix not in {".py", ".json", ".txt", ".md", ".toml", ".command", ""}:
                continue
            entry = zipfile.ZipInfo(rel.as_posix(), date_time=(2026, 1, 1, 0, 0, 0))
            entry.compress_type = zipfile.ZIP_DEFLATED
            z.writestr(entry, file.read_bytes())
    data = buf.getvalue()
    return data, digest_bytes(data)


def validate_local(root=None):
    root = Path(root or ROOT)
    required = ["supplement_protocol.json", "devbaby/supplement.py", "supplement_cloud.py",
                "devbaby/supplement_learning.py", "devbaby/supplement_world.py", "devbaby/supplement_control.py",
                "devbaby/supplement_plan.py",
                "requirements-runtime.txt"]
    for name in required:
        if not (root/name).is_file():
            raise RuntimeError(f"Package incomplete: {name}. Extract the complete ZIP first.")
    for file in [root/"SUPPLEMENT.py", root/"supplement_cloud.py", *sorted((root/"devbaby").glob("*.py"))]:
        compile(file.read_text(encoding="utf-8"), str(file), "exec")
    protocol_raw = (root/"supplement_protocol.json").read_bytes()
    protocol = json.loads(protocol_raw)
    if not isinstance(protocol, dict) or not protocol:
        raise ValueError("supplement_protocol.json must be a nonempty object")
    return protocol, digest_bytes(protocol_raw)


def ensure_launcher_environment():
    """Use an isolated launcher venv but share the existing HF token cache."""
    if sys.version_info[:2] < (3, 10):
        raise RuntimeError("Please install Python 3.11, then run python3 SUPPLEMENT.py")
    venv = ROOT/".venv-supplement-launch"
    python = venv/("Scripts/python.exe" if os.name == "nt" else "bin/python")
    if Path(sys.prefix).resolve() == venv.resolve():
        if importlib.metadata.version("huggingface_hub") != LAUNCHER_HUB_VERSION:
            raise RuntimeError("Launcher dependency changed; recreate .venv-supplement-launch")
        return
    if not python.exists():
        subprocess.run([sys.executable, "-m", "venv", str(venv)], check=True)
    check = subprocess.run([str(python), "-c", "from importlib.metadata import version; assert version('huggingface_hub') == " + repr(LAUNCHER_HUB_VERSION)], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    if check.returncode:
        subprocess.run([str(python), "-m", "pip", "install", "--disable-pip-version-check", "huggingface_hub==" + LAUNCHER_HUB_VERSION], check=True)
    raise SystemExit(subprocess.call([str(python), str(Path(__file__).resolve()), *sys.argv[1:]], cwd=ROOT))


def api_client():
    from huggingface_hub import HfApi, get_token
    token = get_token()
    if not token:
        hf = Path(sys.executable).parent/("hf.exe" if os.name == "nt" else "hf")
        subprocess.run([str(hf), "auth", "login"], check=True)
        token = get_token()
    if not token:
        raise RuntimeError("HF login did not produce a token; no Job submitted.")
    return HfApi(token=token), token


def remote_json(api, repo, filename, revision):
    from huggingface_hub import hf_hub_download
    return read_json(hf_hub_download(repo_id=repo, repo_type="dataset", filename=filename,
                                      revision=revision, token=api.token))


def valid_relative(name):
    path = PurePosixPath(name)
    return bool(name) and not path.is_absolute() and ".." not in path.parts and "\\" not in name


def validate_original_protocol(value):
    body = dict(value)
    stated = body.pop("sha256", None)
    if stated != SOURCE_PROTOCOL or digest_bytes(json.dumps(body, sort_keys=True).encode()) != SOURCE_PROTOCOL:
        raise ValueError("Original protocol checksum does not match the completed experiment")
    if body.get("source_archive") != "source/" + SOURCE_HASH + ".zip":
        raise ValueError("Original source archive hash mismatch")
    cfg = body.get("training_config", {})
    if cfg.get("exploration") != "random" or cfg.get("blocks") != 16 or cfg.get("updates_per_block") != 512:
        raise ValueError("Expected the original 16-block random-exploration experiment")
    if body.get("protocol", {}).get("seeds") != list(range(8)):
        raise ValueError("Expected original eight training seeds")


def validate_shards(manifest, member, available):
    shards = manifest.get("shards", [])
    expected = {f"data/shards/block_{i:04d}.zip" for i in range(16)}
    if len(shards) != 16 or {s.get("file") for s in shards} != expected:
        raise ValueError(f"{member}: original experience must contain all 16 unique block shards")
    result = []
    for shard in sorted(shards, key=lambda s: s["file"]):
        path = f"{member}/{shard['file']}"
        if not valid_relative(shard["file"]) or path not in available:
            raise ValueError(f"Original experience missing: {path}")
        if not re.fullmatch(r"[0-9a-f]{64}", str(shard.get("sha256", ""))) or not isinstance(shard.get("bytes"), int) or shard["bytes"] <= 0:
            raise ValueError(f"Invalid shard integrity metadata: {path}")
        result.append({"path": path, "sha256": shard["sha256"], "bytes": shard["bytes"]})
    return result


def inspect_original(api, repo, run_id, revision=None):
    """Metadata-only preflight. Large tensors/experience are downloaded in cloud."""
    info = api.repo_info(repo_id=repo, repo_type="dataset", revision=revision)
    revision = info.sha
    if not revision:
        raise ValueError(f"Cannot pin source revision: {repo}")
    base = f"runs/{run_id}"
    protocol = remote_json(api, repo, base+"/protocol.json", revision)
    validate_original_protocol(protocol)
    available = set(api.list_repo_files(repo_id=repo, repo_type="dataset", revision=revision))
    paths = [base+"/protocol.json"]
    shards, checkpoints = [], []
    for seed in range(8):
        member = f"{base}/members/full-s{seed}"
        meta = [member+"/config.json", member+"/data_manifest.json"]
        if not set(meta) <= available:
            raise ValueError(f"Missing original member metadata: full-s{seed}")
        cfg = remote_json(api, repo, meta[0], revision)
        expected_config = {**protocol["training_config"], "seed": seed}
        if cfg != expected_config:
            raise ValueError(f"Original member config mismatch: full-s{seed}")
        paths.extend(meta)
        shards.extend(validate_shards(remote_json(api, repo, meta[1], revision), member, available))
        for block, update in [(0, 0), (8, 4096), (16, 8192)]:
            path = f"{member}/checkpoints/model_{update:08d}.pt"
            if path not in available:
                raise ValueError(f"Missing pretrained checkpoint: {path}. No baseline will be retrained.")
            checkpoints.append({"seed": seed, "age_blocks": block, "update": update, "path": path})
    paths.extend(s["path"] for s in shards)
    paths.extend(c["path"] for c in checkpoints)
    # Pin available LFS digests for the cloud verifier; revision itself pins Git files.
    if hasattr(api, "get_paths_info"):
        details = api.get_paths_info(repo_id=repo, repo_type="dataset", revision=revision,
                                     paths=[c["path"] for c in checkpoints])
        indexed = {d.path: d for d in details}
        for checkpoint in checkpoints:
            detail = indexed.get(checkpoint["path"])
            lfs = getattr(detail, "lfs", None)
            sha = getattr(lfs, "sha256", None) if lfs is not None else None
            if isinstance(lfs, dict):
                sha = lfs.get("sha256")
            if sha:
                checkpoint["sha256"] = sha
            if getattr(detail, "size", None) is not None:
                checkpoint["bytes"] = detail.size
    return {"repo_id": repo, "repo_type": "dataset", "revision": revision,
            "run_id": run_id, "original_job_id": SOURCE_JOB, "protocol_sha256": SOURCE_PROTOCOL,
            "original_source_sha256": SOURCE_HASH, "allow_paths": sorted(set(paths)),
            "checkpoints": checkpoints, "shards": shards,
            "known_shard_bytes": sum(s["bytes"] for s in shards)}


def local_source_candidates(root, run_id):
    """Inspect bounded old launcher records, including sibling extracted packages."""
    root = Path(root)
    directories = [root/".launch_records", root.parent/".launch_records"]
    directories += [p/".launch_records" for p in root.parent.glob("*")
                    if p.is_dir() and "devbaby" in p.name.lower()]
    result = []
    for directory in directories:
        if not directory.is_dir():
            continue
        for path in sorted(directory.glob("*.json")):
            try:
                value = read_json(path)
            except (OSError, ValueError):
                continue
            if value.get("run_id") == run_id or value.get("job_id") == SOURCE_JOB:
                repo = value.get("result_repo")
                if repo and repo not in result:
                    result.append(repo)
    return result


def discover_original(api, owner, args):
    if args.source_repo:
        return inspect_original(api, args.source_repo, args.source_run)
    candidates = local_source_candidates(ROOT, args.source_run)
    for repo in candidates:
        try:
            return inspect_original(api, repo, args.source_run)
        except Exception as exc:
            print(f"Prior local record {repo}: {type(exc).__name__}; checking other sources.")
    # The recorded old Job is independent evidence of the dataset name.
    try:
        old_job = api.inspect_job(job_id=SOURCE_JOB, namespace=owner)
        observed = (getattr(old_job, "environment", {}) or {}).get("DEVBABY_RESULT_REPO")
        if observed:
            return inspect_original(api, observed, args.source_run)
    except Exception as exc:
        print(f"Original Job locator unavailable ({type(exc).__name__}); scanning account datasets.")
    matches = []
    failures = []
    account_datasets = sorted(api.list_datasets(author=owner),
                              key=lambda item: "devbaby" not in str(getattr(item, "id", "")).lower())
    for item in account_datasets:
        repo = getattr(item, "id", None)
        if not repo:
            continue
        try:
            if not api.file_exists(repo_id=repo, repo_type="dataset", filename=f"runs/{args.source_run}/protocol.json"):
                continue
            matches.append(inspect_original(api, repo, args.source_run))
        except Exception as exc:
            failures.append(f"{repo}: {type(exc).__name__}")
    if len(matches) == 1:
        return matches[0]
    if len(matches) > 1:
        raise RuntimeError("Multiple matching source datasets. Select one using --source-repo owner/repo: " + ", ".join(m["repo_id"] for m in matches))
    raise RuntimeError("Original pretrained checkpoints/raw experience could not be verified. No GPU Job submitted and no baseline retraining. Supply --source-repo owner/repo. Candidates: " + "; ".join(failures))


@contextmanager
def exclusive_lock(path):
    path = Path(path); path.parent.mkdir(parents=True, exist_ok=True)
    try:
        fd = os.open(path, os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0o600)
    except FileExistsError:
        raise RuntimeError(f"Submission lock exists: {path}. Another terminal may be submitting. Inspect status/HF Jobs before removing a stale lock.") from None
    with os.fdopen(fd, "w") as f:
        f.write(str(os.getpid()))
    try:
        yield
    finally:
        path.unlink(missing_ok=True)


def job_view(job):
    return {"job_id": job.id, "url": job.url,
            "status": getattr(job.status, "stage", str(job.status)).upper()}


def reconcile(api, owner, record):
    if record.get("job_id"):
        return job_view(api.inspect_job(job_id=record["job_id"], namespace=owner))
    if record.get("phase") == "submitting":
        key = record["submission_key"]
        matches = []
        for job in api.list_jobs(namespace=owner):
            labels = getattr(job, "labels", {}) or {}
            env = getattr(job, "environment", {}) or {}
            if labels.get("devbaby_supplement_key") == key or env.get("SUPPLEMENT_SUBMISSION_KEY") == key:
                matches.append(job)
        if len(matches) == 1:
            return job_view(matches[0])
        if len(matches) > 1:
            raise RuntimeError("More than one Job matched this submission key. Inspect HF Jobs; no new Job submitted.")
        raise RuntimeError("Previous submission outcome is unknown. No automatic retry or new charge was created. Run status again after checking HF Jobs; preserve the local record.")
    return None


def record_location(args, required=True):
    if args.record:
        path = Path(args.record).expanduser().resolve()
    else:
        latest = ROOT/".supplement_launch_records/latest.json"
        if not latest.exists():
            if required:
                raise FileNotFoundError("No supplemental launch record. Run launch first, or pass --record /absolute/path.json")
            return None
        path = Path(read_json(latest)["record"])
    if required and not path.exists():
        raise FileNotFoundError(path)
    return path


def record_paths(result_repo, run_id):
    directory = ROOT/".supplement_launch_records"
    key = digest_bytes((result_repo+"/"+run_id).encode())[:24]
    return directory/f"{key}.json", directory/f"{key}.lock"


def save_record(path, record):
    atomic(path, record)
    atomic(ROOT/".supplement_launch_records/latest.json", {"record": str(Path(path).resolve())})


def make_environment(repo, source_path, revision, digest, manifest_path, key):
    env = {"SUPPLEMENT_CODE_REPO": repo, "SUPPLEMENT_CODE_PATH": source_path,
           "SUPPLEMENT_CODE_REVISION": revision, "SUPPLEMENT_CODE_SHA256": digest,
           "SUPPLEMENT_MANIFEST_PATH": manifest_path, "SUPPLEMENT_SUBMISSION_KEY": key,
           "PYTHONUNBUFFERED": "1", "OMP_NUM_THREADS": "4"}
    if RESERVED & set(env):
        raise ValueError("Reserved platform variable in environment")
    return env


def show_job(record):
    value = {k: record[k] for k in ["job_id", "url", "status", "run_id", "result_repo"] if k in record}
    if record.get("result_repo") and record.get("run_id"):
        value["results_url"] = f"https://huggingface.co/datasets/{record['result_repo']}/tree/main/runs/{record['run_id']}"
    print(json.dumps(value, indent=2, ensure_ascii=False))


def download_patterns(base, all_files=False):
    # fnmatch '*' spans '/' on HF; default paths must therefore be exact names.
    return [base+"/*"] if all_files else [base+"/"+name for name in REPORT_FILES]


def experiment_plan(protocol):
    from devbaby.supplement_plan import plan
    return plan(protocol)


def show_budget(protocol):
    counts = experiment_plan(protocol)
    print("Counts describe the complete locked experiment; resume reuses completed units.")
    print(json.dumps({key: counts[key] for key in ["scheduled_cells", "scheduled_trials",
          "unique_execution_panels", "unique_execution_trials", "training", "limits"]
          if key in counts}, indent=2, ensure_ascii=False))
    print("24 hours is the per-Job hard cap, not a promise that the entire experiment finishes in one Job.")
    print("At 23 hours the runner saves progress. Further paid computation requires an explicit resume command; no automatic Job retries.")


def inspect_resume_output(api, repo, run_id, revision):
    """A terminal setup failure may safely resume only if its output is empty."""
    prefix = f"runs/{run_id}/"
    if api.file_exists(repo_id=repo, repo_type="dataset", filename=prefix+"supplement_state.json", revision=revision):
        state = remote_json(api, repo, prefix+"supplement_state.json", revision)
        if not state:
            raise RuntimeError("Uploaded supplemental state is empty")
        return True, state
    existing = [name for name in api.list_repo_files(repo_id=repo, repo_type="dataset", revision=revision)
                if name.startswith(prefix)]
    if existing:
        raise RuntimeError("Result files exist without supplemental state; refusing to discard possible checkpoints. Inspect the pinned result dataset.")
    return False, {"status": "setup_failed_before_output"}


def submit(api, token, owner, args, resume=False):
    protocol, protocol_sha = validate_local()
    source, code_sha = source_bytes()
    if resume:
        path = record_location(args)
        old = read_json(path)
        result_repo, run_id = old["result_repo"], old["run_id"]
        _, lock = record_paths(result_repo, run_id)
    else:
        result_repo = args.result_repo or f"{owner}/devbaby-supplement-results"
        run_id = args.run_id or "supplement-" + code_sha[:12]
        path, lock = record_paths(result_repo, run_id)
    if not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9._-]{0,95}", run_id):
        raise ValueError("Invalid run ID")
    with exclusive_lock(lock):
        old = read_json(path) if path.exists() else None
        if old:
            if old.get("code_sha256") != code_sha or old.get("protocol_sha256") != protocol_sha:
                raise RuntimeError("Code/protocol changed since this run was launched. Resume requires the original package; a fresh experiment needs a new --run-id.")
            view = reconcile(api, owner, old)
            if view:
                old.update(view); old["phase"] = "submitted"; save_record(path, old)
                if not resume or view["status"] not in TERMINAL:
                    show_job(old); print("Existing Job reused; no new Job submitted."); return old
            if resume and not view:
                raise RuntimeError("Cannot resume a run with no reconciled original Job")
        elif resume:
            raise RuntimeError("Resume needs a previous launch record")
        if resume:
            original = old["original_source"]
            result_revision = api.repo_info(repo_id=result_repo, repo_type="dataset").sha
            resume_has_output, state = inspect_resume_output(api, result_repo, run_id, result_revision)
            if state.get("status") in {"completed", "complete"}:
                print("Supplemental experiment is complete; no new Job submitted."); return old
            if not resume_has_output:
                print("Previous terminal Job stopped before uploading any run files; explicit resume will retry setup using the same pinned source and run ID.")
            attempt = int(old.get("attempt", 0)) + 1
            flavor = old["flavor"]
        else:
            original = discover_original(api, owner, args)
            result_revision = None; resume_has_output = False; attempt = 0; flavor = args.flavor
        if result_repo == original["repo_id"]:
            raise ValueError("Use a separate private supplemental result repository, not the original dataset")
        if not flavor.startswith(("t4-", "a10g-", "a100-", "a100x", "l4-", "l4x", "l40s-", "l40sx", "h100-", "h100x")):
            raise ValueError("Choose a GPU flavor; default is one t4-small")
        print(f"Original dataset verified: {original['repo_id']} @ {original['revision']}")
        print(f"24 pretrained checkpoints; 128 raw block shards; known compressed experience {original['known_shard_bytes']/1e9:.2f} GB")
        show_budget(protocol)
        api.create_repo(repo_id=result_repo, repo_type="dataset", private=True, exist_ok=True)
        if not api.repo_info(repo_id=result_repo, repo_type="dataset").private:
            raise RuntimeError("Supplemental result repository is public. Choose a new private --result-repo.")
        # Remote state blocks overwrites even after losing a local launcher directory.
        if not resume and api.file_exists(repo_id=result_repo, repo_type="dataset", filename=f"runs/{run_id}/supplement_state.json"):
            raise RuntimeError("Remote supplemental run already exists. Recover its local record and use resume; no overwrite or new Job.")
        submission_key = digest_bytes(f"{result_repo}/{run_id}/{attempt}".encode())[:32]
        # Reconcile remotely before first submit as well (e.g. launcher folder copied).
        for job in api.list_jobs(namespace=owner):
            env = getattr(job, "environment", {}) or {}
            labels = getattr(job, "labels", {}) or {}
            if labels.get("devbaby_supplement_key") == submission_key or env.get("SUPPLEMENT_SUBMISSION_KEY") == submission_key:
                recovered = {**(old or {}), "run_id": run_id, "result_repo": result_repo,
                             "owner": owner, "code_sha256": code_sha, "protocol_sha256": protocol_sha,
                             "original_source": original, "flavor": flavor, "attempt": attempt,
                             "phase": "submitted", "submission_key": submission_key, **job_view(job)}
                save_record(path, recovered); show_job(recovered)
                print("Matching remote Job recovered; no new Job submitted."); return recovered
        manifest = {"schema": "devbaby-supplement-launch-v1", "run_id": run_id, "result_repo": result_repo,
                    "original_source": original, "code_sha256": code_sha, "protocol_sha256": protocol_sha,
                    "image": IMAGE, "flavor": flavor, "hard_timeout_seconds": 86400,
                    "job_budget_seconds": 82800, "resume": resume, "resume_revision": result_revision,
                    "resume_has_output": resume_has_output,
                    "attempt": attempt, "submission_key": submission_key}
        source_path = f"supplement_source/{code_sha}.zip"
        manifest_path = f"launches/{run_id}/attempt_{attempt:03d}.json"
        from huggingface_hub import CommitOperationAdd
        commit = api.create_commit(repo_id=result_repo, repo_type="dataset",
                    operations=[CommitOperationAdd(path_in_repo=source_path, path_or_fileobj=source),
                                CommitOperationAdd(path_in_repo=manifest_path, path_or_fileobj=json.dumps(manifest, indent=2).encode()),
                                CommitOperationAdd(path_in_repo=f"launches/{run_id}/supplement_protocol.json", path_or_fileobj=(ROOT/"supplement_protocol.json").read_bytes())],
                    commit_message=f"Freeze supplemental experiment {run_id} attempt {attempt}")
        env = make_environment(result_repo, source_path, commit.oid, code_sha, manifest_path, submission_key)
        record = {**manifest, "owner": owner, "phase": "submitting", "code_revision": commit.oid,
                  "manifest_path": manifest_path, "source_path": source_path,
                  "previous_jobs": (old or {}).get("previous_jobs", []) + ([old["job_id"]] if resume else [])}
        # Durable state MUST precede the API request (network failure may hide success).
        save_record(path, record)
        command = ["bash", "-lc", "python -m pip install --disable-pip-version-check huggingface_hub==0.36.0 && python -u -c " + shlex.quote(BOOTSTRAP)]
        try:
            job = api.run_job(image=IMAGE, command=command, flavor=flavor, timeout="24h", namespace=owner,
                              env=env, secrets={"HF_TOKEN": token},
                              labels={"devbaby_supplement_key": submission_key, "devbaby_run": run_id.replace(".", "-")})
        except Exception as exc:
            # Never print an API exception body: it may contain the submission payload.
            print(f"Submission response unavailable ({type(exc).__name__}). Its outcome may be unknown; no retry was made.")
            print(f"Saved record: {path}\nRun: python3 SUPPLEMENT.py status")
            raise RuntimeError("Unknown submission outcome; use status reconciliation, not a new run ID") from None
        record.update(job_view(job)); record["phase"] = "submitted"
        save_record(path, record); show_job(record)
        return record


def manage(api, owner, args):
    path = record_location(args)
    record = read_json(path)
    owner = record.get("owner", owner)
    view = reconcile(api, owner, record)
    if not view:
        raise RuntimeError("No submitted Job in launch record")
    record.update(view); record["phase"] = "submitted"; save_record(path, record)
    if args.action == "status":
        show_job(record)
        try:
            revision = api.repo_info(repo_id=record["result_repo"], repo_type="dataset").sha
            state = remote_json(api, record["result_repo"], f"runs/{record['run_id']}/supplement_state.json", revision)
            print(json.dumps({"experiment_state": state}, indent=2, ensure_ascii=False))
        except Exception as exc:
            print(f"Experiment state not uploaded/available yet ({type(exc).__name__}).")
    elif args.action == "logs":
        for line in api.fetch_job_logs(job_id=record["job_id"], namespace=owner, follow=args.follow):
            print(line, end="" if str(line).endswith("\n") else "\n", flush=True)
    elif args.action == "cancel":
        if view["status"] in TERMINAL:
            print("Job is already terminal; no cancellation needed.")
        else:
            api.cancel_job(job_id=record["job_id"], namespace=owner)
            print("Cancellation requested. Already-uploaded checkpoints remain available for explicit resume.")
    elif args.action == "download":
        from huggingface_hub import snapshot_download
        repo = record["result_repo"]; base = f"runs/{record['run_id']}"
        revision = api.repo_info(repo_id=repo, repo_type="dataset").sha
        directory = Path(args.output or ROOT/"supplement_results").expanduser().resolve()
        # Default intentionally excludes tensors/raw experience; --all includes everything.
        patterns = download_patterns(base, all_files=args.all)
        snapshot_download(repo_id=repo, repo_type="dataset", revision=revision, token=api.token,
                          allow_patterns=patterns, local_dir=str(directory))
        print(f"Downloaded pinned revision {revision} to {directory/base}")


def parser():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("action", nargs="?", default="launch", choices=["launch", "run", "plan", "check", "status", "logs", "download", "cancel", "resume"])
    p.add_argument("--source-repo", help="Existing original dataset owner/repo; hashes still verified")
    p.add_argument("--source-run", default=SOURCE_RUN)
    p.add_argument("--result-repo", help="New/private supplemental dataset; default ACCOUNT/devbaby-supplement-results")
    p.add_argument("--run-id", help="New experiment ID; default deterministic source digest")
    p.add_argument("--flavor", default="t4-small", help="One GPU by default: t4-small")
    p.add_argument("--record", help="Path to an existing supplemental launch record")
    p.add_argument("--output", help="Local directory for download")
    p.add_argument("--follow", action="store_true", help="Follow logs until Job stops")
    p.add_argument("--all", action="store_true", help="Download checkpoints/raw recordings as well")
    return p


def main(argv=None):
    args = parser().parse_args(argv)
    os.chdir(ROOT)
    if args.action == "plan":
        protocol, sha = validate_local()
        _, code = source_bytes()
        print(json.dumps({"action": "plan_only_no_upload_no_paid_job", "image": IMAGE,
                          "flavor": args.flavor, "hard_limit_hours": 24, "cooperative_budget_hours": 23,
                          "source_run": args.source_run, "source_protocol_sha256": SOURCE_PROTOCOL,
                          "supplement_protocol_sha256": sha, "code_sha256": code,
                          "default_run_id": "supplement-"+code[:12], "experiment_plan": experiment_plan(protocol),
                          "protocol": protocol}, indent=2, ensure_ascii=False))
        return
    ensure_launcher_environment()
    api, token = api_client(); owner = api.whoami()["name"]
    if args.action == "check":
        protocol, sha = validate_local(); locator = discover_original(api, owner, args)
        print(json.dumps({"check": "passed_no_upload_no_paid_job", "owner": owner,
                          "protocol_sha256": sha, "original_source": {
                              **{key: locator[key] for key in ["repo_id", "revision", "run_id", "original_job_id",
                                 "protocol_sha256", "original_source_sha256", "known_shard_bytes"]},
                              "verified_checkpoint_paths": len(locator["checkpoints"]),
                              "verified_shard_paths": len(locator["shards"])}}, indent=2, ensure_ascii=False))
        show_budget(protocol)
    elif args.action in {"launch", "run", "resume"}:
        submit(api, token, owner, args, resume=args.action == "resume")
    else:
        manage(api, owner, args)


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("Interrupted. If submission had begun, run status to reconcile before retrying.", file=sys.stderr)
        raise SystemExit(130)
    except Exception as exc:
        # Known local errors have actionable messages; unexpected API errors are redacted.
        if isinstance(exc, (ValueError, RuntimeError, FileNotFoundError)):
            print(f"ERROR: {exc}", file=sys.stderr)
        else:
            print(f"ERROR: {type(exc).__name__}. No automatic Job retry. Run check/status to inspect.", file=sys.stderr)
        raise SystemExit(1)
