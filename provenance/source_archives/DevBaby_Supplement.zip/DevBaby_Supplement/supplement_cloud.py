#!/usr/bin/env python3
"""Cloud-only bootstrap for the pinned supplemental experiment.

Downloads immutable source artifacts, checks every raw shard, restores a pinned
supplemental checkpoint on explicit resume, and hands off to the experiment.
This module never submits Jobs and never retries a paid Job.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import shutil
import subprocess
import sys
import time
import zipfile

ROOT = Path(__file__).resolve().parent


def sha256_file(path):
    digest = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1024*1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def safe_extract(archive, destination, required_prefix=None):
    destination = Path(destination).resolve()
    destination.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(archive) as z:
        for info in z.infolist():
            posix = PurePosixPath(info.filename)
            if posix.is_absolute() or ".." in posix.parts or "\\" in info.filename:
                raise ValueError(f"Unsafe ZIP path: {info.filename}")
            if not (destination/info.filename).resolve().is_relative_to(destination):
                raise ValueError("ZIP destination escapes source root")
            if (info.external_attr >> 16) & 0o170000 == 0o120000:
                raise ValueError("Symbolic links are forbidden in source ZIP")
            if required_prefix and not info.filename.startswith(required_prefix):
                raise ValueError(f"Unexpected file in experience shard: {info.filename}")
        z.extractall(destination)


def check_file(path, metadata):
    path = Path(path)
    if not path.is_file():
        raise FileNotFoundError(path)
    if "bytes" in metadata and path.stat().st_size != metadata["bytes"]:
        raise ValueError(f"File size mismatch: {path.name}")
    if metadata.get("sha256") and sha256_file(path) != metadata["sha256"]:
        raise ValueError(f"SHA-256 mismatch: {path.name}")


def atomic(path, value):
    path = Path(path); path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_name(path.name+".tmp")
    with temp.open("w", encoding="utf-8") as f:
        json.dump(value, f, indent=2, ensure_ascii=False)
        f.flush(); os.fsync(f.fileno())
    os.replace(temp, path)


def restore_original(locator, destination):
    from huggingface_hub import snapshot_download
    from SUPPLEMENT import SOURCE_HASH, SOURCE_PROTOCOL, validate_original_protocol, validate_shards
    if locator.get("original_source_sha256") != SOURCE_HASH or locator.get("protocol_sha256") != SOURCE_PROTOCOL:
        raise ValueError("Original source identity changed")
    if not locator.get("revision") or not locator.get("allow_paths"):
        raise ValueError("Source snapshot must have an exact revision and file allowlist")
    destination = Path(destination)
    print(f"Downloading original source: {locator['repo_id']} @ {locator['revision']}", flush=True)
    # HF's local metadata reuses already downloaded files on a surviving worker.
    # A fresh cloud machine necessarily fetches this immutable snapshot again.
    snapshot_download(repo_id=locator["repo_id"], repo_type="dataset", revision=locator["revision"],
                      allow_patterns=locator["allow_paths"], local_dir=str(destination), max_workers=4)
    run_root = destination/"runs"/locator["run_id"]
    protocol = json.loads((run_root/"protocol.json").read_text())
    validate_original_protocol(protocol)
    actual_paths = {p.relative_to(destination).as_posix() for p in destination.rglob("*") if p.is_file()}
    for seed in range(8):
        member_path = f"runs/{locator['run_id']}/members/full-s{seed}"
        manifest = json.loads((destination/member_path/"data_manifest.json").read_text())
        validate_shards(manifest, member_path, actual_paths)
    for checkpoint in locator["checkpoints"]:
        check_file(destination/checkpoint["path"], checkpoint)
    for count, shard in enumerate(locator["shards"], 1):
        archive = destination/shard["path"]
        check_file(archive, shard)
        # .../members/full-sN/data/shards/block_N.zip -> member root
        member = archive.parents[2]
        marker = member/".verified_shards"/(archive.stem+".json")
        old = json.loads(marker.read_text()) if marker.exists() else None
        if old != {"sha256": shard["sha256"], "revision": locator["revision"]}:
            safe_extract(archive, member, required_prefix="data/episodes/")
            atomic(marker, {"sha256": shard["sha256"], "revision": locator["revision"]})
        if count % 16 == 0:
            print(f"Verified and restored {count}/{len(locator['shards'])} original raw shards", flush=True)
    # This identity remains invariant over cloud workers and resumed paid Jobs.
    atomic(run_root/"supplement_source_identity.json", {
        key: locator[key] for key in ["repo_id", "repo_type", "revision", "run_id",
                                     "protocol_sha256", "original_source_sha256"]})
    return run_root


def verify_checkpoint_metadata(locator, snapshot_root):
    """Check ages/seeds after immutable-snapshot and LFS integrity verification."""
    import torch
    for metadata in locator["checkpoints"]:
        checkpoint = torch.load(Path(snapshot_root)/metadata["path"], map_location="cpu", weights_only=False)
        expected_interactions = metadata["age_blocks"]*32*64
        cfg = checkpoint.get("config", {})
        if (cfg.get("seed") != metadata["seed"] or cfg.get("ablation") != "none"
                or checkpoint.get("update") != metadata["update"]
                or checkpoint.get("interactions") != expected_interactions
                or not checkpoint.get("model")):
            raise ValueError(f"Pretrained checkpoint seed/age metadata mismatch: {metadata['path']}")
        del checkpoint


def restore_output(manifest, output, cache):
    if not manifest.get("resume") or not manifest.get("resume_has_output", True):
        return
    from huggingface_hub import snapshot_download
    revision = manifest.get("resume_revision")
    if not revision:
        raise ValueError("Explicit resume requires a pinned result revision")
    prefix = "runs/"+manifest["run_id"]
    snapshot_download(repo_id=manifest["result_repo"], repo_type="dataset", revision=revision,
                      allow_patterns=[prefix+"/*"], local_dir=str(cache), max_workers=4)
    saved = Path(cache)/prefix
    if not (saved/"supplement_state.json").is_file():
        raise RuntimeError("No supplemental state was restored; refusing to restart from scratch")
    output = Path(output)
    if output.exists():
        if any(output.iterdir()):
            raise RuntimeError("Cloud output directory is not empty before pinned resume restore")
        output.rmdir()
    shutil.move(str(saved), str(output))
    shutil.rmtree(cache, ignore_errors=True)
    locator_file = Path(output)/"source_locator.json"
    if locator_file.exists() and json.loads(locator_file.read_text()) != manifest["original_source"]:
        raise ValueError("Original source locator changed across resume")


def publish_setup(manifest, output):
    """Persist recovery state before potentially expensive dependency/data setup."""
    if manifest.get("resume") and manifest.get("resume_has_output", True):
        return
    from huggingface_hub import HfApi
    api = HfApi()
    prefix = f"runs/{manifest['run_id']}"
    if api.file_exists(repo_id=manifest["result_repo"], repo_type="dataset", filename=prefix+"/supplement_state.json"):
        raise RuntimeError("Run state already exists; refusing duplicate cloud setup")
    atomic(Path(output)/"supplement_state.json", {"status": "setup", "phase": "setup"})
    api.upload_folder(repo_id=manifest["result_repo"], repo_type="dataset", folder_path=str(output),
                      path_in_repo=prefix, allow_patterns=["supplement_state.json", "source_locator.json", "launch_manifest.json"],
                      commit_message="Persist supplemental setup recovery state")


def main(argv=None):
    started = time.time()
    p = argparse.ArgumentParser()
    p.add_argument("--manifest-repo", required=True)
    p.add_argument("--manifest-path", required=True)
    p.add_argument("--manifest-revision", required=True)
    args = p.parse_args(argv)
    from huggingface_hub import hf_hub_download
    manifest_file = hf_hub_download(args.manifest_repo, args.manifest_path, repo_type="dataset", revision=args.manifest_revision)
    manifest = json.loads(Path(manifest_file).read_text())
    if manifest.get("schema") != "devbaby-supplement-launch-v1":
        raise ValueError("Unsupported cloud launch manifest")
    if manifest.get("hard_timeout_seconds") != 86400 or manifest.get("job_budget_seconds") != 82800:
        raise ValueError("Expected 24-hour hard cap and 23-hour cooperative budget")
    if hashlib.sha256((ROOT/"supplement_protocol.json").read_bytes()).hexdigest() != manifest["protocol_sha256"]:
        raise ValueError("Supplemental protocol checksum mismatch")
    if not (3, 10) <= sys.version_info[:2] <= (3, 11):
        raise RuntimeError("Use the supplied PyTorch 2.6 CUDA12.4 image with Python 3.10/3.11")
    output = Path("/tmp/devbaby-supplement-output")
    restore_output(manifest, output, Path("/tmp/devbaby-supplement-resume"))
    output.mkdir(parents=True, exist_ok=True)
    atomic(output/"source_locator.json", manifest["original_source"])
    atomic(output/"launch_manifest.json", {**manifest, "manifest_repo": args.manifest_repo,
           "manifest_path": args.manifest_path, "manifest_revision": args.manifest_revision})
    publish_setup(manifest, output)
    subprocess.run([sys.executable, "-m", "pip", "install", "--disable-pip-version-check", "-r", str(ROOT/"requirements-runtime.txt")], check=True)
    import torch
    if not torch.cuda.is_available() or not torch.__version__.startswith("2.6."):
        raise RuntimeError("Expected CUDA GPU and PyTorch 2.6; refusing an unintended runtime")
    source_root = restore_original(manifest["original_source"], Path("/tmp/devbaby-original-snapshot"))
    verify_checkpoint_metadata(manifest["original_source"], Path("/tmp/devbaby-original-snapshot"))
    deadline = started+manifest["job_budget_seconds"]
    if time.time() >= deadline-300:
        raise RuntimeError("Setup exhausted the job budget; experiment was not started")
    env = os.environ.copy()
    env["DEVBABY_SUPPLEMENT_DEADLINE_UNIX"] = str(deadline)
    env["DEVBABY_SUPPLEMENT_JOB_STARTED_UNIX"] = str(started)
    command = [sys.executable, "-u", "-m", "devbaby.supplement", "--source-root", str(source_root),
               "--output", str(output), "--protocol", str(ROOT/"supplement_protocol.json"),
               "--device", "cuda", "--hf-repo", manifest["result_repo"], "--run-id", manifest["run_id"]]
    if manifest.get("resume"):
        command.append("--resume")
    print(f"Starting supplemental run {manifest['run_id']}; source datasets/checkpoints reused, no baseline retraining.", flush=True)
    subprocess.run(command, cwd=ROOT, env=env, check=True)


if __name__ == "__main__":
    main()
