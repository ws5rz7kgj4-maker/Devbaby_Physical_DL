import json

import numpy as np
import pytest

from devbaby.supplement_report import (
    META_FIELDS, PRIMARY_CONTRASTS, _load_records, build_report,
    crossed_bootstrap, curve_statistics, holm, primary_contrasts, sign_flip_p,
)


def protocol():
    return {"seeds": list(range(8)), "adaptation_domains": ["new_dynamics", "delay_3"],
            "adaptation_tasks": ["reach", "touch"], "budgets": [0, 128, 2048],
            "mature_source_age": 32768, "final_trials": 4, "bootstrap_draws": 200,
            "development_only": False}


def records():
    result = []
    values = {"frozen": [0, 0, 0, 0], "full_update": [1, 0, 0, 0],
              "replay_mix": [1, 1, 1, 0], "frozen_encoder": [1, 1, 0, 0],
              "low_lr": [1, 1, 0, 0], "history": [1, 1, 1, 1]}
    for arm, outcomes in values.items():
        for seed in range(8):
            for domain in protocol()["adaptation_domains"]:
                for task in protocol()["adaptation_tasks"]:
                    for trial, success in enumerate(outcomes):
                        result.append(dict(phase="adaptation", split="final", seed=seed,
                                           model="history" if arm == "history" else "baby", arm=arm,
                                           source_age=32768, budget=2048, domain=domain, task=task,
                                           trial=trial, scene_seed=str(trial), success=success))
    return result


def test_growth_is_physical_success_not_higher_start():
    mature = curve_statistics([0, 1000, 2000], [.8, .8, .7])
    young = curve_statistics([0, 1000, 2000], [.1, .3, .6])
    assert mature["growth_pp_per_1000_interactions"][1:] == pytest.approx([0, -10])
    assert mature["normalized_gain_auc"] == pytest.approx(-.025)
    assert young["normalized_gain_auc"] > 0
    assert young["thresholds"]["0.75"]["right_censored"] is True
    assert young["thresholds"]["0.75"]["first_observed_interactions"] is None
    assert mature["thresholds"]["0.75"]["already_reached_at_start"] is True


def test_paired_crossed_scene_bootstrap_preserves_pairing():
    a = np.tile([0, 0, 1, 1], (8, 1))
    assert crossed_bootstrap([a - a], draws=200) == [0, 0]
    # Identical seeds still leave uncertainty across held-out scene composition.
    interval = crossed_bootstrap([a], draws=1000)
    assert interval[0] < .5 < interval[1]
    assert crossed_bootstrap([np.zeros((1, 4))]) == [None, None]


def test_primary_family_complete_and_fixed_six():
    result, reasons = primary_contrasts(records(), protocol(), complete=True)
    assert not reasons and len(result) == 6
    assert result[0]["mean_difference_pp"] == 25
    assert result[0]["n_model_seeds"] == 8
    assert result[0]["exact_paired_sign_flip_p"] == 2 / 256
    assert result[0]["holm_p"] == 6 * 2 / 256
    assert all(row["positive_evidence"] for row in result)
    assert sign_flip_p([0] * 8) == 1
    assert holm([.01, None, .04]) == [.03, None, .08]


def test_no_silent_seed_or_scene_dropping():
    data = records()
    data.pop()
    result, reasons = primary_contrasts(data, protocol(), complete=True)
    assert not result and any("incomplete/unpaired" in reason for reason in reasons)
    result, reasons = primary_contrasts(records(), protocol(), complete=False)
    assert not result and any("not marked complete" in reason for reason in reasons)
    p = {**protocol(), "development_only": True}
    assert not primary_contrasts(records(), p, complete=True)[0]


def test_expected_scene_count_blocks_smaller_panel():
    data = [r for r in records() if r["trial"] != 3]
    result, reasons = primary_contrasts(data, protocol(), complete=True)
    assert not result and any("expected 4" in reason for reason in reasons)


def test_partial_files_are_ignored_and_duplicate_scenes_rejected(tmp_path):
    directory = tmp_path / "evaluations"
    directory.mkdir()
    row = records()[0]
    blob = {"metadata": {k: row[k] for k in META_FIELDS}, "trials": [row]}
    (directory / "partial.json").write_text(json.dumps(blob))
    loaded, ignored = _load_records(tmp_path)
    assert not loaded and ignored == ["evaluations/partial.json"]
    blob["complete"] = True
    (directory / "first.json").write_text(json.dumps(blob))
    assert len(_load_records(tmp_path)[0]) == 1
    (directory / "duplicate.json").write_text(json.dumps(blob))
    with pytest.raises(ValueError, match="Duplicate scene"):
        _load_records(tmp_path)


def test_empty_partial_report_does_not_fabricate_results(tmp_path):
    summary = build_report(tmp_path, protocol(), complete=False)
    assert summary["status"] == "partial" and not summary["primary_tests"]
    assert summary["completed_rollouts"] == 0
    assert (tmp_path / "report.html").is_file()
    assert (tmp_path / "supplement_curves.png").stat().st_size > 1000
    assert len((tmp_path / "curves.csv").read_text().splitlines()) == 1


def test_shared_delay_scene_panels_resample_together():
    a = np.tile([0, 0, 1, 1], (8, 1))
    # Same scenarios with opposite effects must cancel in every resample.
    assert crossed_bootstrap([a, -a], draws=500, scene_panels=[[1, 2, 3, 4]] * 2) == [0, 0]
    independent = crossed_bootstrap([a, -a], draws=500)
    assert independent[0] < 0 < independent[1]


def test_retention_training_domains_do_not_collide(tmp_path):
    directory = tmp_path / "evaluations"
    directory.mkdir()
    row = records()[0]
    for i, training_domain in enumerate(["delay_3", "new_dynamics"]):
        metadata = {k: row[k] for k in META_FIELDS}
        metadata.update(phase="retention", domain="iid", training_domain=training_domain)
        trial = {"success": True, "trial": 0, "scene_seed": "same-iid-scene"}
        (directory / f"retention-{i}.json").write_text(json.dumps({
            "complete": True, "metadata": metadata, "trials": [trial]}))
    loaded, _ = _load_records(tmp_path)
    assert len(loaded) == 2
    assert {r["training_domain"] for r in loaded} == {"delay_3", "new_dynamics"}


def test_learning_progress_uses_balanced_domains_and_keeps_head_start_separate():
    from devbaby.supplement_report import _learning_progress
    p = {**protocol(), "seeds": [0], "budgets": [0, 1000], "adaptation_tasks": ["reach"]}
    rows = []
    for age, start, finish in [(0, .1, .4), (32768, .8, .8)]:
        for domain in p["adaptation_domains"]:
            for budget, value in [(0, start), (1000, finish)]:
                rows.append(dict(model="baby", arm="full_update", source_age=age, seed=0,
                                 phase="adaptation", split="validation", domain=domain,
                                 task="reach", budget=budget, success_rate=value,
                                 same_scene_panel_across_checkpoints=True))
    curves, missing = _learning_progress(rows, p)
    assert not missing and len(curves) == 2
    assert curves[0]["normalized_gain_auc"] == pytest.approx(.15)
    assert curves[1]["normalized_gain_auc"] == 0
    rows.pop()
    curves, missing = _learning_progress(rows, p)
    assert len(curves) == 1 and missing[0]["missing_domain_task_budget_cells"] == 1


def test_scene_seed_never_overwrites_independent_model_seed(tmp_path):
    directory = tmp_path / "evaluations"
    directory.mkdir()
    example = records()[0]
    metadata = {k: example[k] for k in META_FIELDS}
    metadata["seed"] = 0
    trial = {"seed": 999, "model_seed": 0, "scene_seed": 999, "success": True,
             "task": metadata["task"], "domain": metadata["domain"], "split": metadata["split"]}
    path = directory / "result.json"
    path.write_text(json.dumps({"complete": True, "metadata": metadata, "trials": [trial]}))
    rows, _ = _load_records(tmp_path)
    assert rows[0]["seed"] == 0 and rows[0]["scene_seed"] == "999"
    trial["model_seed"] = 1
    path.write_text(json.dumps({"complete": True, "metadata": metadata, "trials": [trial]}))
    with pytest.raises(ValueError, match="model_seed disagrees"):
        _load_records(tmp_path)
    trial["model_seed"] = 0
    trial["domain"] = "wrong-domain"
    path.write_text(json.dumps({"complete": True, "metadata": metadata, "trials": [trial]}))
    with pytest.raises(ValueError, match="domain disagrees"):
        _load_records(tmp_path)
