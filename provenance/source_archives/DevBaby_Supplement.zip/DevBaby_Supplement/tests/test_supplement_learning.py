"""Contracts that can invalidate an adaptation/mechanism comparison."""

from copy import deepcopy
from dataclasses import replace
import json
from types import SimpleNamespace

import numpy as np
import pytest
import torch
from torch import nn

from devbaby.config import Config
from devbaby.data import Replay
from devbaby.model import Baby, losses
from devbaby.supplement_learning import (
    ADAPTATION_ARMS, PLASTIC_MODULES, adaptation_step, configure_adaptation,
    frozen_reference, gradient_audit, parameter_digest, parameter_hashes,
    read_sensory_episode, sample_adaptation_batch, sensory_prediction_diagnostics,
    temporal_alignment_audit,
)


@pytest.fixture(autouse=True)
def short_cpu_operations():
    previous = torch.get_num_threads()
    torch.set_num_threads(1)
    yield
    torch.set_num_threads(previous)


def config():
    return Config(hidden=16, clip_steps=3, episode_steps=12, batch_size=4,
                  learning_rate=3e-4, threads=1, save_video=False)


def sensory_arrays(seed=4, steps=12):
    rng = np.random.default_rng(seed)
    return {
        "rgb": rng.integers(0, 256, (steps + 1, 64, 64, 3), dtype=np.uint8),
        "audio": rng.normal(0, .1, (steps + 1, 32, 16)).astype(np.float32),
        "proprio": rng.normal(0, .1, (steps + 1, 10)).astype(np.float32),
        "actions": rng.uniform(-1, 1, (steps, 5)).astype(np.float32),
    }


def write_episode(root, number=0, seed=4, arrays=None):
    directory = root / f"{number:07d}"
    directory.mkdir(parents=True, exist_ok=True)
    np.savez_compressed(directory / "observations.npz", **(sensory_arrays(seed) if arrays is None else arrays))
    # Hidden content here must never be consumed by training or diagnostics.
    (directory / "complete.json").write_text('{"secret_success_label": true}')
    (directory / "annotations").mkdir(exist_ok=True)
    (directory / "annotations" / "frames.jsonl").write_text('invalid annotation intentionally unreadable')
    return directory / "observations.npz"


def replay(root, seed=11):
    write_episode(root, 0, 4)
    write_episode(root, 1, 9)
    return Replay(config(), root, seed)


def make_model():
    torch.manual_seed(72)
    return Baby(config())


def test_arm_learning_rates_and_trainable_parameter_contract():
    model = make_model()
    for arm in ADAPTATION_ARMS:
        optimizer = configure_adaptation(model, arm)
        if arm == "frozen":
            assert optimizer is None
            assert not any(p.requires_grad for p in model.parameters())
        else:
            assert optimizer.param_groups[0]["lr"] == pytest.approx(config().learning_rate * (.1 if arm == "low_lr" else 1))
            actual = {name for name, p in model.named_parameters() if p.requires_grad}
            expected = {name for name, _ in model.named_parameters()
                        if arm != "frozen_encoder" or name.split(".", 1)[0] in PLASTIC_MODULES}
            assert actual == expected
    with pytest.raises(ValueError, match="Unknown adaptation arm"):
        configure_adaptation(model, "unregistered_arm")


def test_frozen_encoder_preserves_exact_weights_and_old_reference(tmp_path):
    model = make_model()
    old_reference = frozen_reference(model)
    before = parameter_hashes(model)
    origin_digest = parameter_digest(old_reference)
    assert all(not p.requires_grad for p in old_reference.parameters())
    assert all(a.data_ptr() != b.data_ptr() for a, b in zip(model.parameters(), old_reference.parameters()))
    optimizer = configure_adaptation(model, "frozen_encoder")
    result, trace = adaptation_step(model, optimizer, replay(tmp_path), "cpu", "frozen_encoder", audit=True)
    after = parameter_hashes(model)
    assert result["updated"] and len(trace) == config().batch_size
    audit = result["gradient_audit"]
    assert audit["all_finite"] and not audit["frozen_parameters_with_gradient"]
    for name in before:
        if name.split(".", 1)[0] not in PLASTIC_MODULES:
            assert before[name] == after[name]
    for group in PLASTIC_MODULES:
        assert audit["groups"][group]["gradient_l2"] > 0
        assert any(before[name] != after[name] for name in before if name.startswith(group + "."))
    assert parameter_digest(old_reference) == origin_digest
    assert all(p.grad is None for p in old_reference.parameters())


def test_update_matches_original_loss_without_previous_model(tmp_path):
    model = make_model()
    manual = deepcopy(model)
    new_replay = replay(tmp_path)
    replay_state = deepcopy(new_replay.rng.bit_generator.state)
    optimizer = configure_adaptation(model, "full_update")
    manual_optimizer = configure_adaptation(manual, "full_update")
    actual, _ = adaptation_step(model, optimizer, new_replay, "cpu", "full_update")
    new_replay.rng.bit_generator.state = replay_state
    batch, _ = new_replay.sample("cpu")
    manual_optimizer.zero_grad(set_to_none=True)
    loss, expected = losses(manual, batch, previous_model=None)
    loss.backward()
    torch.nn.utils.clip_grad_norm_(manual.parameters(), 5, error_if_nonfinite=True)
    manual_optimizer.step()
    assert actual["loss"] == expected["loss"]
    assert actual["progress_prediction"] == 0
    assert parameter_hashes(model) == parameter_hashes(manual)
    assert all(p.grad is None for p in model.progress.parameters())


def test_frozen_control_does_not_consume_replay_or_change_parameters():
    model = make_model()
    before = parameter_digest(model)
    optimizer = configure_adaptation(model, "frozen")

    class NoSampling:
        def sample(self, device):
            raise AssertionError("A frozen control must not consume training samples")

    stats, trace = adaptation_step(model, optimizer, NoSampling(), "cpu", "frozen")
    assert not stats["updated"] and trace == []
    assert parameter_digest(model) == before


def test_replay_mixture_exact_half_and_unambiguous_source_trace(tmp_path):
    new = replay(tmp_path / "new", 11)
    old = replay(tmp_path / "old", 19)
    # Distinguishable observable values test actual data membership, not just labels.
    for path in new.paths:
        arrays = read_sensory_episode(path)
        arrays["proprio"][:] = .25
        np.savez_compressed(path, **arrays)
    for path in old.paths:
        arrays = read_sensory_episode(path)
        arrays["proprio"][:] = -.75
        np.savez_compressed(path, **arrays)
    batch, trace = sample_adaptation_batch(new, "cpu", "replay_mix", old)
    assert batch["actions"].shape[0] == config().batch_size
    assert torch.all(batch["proprio"][:2] == .25)
    assert torch.all(batch["proprio"][2:] == -.75)
    assert [row["source"] for row in trace] == ["new_experience"] * 2 + ["old_experience"] * 2
    with pytest.raises(ValueError, match="old-experience"):
        sample_adaptation_batch(new, "cpu", "replay_mix")
    odd = Replay(replace(config(), batch_size=3), tmp_path / "new", 11)
    with pytest.raises(ValueError, match="even batch size"):
        sample_adaptation_batch(odd, "cpu", "replay_mix", old)


def test_replay_mix_restart_restores_both_rngs_optimizer_and_freeze_selection(tmp_path):
    new = replay(tmp_path / "new", 11)
    old = replay(tmp_path / "old", 19)
    model = make_model()
    optimizer = configure_adaptation(model, "replay_mix")
    adaptation_step(model, optimizer, new, "cpu", "replay_mix", old)
    saved = deepcopy({"model": model.state_dict(), "optimizer": optimizer.state_dict(),
                      "new_rng": new.rng.bit_generator.state, "old_rng": old.rng.bit_generator.state})
    expected_stats, expected_trace = adaptation_step(model, optimizer, new, "cpu", "replay_mix", old)
    expected_hashes = parameter_hashes(model)

    resumed = make_model()
    resumed.load_state_dict(saved["model"])
    resumed_optimizer = configure_adaptation(resumed, "replay_mix")
    resumed_optimizer.load_state_dict(saved["optimizer"])
    resumed_new = Replay(config(), tmp_path / "new", 987)
    resumed_old = Replay(config(), tmp_path / "old", 654)
    resumed_new.rng.bit_generator.state = saved["new_rng"]
    resumed_old.rng.bit_generator.state = saved["old_rng"]
    stats, trace = adaptation_step(resumed, resumed_optimizer, resumed_new, "cpu", "replay_mix", resumed_old)
    assert stats == expected_stats and trace == expected_trace
    assert parameter_hashes(resumed) == expected_hashes


def test_current_issued_action_changes_prediction_then_next_history(tmp_path):
    model = make_model().eval()
    batch, _ = replay(tmp_path).sample("cpu")
    changed = {key: value.clone() for key, value in batch.items()}
    changed["actions"][:, 1] = -batch["actions"][:, 1]
    with torch.no_grad():
        original, altered = model(batch), model(changed)
    # a_1 is issued after encoding o_1: no effect on h_0 or h_1.
    assert torch.equal(original["h"][:, :2], altered["h"][:, :2])
    assert not torch.allclose(original["pred_body"][:, 1], altered["pred_body"][:, 1], atol=1e-7)
    assert not torch.allclose(original["h"][:, 2], altered["h"][:, 2], atol=1e-7)
    assert torch.equal(original["pred_body"][:, 0], altered["pred_body"][:, 0])


@pytest.mark.parametrize("ablation", ["none", "no_action", "no_world_memory", "no_audio"])
def test_forward_matches_online_at_episode_start(tmp_path, ablation):
    torch.manual_seed(19)
    model = Baby(replace(config(), ablation=ablation)).train()
    path = write_episode(tmp_path)
    before = parameter_digest(model)
    result = temporal_alignment_audit(model, path, "cpu", steps=7)
    assert result["forward_vs_online_hidden_max_abs"] < 2e-6
    assert result["forward_vs_online_body_max_abs"] < 2e-6
    assert model.training and parameter_digest(model) == before


def test_clip_context_audit_separates_false_previous_action_and_lost_history(tmp_path):
    model = make_model()
    path = write_episode(tmp_path)
    result = sensory_prediction_diagnostics(model, [path], "cpu", max_starts_per_episode=5)
    context = result["per_episode"][0]["clip_context"]
    assert context["episode_history"]["1"]["hidden_mse_vs_episode"] == 0
    assert context["clip_reset_true_previous"]["1"]["hidden_mse_vs_episode"] > 0
    assert context["clip_reset_zero_previous"]["1"]["hidden_mse_vs_episode"] > 0
    assert context["clip_reset_true_previous"]["1"]["body_mse"] != context["clip_reset_zero_previous"]["1"]["body_mse"]
    assert context["clip_reset_true_previous"]["8"]["hidden_mse_vs_episode"] > 0


def test_free_run_never_reads_future_vision_or_audio(tmp_path):
    original = sensory_arrays()
    modified = {key: value.copy() for key, value in original.items()}
    modified["rgb"][1:] = 255 - modified["rgb"][1:]
    modified["audio"][1:] += 10
    left = write_episode(tmp_path / "left", arrays=original)
    right = write_episode(tmp_path / "right", arrays=modified)
    model = make_model().train()
    digest = parameter_digest(model)
    rng = torch.get_rng_state().clone()
    result_a = sensory_prediction_diagnostics(model, [left], "cpu", max_starts_per_episode=1)
    result_b = sensory_prediction_diagnostics(model, [right], "cpu", max_starts_per_episode=1)
    # Single start t=0; only the withheld future inputs differ, not targets/actions.
    assert result_a["per_episode"][0]["starts"] == [0]
    assert result_a["metrics"]["free_run"] == result_b["metrics"]["free_run"]
    assert result_a["metrics"]["teacher_forced"]["8"] != result_b["metrics"]["teacher_forced"]["8"]
    assert result_a["metrics"]["teacher_forced"]["1"] == result_a["metrics"]["free_run"]["1"]
    assert parameter_digest(model) == digest and torch.equal(torch.get_rng_state(), rng)
    assert model.training and all(p.grad is None for p in model.parameters())
    json.dumps(result_a, allow_nan=False)


class ZeroEncoder(nn.Module):
    def forward(self, value):
        return value.new_zeros((len(value), 1))


class ZeroDynamics(nn.Module):
    def forward(self, value):
        return value.new_zeros((*value.shape[:-1], 1))


class UnitBodyDrift(nn.Module):
    def forward(self, value):
        result = value.new_zeros((*value.shape[:-1], 10))
        result[..., 0] = 1
        return result


class AnalyticDriftModel(nn.Module):
    """Known one metre per step error against a motionless target trajectory."""
    def __init__(self):
        super().__init__()
        self.cfg = SimpleNamespace(ablation="none")
        self.visual = ZeroEncoder()
        self.hearing = ZeroEncoder()
        self.dynamics = ZeroDynamics()
        self.body = UnitBodyDrift()

    def _actions(self, actions):
        return actions

    def _memory(self, value, state=None):
        result = value.new_zeros((*value.shape[:2], 1))
        return result, result[:, -1].unsqueeze(0)


def test_multistep_error_detects_compounding_and_reports_physical_units(tmp_path):
    arrays = sensory_arrays()
    arrays["proprio"][:] = 0
    path = write_episode(tmp_path, arrays=arrays)
    result = sensory_prediction_diagnostics(AnalyticDriftModel(), [path], "cpu")
    for horizon in (1, 2, 4, 8):
        tf = result["metrics"]["teacher_forced"][str(horizon)]
        free = result["metrics"]["free_run"][str(horizon)]
        assert tf["body_mse"] == pytest.approx(.1)
        assert free["body_mse"] == pytest.approx(horizon ** 2 / 10)
        assert free["position_rmse_m"] == pytest.approx(horizon / np.sqrt(3))
        assert free["grasp_mse"] == 0
        assert free["n_predictions"] == tf["n_predictions"] == 5


def test_hidden_annotations_rejected_and_diagnostic_mode_restored_after_failure(tmp_path):
    arrays = sensory_arrays()
    arrays["mass_hidden"] = np.array(1.)
    path = write_episode(tmp_path, arrays=arrays)
    with pytest.raises(ValueError, match="extra or missing"):
        read_sensory_episode(path)
    model = make_model().train()
    with pytest.raises(ValueError, match="extra or missing"):
        sensory_prediction_diagnostics(model, [path], "cpu")
    assert model.training
    training = Replay(config(), tmp_path, 4)
    optimizer = configure_adaptation(model, "full_update")
    with pytest.raises(ValueError, match="extra or missing"):
        adaptation_step(model, optimizer, training, "cpu", "full_update")


def test_gradient_audit_reports_nonfinite_without_nonstandard_json():
    model = make_model()
    first = next(model.parameters())
    first.grad = torch.full_like(first, float("nan"))
    audit = gradient_audit(model)
    assert not audit["all_finite"]
    assert audit["groups"]["visual"]["gradient_l2"] is None
    json.dumps(audit, allow_nan=False)
