import json
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch

import pytest

from devbaby.supplement_sync import sync_run, INDEX, STATE


class MemoryAPI:
    def __init__(self, fail_at=None):
        self.calls=[]; self.remote={}; self.fail_at=fail_at
    def create_commit(self, **kwargs):
        paths=[op.path_in_repo for op in kwargs['operations']]
        if self.fail_at is not None and any(self.fail_at in p for p in paths):
            raise OSError('simulated upload interruption')
        changes={}
        for op in kwargs['operations']:
            source=op.path_or_fileobj
            changes[op.path_in_repo]=source if isinstance(source,bytes) else Path(source).read_bytes()
        self.remote.update(changes);self.calls.append(paths)
        return SimpleNamespace(oid=str(len(self.calls)))


def put(root,name,data):
    p=root/name;p.parent.mkdir(parents=True,exist_ok=True)
    p.write_text(data if isinstance(data,str) else json.dumps(data))
    return p


def fixture(root):
    put(root,STATE,{'status':'running'})
    put(root,'supplement_protocol.lock.json',{'locked':True})
    ep='experience/s0/delay_3/0000000/'
    put(root,ep+'observations.npz','raw simulated npz')
    put(root,ep+'audio.wav','synthetic audio')
    put(root,ep+'annotations/frames.jsonl','annotation')
    put(root,ep+'complete.json',{'steps':64})
    put(root,'checkpoints/adaptation/s0/last.pt','checkpoint')
    put(root,'checkpoints/adaptation/s0/training_trace.jsonl','trainingtrace')
    put(root,'checkpoints/adaptation/s0/complete.json',{'complete':True})
    put(root,'physical_panels/p/sensory.zip','all sensory')
    put(root,'physical_panels/p/panel.json',{'complete':True,'trials':[1,2]})
    put(root,'physical_panels/p/trials/00000.json',{'partial':True})
    put(root,'physical_panels/q/trials/00000.json',{'partial':True})
    put(root,'physical_panels/q/sensory.zip','partialarchive')
    put(root,'physical_panels/p/sensory/file.npz','unpacked')
    put(root,'evaluations/e/result.json',{'complete':True})
    put(root,'speech_cache/voice.wav','cached speech')
    put(root,'checkpoints/adaptation/s0/last.tmp','unfinished')
    put(root,'.cache/huggingface/token','never upload')
    put(root,'experience/s0/delay_3/0000001/observations.npz','unfinished episode')


def test_complete_dependencies_before_checkpoints_and_state_and_exclusions(tmp_path):
    fixture(tmp_path);api=MemoryAPI()
    result=sync_run(tmp_path,'user/results','run',api=api,max_files=2,max_bytes=30)
    flat=[p for batch in api.calls for p in batch]
    find=lambda suffix:next(i for i,p in enumerate(flat) if p.endswith(suffix))
    assert find('observations.npz')<find('experience/s0/delay_3/0000000/complete.json')<find('last.pt')
    assert find('training_trace.jsonl')<find('last.pt')<find('checkpoints/adaptation/s0/complete.json')
    assert find('sensory.zip')<find('panel.json')<find('result.json')<find(STATE)
    assert all(len(batch)<=2 for batch in api.calls)
    assert all('trials/' not in p and '/sensory/' not in p and 'speech_cache' not in p and '.tmp' not in p and '/.cache/' not in p for p in flat)
    assert not any('0000001' in p or 'physical_panels/q' in p for p in flat)
    assert api.calls[-1]==['runs/run/'+STATE,'runs/run/'+INDEX]
    assert result['uploaded_files']>0
    assert (tmp_path/INDEX).is_file()


def test_unchanged_files_not_recommitted_and_changed_checkpoint_is_bounded(tmp_path):
    fixture(tmp_path);api=MemoryAPI()
    sync_run(tmp_path,'user/results','run',api=api)
    calls=len(api.calls)
    assert sync_run(tmp_path,'user/results','run',api=api)['commits']==0
    assert len(api.calls)==calls
    put(tmp_path,'checkpoints/adaptation/s0/last.pt','new weights')
    put(tmp_path,STATE,{'status':'paused'})
    sync_run(tmp_path,'user/results','run',api=api)
    flat=[p for batch in api.calls[calls:] for p in batch]
    assert flat==['runs/run/checkpoints/adaptation/s0/last.pt','runs/run/'+STATE,'runs/run/'+INDEX]


def test_failed_data_batch_does_not_publish_state_or_local_index(tmp_path):
    fixture(tmp_path);api=MemoryAPI(fail_at='last.pt')
    with patch('devbaby.supplement_sync.time.sleep'):
        with pytest.raises(OSError):sync_run(tmp_path,'user/results','run',api=api)
    assert 'runs/run/'+STATE not in api.remote
    assert not (tmp_path/INDEX).exists()
    api.fail_at=None
    sync_run(tmp_path,'user/results','run',api=api)
    assert 'runs/run/'+STATE in api.remote


def test_restore_rehashes_equal_content_without_data_upload(tmp_path):
    fixture(tmp_path);api=MemoryAPI()
    sync_run(tmp_path,'user/results','run',api=api)
    index=json.loads((tmp_path/INDEX).read_text())
    for value in index['files'].values():value['mtime_ns']=0
    put(tmp_path,INDEX,index)
    calls=len(api.calls)
    result=sync_run(tmp_path,'user/results','run',api=api)
    assert result['uploaded_files']==0
    assert len(api.calls)==calls+1
    assert api.calls[-1]==['runs/run/'+STATE,'runs/run/'+INDEX]


def test_wrong_result_identity_refused_before_upload(tmp_path):
    fixture(tmp_path);api=MemoryAPI()
    sync_run(tmp_path,'user/results','run',api=api)
    with pytest.raises(ValueError,match='different result run'):
        sync_run(tmp_path,'user/other','run',api=api)
