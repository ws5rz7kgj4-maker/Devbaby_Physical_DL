"""Exact preflight counts and aliasing must agree with the paid runner."""
import copy
import json
from pathlib import Path
import subprocess
import sys
from types import SimpleNamespace

import pytest

from devbaby.supplement_plan import checkpoint_identity, execution_identity, plan, scheduled_panels


ROOT = Path(__file__).resolve().parent.parent


def protocol():
    return json.loads((ROOT/"supplement_protocol.json").read_text())


def test_import_needs_no_numerical_gpu_or_simulator_packages():
    result = subprocess.run([sys.executable, "-c",
                             "import sys; import devbaby.supplement_plan; "
                             "assert not {'torch','numpy','pybullet','huggingface_hub'} & set(sys.modules)"],
                            cwd=ROOT, capture_output=True, text=True)
    assert result.returncode == 0, result.stderr


def test_formal_plan_counts_training_targets_and_new_interactions_exactly():
    result = plan(protocol())
    assert result["scheduled_cells"] == 4918
    assert result["scheduled_trials"] == 76736
    assert result["unique_execution_panels"] == 3550
    assert result["unique_execution_trials"] == 59360
    assert result["aliased_trials"] == 17376
    training = result["training"]
    assert training["original_baby_retraining_updates"] == 0
    assert training["original_checkpoints_reused"] == 24
    assert training["unique_original_interactions_reused"] == 8*32768
    assert training["history_source_updates"] == 8*8192
    assert training["baby_adaptation_updates"] == 73728
    assert training["history_adaptation_updates"] == 12288
    assert training["all_new_optimizer_updates"] == 151552
    assert training["unique_new_adaptation_episodes"] == 8*3*32
    assert training["unique_new_adaptation_interactions"] == 8*3*2048
    assert training["diagnostic_only_episodes"] == 8*3*4
    assert training["diagnostic_model_domain_evaluations"] == 8*3*5
    assert training["history_source_scored_body_transition_presentations"] == 8*8192*16*9
    assert training["original_baby_completed_body_target_presentations_reused"] == 8*8192*16*16
    assert all(row["history_to_baby_valid_target_ratio"] == 9/16 for row in training["per_seed_source_budget"])
    replay = training["adaptation_by_arm"]["replay_mix"]
    assert replay["new_experience_clip_presentations"] == replay["old_experience_clip_presentations"] == 98304
    assert result["evaluation"]["unique_control_steps"] == 59360*40
    assert result["limits"]["estimated_wall_seconds"] is None
    assert result["limits"]["runtime_guaranteed"] is False


def test_plan_schedule_and_checkpoint_aliases_match_actual_runner():
    from devbaby.supplement import Experiment
    p = protocol()
    runner = Experiment.__new__(Experiment)
    runner.p = p
    runner.source, runner.root = Path("/virtual/source"), Path("/virtual/output")
    runner.source_cfgs = {seed: SimpleNamespace(updates_per_block=512) for seed in p["seeds"]}
    real = list(runner.schedule())
    symbolic = list(scheduled_panels(p))
    assert len(real) == len(symbolic)
    identities = {}
    actual_unique = set()
    for (actual_metadata, actual_n, path), (metadata, n, identity) in zip(real, symbolic):
        assert actual_metadata == metadata
        assert actual_n == n
        if identity in identities:
            assert identities[identity] == path
        identities[identity] = path
        actual_unique.add(execution_identity(metadata, n, path))
    # Logical source identities and source checkpoint files are a bijection.
    assert len(set(identities.values())) == len(identities)
    assert len(actual_unique) == plan(p)["unique_execution_panels"]


def test_aliases_do_not_change_with_phase_arm_or_frozen_budget_labels():
    original = dict(phase="adaptation", split="validation", seed=0, model="baby", arm="frozen",
                    source_age=32768, budget=0, domain="delay_3", task="reach")
    frozen_later = {**original, "budget": 2048}
    untrained_arm = {**original, "arm": "low_lr"}
    development = {**original, "phase": "development"}
    key = execution_identity(original, 12, checkpoint_identity(original))
    for metadata in (frozen_later, untrained_arm, development):
        assert execution_identity(metadata, 12, checkpoint_identity(metadata)) == key
    fitted = {**untrained_arm, "budget": 2048}
    assert execution_identity(fitted, 12, checkpoint_identity(fitted)) != key
    assert execution_identity(original, 32, checkpoint_identity(original)) != key
    assert execution_identity({**original, "split": "final"}, 12, checkpoint_identity(original)) != key


def test_reference_policies_never_alias_despite_all_having_no_checkpoint():
    rows = [r for r in scheduled_panels(protocol()) if r[0]["phase"] == "reference"]
    assert all(checkpoint is None for _, _, checkpoint in rows)
    assert len({execution_identity(m, n, cp) for m, n, cp in rows}) == len(rows)


def test_source_payload_expectations_match_real_age_update_identity():
    rows = plan(protocol())["training"]["expected_source_checkpoint_payloads"]
    for row in rows:
        assert row["expected_update"] == row["block"]*512
        assert row["expected_interactions"] == row["block"]*32*64 == row["source_age"]
        assert f'full-s{row["seed"]}/checkpoints/model_{row["expected_update"]:08d}.pt' in row["relative_path"]


def test_supplied_configurations_control_counts_and_reject_identity_mismatch():
    p = protocol()
    cfg = json.loads((ROOT/"configs/formal.json").read_text())
    configs = {seed: {**cfg, "physics_steps": 80} for seed in p["seeds"]}
    result = plan(p, source_configs=configs)
    assert result["source_config_basis"] == "provided_verified_source_configurations"
    assert result["evaluation"]["unique_control_steps"] == 59360*80
    configs[0]["episode_steps"] = 32
    with pytest.raises(ValueError, match="age/block/interaction"):
        plan(p, source_configs=configs)


def test_development_protocol_uses_its_own_counts():
    p = copy.deepcopy(protocol())
    p.update(development_only=True, seeds=[0], source_ages=[0, 2048], source_blocks=[0, 1],
             mature_source_age=2048, budgets=[0, 64], history_updates_per_block=2,
             adaptation_domains=["delay_3"], development_domains=["iid"],
             delay_domains=["delay_0"], push_domains=["iid"], adaptation_tasks=["reach"],
             final_trials=1, validation_trials=1, development_trials=1, retention_trials=1,
             diagnostic_episodes=1)
    result = plan(p)
    assert result["training"]["all_new_optimizer_updates"] == 2+6*16
    assert result["training"]["unique_new_adaptation_interactions"] == 64
    assert result["training"]["original_checkpoints_reused"] == 2
    assert result["unique_execution_trials"] < result["scheduled_trials"]
