"""Tiny complete experiment and interruption/integrity contracts (CPU only)."""
from copy import deepcopy
from dataclasses import asdict
import json
from pathlib import Path
import shutil
import time
import zipfile

import numpy as np
import pytest
import torch

from devbaby.config import Config
from devbaby.model import Baby
import devbaby.supplement as runner
from devbaby.supplement_learning import parameter_hashes
from devbaby.utils import atomic_json, sha256


@pytest.fixture
def tiny_source(tmp_path, monkeypatch):
    # Concurrent development of unrelated package files must not make these
    # operational tests depend on the instant at which a source hash is read.
    # A separate test below verifies lock rejection of changed code identity.
    monkeypatch.setattr(runner, 'code_digest', lambda: 'test-locked-code')
    monkeypatch.delenv('DEVBABY_SUPPLEMENT_DEADLINE_UNIX', raising=False)
    cfg=Config(seed=0,hidden=16,episode_steps=6,clip_steps=3,batch_size=2,
               blocks=2,episodes_per_block=1,updates_per_block=1,
               evaluation_mode='physics',motor_domain_randomization=True,
               physics_trials=1,physics_steps=3,planner_horizon=1,
               planner_candidates=4,planner_iterations=1,threads=1,save_video=False)
    source=tmp_path/'source';member=source/'members/full-s0'
    (member/'checkpoints').mkdir(parents=True)
    cfg.save(member/'config.json')
    torch.manual_seed(10);model=Baby(cfg)
    for block in range(3):
        # Synthetic source checkpoints are test fixtures, never research data.
        torch.save(dict(config=asdict(cfg),model=model.state_dict(),update=block,
                        interactions=block*6),member/'checkpoints'/f'model_{block:08d}.pt')
    rng=np.random.default_rng(4)
    for ep in range(2):
        path=member/'data/episodes'/f'{ep:07d}';path.mkdir(parents=True)
        np.savez_compressed(path/'observations.npz',
            rgb=rng.integers(0,256,(7,64,64,3),dtype=np.uint8),
            audio=rng.normal(0,.1,(7,32,16)).astype(np.float32),
            proprio=rng.normal(0,.1,(7,10)).astype(np.float32),
            actions=rng.uniform(-1,1,(6,5)).astype(np.float32))
        atomic_json(path/'complete.json',dict(fixture=True))
    protocol=dict(version='unit-supplement',development_only=True,seeds=[0],
        source_ages=[0,6,12],source_blocks=[0,1,2],mature_source_age=12,
        history_updates_per_block=1,history_length=2,history_width=16,history_cache_episodes=1,
        adaptation_domains=['delay_1'],adaptation_tasks=['reach'],
        arms=['frozen','full_update','low_lr','frozen_encoder','replay_mix','history'],
        budgets=[0,6],adaptation_updates_per_episode=1,
        development_domains=['iid'],delay_domains=['delay_1'],push_domains=['iid'],
        development_trials=1,validation_trials=1,final_trials=1,retention_trials=1,
        diagnostic_episodes=1,diagnostic_horizons=[1,2],namespace='unit-new-supplement-panels',
        bootstrap_replicates=10,job_seconds=300,sync_seconds=999,
        record_evaluation_sensory=True)
    protocol_path=tmp_path/'protocol.json';atomic_json(protocol_path,protocol)
    return source,protocol_path,cfg,protocol


def experiment(fixture, root, resume=False):
    source,protocol,_,_=fixture
    return runner.Experiment(source,root,protocol,'cpu',resume=resume)


def parameter_state(path):
    return torch.load(path,map_location='cpu',weights_only=False)['model']


def assert_models_equal(left,right):
    a,b=parameter_state(left),parameter_state(right)
    assert a.keys()==b.keys()
    assert all(torch.equal(a[key],b[key]) for key in a)


def test_complete_tiny_suite_records_every_modality_and_resumes_without_retraining(tiny_source,tmp_path,monkeypatch):
    output=tmp_path/'complete'
    actual_run_trial=runner.run_trial;calls=[]
    def tracked_trial(*args,**kwargs):
        state=runner.read(output/'supplement_state.json')
        assert state['training_complete'] is True
        calls.append((args[2:5],kwargs['policy'],kwargs['split']))
        return actual_run_trial(*args,**kwargs)
    monkeypatch.setattr(runner,'run_trial',tracked_trial)
    result=experiment(tiny_source,output).run()
    assert result['status']=='completed' and result['training_complete']
    plan=runner.read(output/'planned_evaluations.json')
    evaluations=list((output/'evaluations').glob('*/result.json'))
    panels=list((output/'physical_panels').glob('*/panel.json'))
    assert len(evaluations)==plan['cells']
    assert len(calls)==len(panels)<len(evaluations)
    assert all(not (panel.parent/'trials').exists() for panel in panels)
    for panel in panels:
        archive=output/runner.read(panel)['sensory_archive']
        with zipfile.ZipFile(archive) as packed:
            names=packed.namelist()
            assert any(name.endswith('observations.npz') for name in names)
            assert any(name.endswith('audio.wav') for name in names)
            assert any(name.endswith('annotations/frames.jsonl') for name in names)
    summary=runner.read(output/'summary.json')
    assert summary['status']=='completed' and summary['development_only']
    assert not any(test['positive_evidence'] for test in summary['primary_tests'])
    source=tiny_source[0]
    training_paths={str(path.resolve()) for path in (source/'members/full-s0/data/episodes').glob('*/observations.npz')}
    test_paths={str(path.resolve()) for path in (output/'diagnostic_experience').glob('**/observations.npz')}
    assert training_paths.isdisjoint(test_paths)
    traces=list((output/'checkpoints').rglob('training_trace.jsonl'))
    assert len(traces)==8  # history + 2 young full-update + 5 mature updating arms
    assert all(runner.read(path.parent/'complete.json') for path in traces)
    before={str(path.relative_to(output)):sha256(path) for path in (output/'checkpoints').rglob('*.pt')}
    prior_calls=len(calls)
    def forbidden(*args,**kwargs):raise AssertionError('Completed resume performed an update')
    monkeypatch.setattr(runner,'adaptation_step',forbidden)
    monkeypatch.setattr(runner,'history_loss',forbidden)
    result=experiment(tiny_source,output,resume=True).run()
    assert result['status']=='completed' and len(calls)==prior_calls
    assert before=={str(path.relative_to(output)):sha256(path) for path in (output/'checkpoints').rglob('*.pt')}


def test_history_recovers_checkpoint_committed_before_age_snapshot(tiny_source,tmp_path,monkeypatch):
    clean=experiment(tiny_source,tmp_path/'clean');clean.history_training(0)
    interrupted=experiment(tiny_source,tmp_path/'interrupted')
    original_save=runner.save_model;fired=False
    def fail_snapshot(path,*args,**kwargs):
        nonlocal fired
        if Path(path).name=='age_00000006.pt' and not fired:
            fired=True
            raise RuntimeError('interrupt after last checkpoint before age snapshot')
        return original_save(path,*args,**kwargs)
    monkeypatch.setattr(runner,'save_model',fail_snapshot)
    with pytest.raises(RuntimeError,match='before age snapshot'):
        interrupted.history_training(0)
    assert (interrupted.root/'checkpoints/history/s0/last.pt').exists()
    assert not interrupted.history_checkpoint(0,6).exists()
    monkeypatch.setattr(runner,'save_model',original_save)
    restored=experiment(tiny_source,interrupted.root,resume=True);restored.history_training(0)
    for age in (0,6,12):assert_models_equal(clean.history_checkpoint(0,age),restored.history_checkpoint(0,age))
    a=(clean.root/'checkpoints/history/s0/training_trace.jsonl').read_text()
    b=(restored.root/'checkpoints/history/s0/training_trace.jsonl').read_text()
    assert a==b


def test_adaptation_mid_episode_restart_trims_uncommitted_updates(tiny_source,tmp_path,monkeypatch):
    source,protocol_path,cfg,protocol=tiny_source
    protocol['adaptation_updates_per_episode']=2;protocol['budgets']=[0,6,12]
    atomic_json(protocol_path,protocol)
    clean=experiment(tiny_source,tmp_path/'clean');clean.prepare_experience(0,'delay_1')
    clean.adapt(0,12,'delay_1','replay_mix')
    interrupted=experiment(tiny_source,tmp_path/'interrupted')
    # eSpeak's internal synthesis can vary across independent re-generation.
    # Resume correctness is tested on identical committed sensor recordings,
    # exactly as all arms in one experiment share their saved experience.
    shutil.copytree(clean.root/'experience',interrupted.root/'experience')
    interrupted.prepare_experience(0,'delay_1')
    actual=runner.adaptation_step;calls=0
    def fail_step(*args,**kwargs):
        nonlocal calls
        calls+=1
        if calls==4:raise RuntimeError('mid episode interruption')
        return actual(*args,**kwargs)
    monkeypatch.setattr(runner,'adaptation_step',fail_step)
    with pytest.raises(RuntimeError,match='mid episode'):
        interrupted.adapt(0,12,'delay_1','replay_mix')
    trace=interrupted.root/'checkpoints/adaptation/s0/age_00000012/delay_1/replay_mix/training_trace.jsonl'
    assert len(trace.read_text().splitlines())==3
    monkeypatch.setattr(runner,'adaptation_step',actual)
    resumed=experiment(tiny_source,interrupted.root,resume=True);resumed.adapt(0,12,'delay_1','replay_mix')
    for budget in (6,12):assert_models_equal(clean.checkpoint(0,12,'replay_mix','delay_1',budget),resumed.checkpoint(0,12,'replay_mix','delay_1',budget))
    assert (clean.root/trace.relative_to(interrupted.root)).read_text()==trace.read_text()


@pytest.mark.parametrize('field,value',[('interactions',999),('update',999),('config_seed',7)])
def test_source_payload_mismatch_rejected_before_training(tiny_source,tmp_path,field,value):
    path=tiny_source[0]/'members/full-s0/checkpoints/model_00000001.pt'
    payload=torch.load(path,weights_only=False)
    if field=='config_seed':payload['config']['seed']=value
    else:payload[field]=value
    torch.save(payload,path)
    with pytest.raises(ValueError,match='Source checkpoint payload'):
        experiment(tiny_source,tmp_path/'bad')
    assert not (tmp_path/'bad/checkpoints').exists()


def test_resume_rejects_changed_source_weights_or_code(tiny_source,tmp_path,monkeypatch):
    root=tmp_path/'locked';experiment(tiny_source,root)
    monkeypatch.setattr(runner,'code_digest',lambda:'changed-code')
    with pytest.raises(ValueError,match='Protocol/code/source changed'):
        experiment(tiny_source,root,resume=True)
    monkeypatch.setattr(runner,'code_digest',lambda:'test-locked-code')
    path=tiny_source[0]/'members/full-s0/checkpoints/model_00000001.pt'
    payload=torch.load(path,weights_only=False)
    name=next(iter(payload['model']));payload['model'][name].add_(1)
    torch.save(payload,path)
    with pytest.raises(ValueError,match='Protocol/code/source changed'):
        experiment(tiny_source,root,resume=True)


def test_corrupt_resume_identity_rejected_and_completion_cannot_hide_missing_weights(tiny_source,tmp_path):
    run=experiment(tiny_source,tmp_path/'run');run.prepare_experience(0,'delay_1')
    run.adapt(0,12,'delay_1','full_update')
    folder=run.root/'checkpoints/adaptation/s0/age_00000012/delay_1/full_update'
    snapshot=run.checkpoint(0,12,'full_update','delay_1',6)
    snapshot.unlink()
    with pytest.raises(ValueError,match='artifact missing or changed'):
        run.adapt(0,12,'delay_1','full_update')
    (folder/'complete.json').unlink()
    payload=torch.load(folder/'last.pt',weights_only=False);payload['arm']='low_lr'
    torch.save(payload,folder/'last.pt')
    with pytest.raises(ValueError,match='identity mismatch'):
        run.adapt(0,12,'delay_1','full_update')


def test_global_deadline_accounts_for_cloud_setup_time(tiny_source,tmp_path,monkeypatch):
    monkeypatch.setenv('DEVBABY_SUPPLEMENT_DEADLINE_UNIX',str(time.time()-1))
    run=experiment(tiny_source,tmp_path/'expired')
    with pytest.raises(runner.BudgetReached):run.check()
    state=run.run()
    assert state['status']=='time_budget_reached'
    assert not state['training_complete']
    assert not list((run.root/'physical_panels').glob('*/panel.json'))


def test_trace_truncation_retains_committed_chain_and_rejects_gaps(tmp_path):
    path=tmp_path/'training_trace.jsonl'
    for step in range(1,4):runner.append_training_trace(path,step,[],{'loss':float(step)})
    with path.open('a') as stream:stream.write('{"update":4')
    runner.trim_training_trace(path,2)
    assert [json.loads(line)['update'] for line in path.read_text().splitlines()]==[1,2]
    path.write_text('{"update":1}\n{"update":3}\n')
    with pytest.raises(ValueError,match='duplicate or missing'):
        runner.trim_training_trace(path,2)
