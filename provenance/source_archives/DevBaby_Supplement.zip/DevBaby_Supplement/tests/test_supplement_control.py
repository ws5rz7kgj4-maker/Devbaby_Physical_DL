"""Temporal alignment, causality, and nonprivileged supplemental controls."""
import copy
from types import SimpleNamespace

import numpy as np
import pytest
import torch
from torch import nn

from devbaby.config import Config
from devbaby.model import Baby
from devbaby.physical import Goal, LearnedController
from devbaby.supplement_control import (
    FeedbackController, HistoryController, HistoryDynamics,
    SupplementalController, controller_factory, history_loss,
)
from devbaby.world import ACTION_DIM, PROPRIO_DIM


@pytest.fixture(scope="module", autouse=True)
def small_thread_budget():
    previous = torch.get_num_threads()
    torch.set_num_threads(1)
    yield
    torch.set_num_threads(previous)


def configuration():
    cfg = Config()
    cfg.hidden = 16
    cfg.planner_candidates = 8
    cfg.planner_horizon = 3
    cfg.planner_iterations = 2
    return cfg


def observations(seed=13):
    rng = np.random.default_rng(seed)
    return {
        "rgb": rng.integers(0, 256, (64, 64, 3), dtype=np.uint8),
        "audio": rng.normal(0, .01, (32, 16)).astype(np.float32),
        "proprio": np.array([.2, 0, .3, 0, 0, 0, 0, 0, 0, 0], np.float32),
    }


def make_batch(steps=12, batch_size=2):
    generator = torch.Generator().manual_seed(321)
    return {
        "proprio": torch.rand(batch_size, steps+1, PROPRIO_DIM, generator=generator),
        "actions": torch.rand(batch_size, steps, ACTION_DIM, generator=generator)*2-1,
    }


class DelayedBody(nn.Module):
    """Known causal dynamics for checking controller indexing, never a policy."""
    def __init__(self, history=8, delay=6):
        super().__init__()
        self.history, self.delay = history, delay

    def predict_window(self, pairs):
        pr = pairs[..., -1, :PROPRIO_DIM].clone()
        pr[..., :3] += .1*pairs[..., -self.delay-1, PROPRIO_DIM:PROPRIO_DIM+3]
        return pr


def test_history_windows_pair_present_observation_and_issued_action():
    model = HistoryDynamics(configuration(), history=4, width=12)
    batch = make_batch()
    captured = []
    handle = model.net.register_forward_pre_hook(lambda module, args: captured.append(args[0].clone()))
    output = model(batch)
    handle.remove()
    windows = captured[0].reshape(2, 9, 4, PROPRIO_DIM+ACTION_DIM)
    torch.testing.assert_close(windows[:, 0, :, :PROPRIO_DIM], batch["proprio"][:, :4])
    torch.testing.assert_close(windows[:, 0, :, PROPRIO_DIM:], batch["actions"][:, :4])
    torch.testing.assert_close(windows[:, -1, :, :PROPRIO_DIM], batch["proprio"][:, 8:12])
    torch.testing.assert_close(output["target_body"], batch["proprio"][:, 4:])
    assert output["first_prediction_action_index"] == 3
    _, metrics = history_loss(model, batch)
    assert metrics["valid_transitions_per_clip"] == 9


def test_future_commands_and_unread_annotations_cannot_change_earlier_predictions():
    model = HistoryDynamics(configuration(), history=4, width=12)
    batch = make_batch()
    before = model(batch)["pred_body"].detach()
    changed = {key: value.clone() for key, value in batch.items()}
    changed["actions"][:, 9:] = 100
    changed["proprio"][:, 10:] = -100
    changed["applied_actions"] = torch.full_like(batch["actions"], float("nan"))
    changed["annotations"] = {"delay": 999, "object_positions": "forbidden"}
    after = model(changed)["pred_body"].detach()
    # The first six predictions end in command indices 3..8.
    torch.testing.assert_close(before[:, :6], after[:, :6], rtol=0, atol=0)
    with pytest.raises(ValueError, match="full history"):
        model(make_batch(steps=3))


@pytest.mark.parametrize("delay", [0, 1, 6])
def test_autoregressive_rollout_uses_issued_command_at_correct_delay(delay):
    cfg = configuration()
    model = DelayedBody(history=8, delay=delay)
    controller = HistoryController(model, cfg, "cpu", seed=4)
    obs = observations()
    old_actions = np.arange(7*ACTION_DIM, dtype=np.float32).reshape(7, ACTION_DIM)/100
    for action in old_actions:
        controller.past.append(np.concatenate([obs["proprio"], action]))
    candidates = np.arange(2*10*ACTION_DIM, dtype=np.float32).reshape(2, 10, ACTION_DIM)/100
    snapshot = copy.deepcopy(controller.state_dict())
    actual = controller.rollout(obs, candidates).numpy()
    expected = np.zeros((2, 10, PROPRIO_DIM), np.float32)
    for candidate in range(2):
        pr = obs["proprio"].copy()
        commands = list(old_actions)
        for t in range(10):
            commands.append(candidates[candidate, t])
            pr[:3] += .1*commands[-delay-1][:3]
            expected[candidate, t] = pr
    np.testing.assert_allclose(actual, expected, atol=1e-7)
    assert controller.state_dict() == snapshot


def test_online_and_training_history_alignment_match_after_burnin():
    cfg = configuration()
    model = HistoryDynamics(cfg, history=4, width=12)
    batch = make_batch(steps=10, batch_size=1)
    train_prediction = model(batch)["pred_body"].detach()
    for t in range(3, 10):
        controller = HistoryController(model, cfg, "cpu", seed=4)
        for old_t in range(t-3, t):
            controller.past.append(torch.cat([batch["proprio"][0, old_t], batch["actions"][0, old_t]]).numpy())
        obs = {"proprio": batch["proprio"][0, t].numpy()}
        candidate = batch["actions"][0, t].numpy()[None, None]
        test_prediction = controller.rollout(obs, candidate)[0, 0]
        torch.testing.assert_close(test_prediction, train_prediction[0, t-3])


def test_partial_history_padding_retains_observed_episode_initial_state():
    cfg = configuration()
    model = HistoryDynamics(cfg, history=4, width=12)
    controller = HistoryController(model, cfg, "cpu", seed=1)
    initial = observations()["proprio"]
    controller.past.append(np.concatenate([initial, np.ones(ACTION_DIM, np.float32)]))
    current = initial + .3
    context = controller._context(current, 1)[0].numpy()
    np.testing.assert_array_equal(context[:2, :PROPRIO_DIM], np.repeat(initial[None], 2, axis=0))
    np.testing.assert_array_equal(context[:2, PROPRIO_DIM:], np.zeros((2, ACTION_DIM)))


def test_history_dynamics_learns_observable_delayed_transitions_and_roundtrips(tmp_path):
    torch.manual_seed(48)
    cfg = configuration()
    model = HistoryDynamics(cfg, history=4, width=32)
    generator = torch.Generator().manual_seed(17)
    actions = torch.rand(32, 12, ACTION_DIM, generator=generator)*2-1
    pr = torch.zeros(32, 13, PROPRIO_DIM)
    for t in range(12):
        pr[:, t+1] = pr[:, t]
        if t >= 2:
            pr[:, t+1, :3] += .1*actions[:, t-2, :3]
    batch = {"proprio": pr, "actions": actions}
    optimizer = torch.optim.Adam(model.parameters(), lr=.003)
    initial_loss = history_loss(model, batch)[0].item()
    for _ in range(100):
        optimizer.zero_grad()
        loss, _ = history_loss(model, batch)
        loss.backward()
        optimizer.step()
    assert history_loss(model, batch)[0].item() < initial_loss*.05
    checkpoint = tmp_path/"history.pt"
    torch.save({"model": model.state_dict(), "optimizer": optimizer.state_dict()}, checkpoint)
    restored = HistoryDynamics(cfg, history=4, width=32)
    restored.load_state_dict(torch.load(checkpoint, weights_only=True)["model"])
    torch.testing.assert_close(restored(batch)["pred_body"], model(batch)["pred_body"], rtol=0, atol=0)


@pytest.mark.parametrize("task", ["reach", "touch", "grasp_lift"])
def test_supplemental_baby_controller_preserves_original_actions(task):
    torch.manual_seed(24)
    cfg = configuration()
    baby = Baby(cfg).eval()
    original = LearnedController(baby, cfg, "cpu", seed=47)
    supplement = SupplementalController(baby, cfg, "cpu", seed=47)
    goal = Goal(task, (.6, .1, .4), (.5, .1, .1))
    for step in range(3):
        obs = observations(seed=step)
        np.testing.assert_array_equal(original(obs, goal), supplement(obs, goal))
    torch.testing.assert_close(original.state, supplement.state, rtol=0, atol=0)


@pytest.mark.parametrize("kind", ["world", "history", "feedback"])
def test_controllers_resume_without_changing_actions_or_reading_hidden_keys(kind):
    torch.manual_seed(28)
    cfg = configuration()
    model = HistoryDynamics(cfg, history=4, width=12) if kind == "history" else Baby(cfg).eval()
    original = controller_factory(kind, model, cfg, "cpu", seed=55)
    resumed = controller_factory(kind, model, cfg, "cpu", seed=999)
    goal = Goal("push", (.7, .1, .2), (.3, .1, .2))
    original(observations(), goal)
    resumed.load_state_dict(original.state_dict())
    plain = observations(seed=14)
    extra = copy.deepcopy(plain)
    extra["motor_delay"] = 300
    extra["applied_action"] = np.full(ACTION_DIM, float("nan"))
    extra["object_positions"] = np.full((3, 3), 1e9)
    action = original(plain, goal)
    np.testing.assert_array_equal(action, resumed(extra, goal))
    assert action.shape == (ACTION_DIM,)
    assert np.all(np.abs(action) <= 1)
    assert action[3] == -1 and action[4] == 0


@pytest.mark.parametrize("kind", ["world", "history", "feedback"])
def test_push_phase_uses_only_supplied_contact_point(kind):
    cfg = configuration()
    model = HistoryDynamics(cfg, history=4, width=12) if kind == "history" else Baby(cfg).eval()
    controller = controller_factory(kind, model, cfg, "cpu", seed=77)
    goal = SimpleNamespace(task="push", position=(.7, .1, .2), contact_position=(.3, .1, .2))
    obs = observations()
    controller(obs, goal)
    assert controller.phase == 0
    obs["proprio"][:3] = goal.contact_position
    controller(obs, goal)
    assert controller.phase == 1
    obs["proprio"][:3] = [-.1, -.1, .6]
    controller(obs, goal)
    assert controller.phase == 1


def test_one_step_history_and_invalid_planner_configuration():
    cfg = configuration()
    model = HistoryDynamics(cfg, history=1, width=12)
    controller = HistoryController(model, cfg, "cpu", 13)
    goal = Goal("reach", (.6, .1, .4), (.5, .1, .1))
    controller(observations(), goal)
    assert len(controller.past) == 0
    cfg.planner_candidates = 1
    with pytest.raises(ValueError, match="CEM requires"):
        HistoryController(model, cfg, "cpu", 13)


def test_feedback_controller_observes_body_but_never_hidden_servo_target():
    controller = FeedbackController(configuration())
    obs = observations()
    goal = Goal("reach", (.6, .1, .4), (.5, .1, .1))
    first = controller(obs, goal)
    obs["target"] = np.array([100, 100, 100])
    np.testing.assert_array_equal(first, controller(obs, goal))
    obs["proprio"][3:6] = 1
    assert not np.array_equal(first, controller(obs, goal))
