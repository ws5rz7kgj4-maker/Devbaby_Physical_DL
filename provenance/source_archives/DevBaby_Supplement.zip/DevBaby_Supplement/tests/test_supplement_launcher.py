"""Offline safety/integrity checks: fake API, never real GPU submissions."""
import hashlib
import fnmatch
import io
import json
from pathlib import Path
from tempfile import TemporaryDirectory
from types import SimpleNamespace as NS
import unittest
from unittest.mock import patch
import zipfile
from dataclasses import asdict
import SUPPLEMENT as launcher
import supplement_cloud as cloud
from devbaby.config import Config

PACKAGE = Path(launcher.__file__).resolve().parent

def job(identifier='job-test', stage='RUNNING', key=None):
    return NS(id=identifier, url='https://huggingface.co/jobs/test/'+identifier,
              status=NS(stage=stage), labels={'devbaby_supplement_key':key}, environment={})

def fixture():
    protocol = {'protocol':json.loads((PACKAGE/'formal_protocol.json').read_text()),
                'training_config':asdict(Config.load(PACKAGE/'configs/formal.json')),
                'source_archive':'source/'+launcher.SOURCE_HASH+'.zip', 'sha256':launcher.SOURCE_PROTOCOL}
    data = {f'runs/{launcher.SOURCE_RUN}/protocol.json':protocol}; files=set(data)
    for seed in range(8):
        member=f'runs/{launcher.SOURCE_RUN}/members/full-s{seed}'
        data[member+'/config.json']={**protocol['training_config'],'seed':seed}
        shards=[{'file':f'data/shards/block_{i:04d}.zip','bytes':i+1,'sha256':'a'*64} for i in range(16)]
        data[member+'/data_manifest.json']={'shards':shards}
        files.update(member+'/'+s['file'] for s in shards)
        files.update(f'{member}/checkpoints/model_{u:08d}.pt' for u in (0,4096,8192))
    files.update(data); return data,files

class FakeAPI:
    token='test-token-never-recorded'
    def __init__(self): self.jobs=[]; self.calls=[]; self.fail_submission=False
    def repo_info(self, **kw): return NS(sha='a'*40,private=True)
    def create_repo(self, **kw): self.calls.append(('create_repo',kw))
    def file_exists(self, **kw): return False
    def list_jobs(self, **kw): return self.jobs
    def inspect_job(self,job_id,**kw): return next(j for j in self.jobs if j.id==job_id)
    def create_commit(self, **kw): self.calls.append(('commit',kw)); return NS(oid='b'*40)
    def run_job(self, **kw):
        self.calls.append(('run_job',kw)); j=job(key=kw['labels']['devbaby_supplement_key']); self.jobs.append(j)
        if self.fail_submission: raise OSError('lost response')
        return j

class LauncherTests(unittest.TestCase):
    def test_default_download_exact_reports_exclude_nested_raw_traces(self):
        base='runs/fixed'; patterns=launcher.download_patterns(base)
        for name in ['traces/cell/trial.json','adaptation/model/data/episodes/0001/annotations.json',
                     'checkpoints/metadata.json','nested/summary.json','traces/cell/actions.csv']:
            self.assertFalse(any(fnmatch.fnmatchcase(base+'/'+name,pattern) for pattern in patterns))
        self.assertTrue(any(fnmatch.fnmatchcase(base+'/summary.json',pattern) for pattern in patterns))
        self.assertTrue(any(fnmatch.fnmatchcase(base+'/traces/cell/trial.json',pattern)
                            for pattern in launcher.download_patterns(base,all_files=True)))

    def test_protocol_recomputed_not_only_trusted(self):
        protocol=fixture()[0][f'runs/{launcher.SOURCE_RUN}/protocol.json']
        launcher.validate_original_protocol(protocol); protocol['training_config']['blocks']=15
        with self.assertRaises(ValueError): launcher.validate_original_protocol(protocol)

    def test_exact_24_checkpoints_128_shards_and_missing_fails(self):
        metadata,files=fixture()
        api=NS(repo_info=lambda **kw:NS(sha='r'*40),list_repo_files=lambda **kw:list(files))
        with patch.object(launcher,'remote_json',side_effect=lambda api,repo,path,rev:metadata[path]):
            locator=launcher.inspect_original(api,'test/prior',launcher.SOURCE_RUN)
        self.assertEqual(len(locator['checkpoints']),24); self.assertEqual(len(locator['shards']),128)
        self.assertTrue(all('no_action' not in p for p in locator['allow_paths']))
        self.assertEqual(locator['revision'],'r'*40)
        files.remove(locator['checkpoints'][-1]['path'])
        with patch.object(launcher,'remote_json',side_effect=lambda api,repo,path,rev:metadata[path]):
            with self.assertRaisesRegex(ValueError,'Missing pretrained checkpoint'):
                launcher.inspect_original(api,'test/prior',launcher.SOURCE_RUN)

    def test_duplicate_raw_block_fails(self):
        data,files=fixture(); member=f'runs/{launcher.SOURCE_RUN}/members/full-s0'; manifest=data[member+'/data_manifest.json']
        manifest['shards'][15]=manifest['shards'][14]
        with self.assertRaisesRegex(ValueError,'16 unique'): launcher.validate_shards(manifest,member,files)

    def test_archive_stable_excludes_credentials(self):
        with TemporaryDirectory() as tmp:
            root=Path(tmp); (root/'devbaby').mkdir(); (root/'devbaby/model.py').write_text('VALUE = 1\n')
            (root/'.token').write_text('SECRET'); (root/'.supplement_launch_records').mkdir()
            (root/'.supplement_launch_records/record.json').write_text('SECRET'); (root/'outputs').mkdir()
            (root/'outputs/data.json').write_text('SECRET')
            a,ah=launcher.source_bytes(root); b,bh=launcher.source_bytes(root); self.assertEqual((a,ah),(b,bh))
            with zipfile.ZipFile(io.BytesIO(a)) as z: self.assertEqual(z.namelist(),['devbaby/model.py'])

    def test_zip_traversal_and_symlink_rejected(self):
        with TemporaryDirectory() as tmp:
            root=Path(tmp); archive=root/'bad.zip'
            for name in ['../escape','/tmp/escape','data/../../escape','data\\escape']:
                with zipfile.ZipFile(archive,'w') as z: z.writestr(name,'bad')
                with self.assertRaises(ValueError): cloud.safe_extract(archive,root/'target')
            with zipfile.ZipFile(archive,'w') as z:
                info=zipfile.ZipInfo('data/link'); info.external_attr=(0o120777<<16); z.writestr(info,'../../escape')
            with self.assertRaises(ValueError): cloud.safe_extract(archive,root/'target')

    def test_source_sha_integrity(self):
        with TemporaryDirectory() as tmp:
            f=Path(tmp)/'test.zip'; f.write_bytes(b'abc'); meta={'bytes':3,'sha256':hashlib.sha256(b'abc').hexdigest()}
            cloud.check_file(f,meta); f.write_bytes(b'xyz')
            with self.assertRaisesRegex(ValueError,'SHA-256'): cloud.check_file(f,meta)

    def test_exclusive_lock(self):
        with TemporaryDirectory() as tmp:
            lock=Path(tmp)/'lock'
            with launcher.exclusive_lock(lock):
                with self.assertRaisesRegex(RuntimeError,'Submission lock'):
                    with launcher.exclusive_lock(lock): self.fail('Obtained second lock')
            self.assertFalse(lock.exists())

    def test_uncertain_submit_never_retries(self):
        api=FakeAPI()
        with self.assertRaisesRegex(RuntimeError,'unknown'): launcher.reconcile(api,'test',{'phase':'submitting','submission_key':'key'})
        self.assertFalse(api.calls)
        api.jobs=[job(key='key')]
        self.assertEqual(launcher.reconcile(api,'test',{'phase':'submitting','submission_key':'key'})['job_id'],'job-test')

    def test_lost_response_durable_record_and_no_second_job(self):
        with TemporaryDirectory() as tmp,patch.object(launcher,'ROOT',Path(tmp)):
            (Path(tmp)/'supplement_protocol.json').write_text('{"fixed":true}')
            api=FakeAPI(); api.fail_submission=True; args=launcher.parser().parse_args(['launch'])
            locator={'repo_id':'test/original','revision':'c'*40,'known_shard_bytes':100,'run_id':launcher.SOURCE_RUN}
            with patch.object(launcher,'validate_local',return_value=({'fixed':True},'protocol')),patch.object(launcher,'source_bytes',return_value=(b'source','d'*64)),patch.object(launcher,'discover_original',return_value=locator),patch.object(launcher,'show_budget'):
                with self.assertRaisesRegex(RuntimeError,'Unknown submission'): launcher.submit(api,api.token,'test',args)
                path=launcher.record_location(args); record=launcher.read_json(path)
                self.assertEqual(record['phase'],'submitting'); self.assertNotIn(api.token,path.read_text())
                self.assertEqual(launcher.submit(api,api.token,'test',args)['job_id'],'job-test')
            calls=[kw for method,kw in api.calls if method=='run_job']; self.assertEqual(len(calls),1)
            self.assertEqual(calls[0]['timeout'],'24h'); self.assertEqual(calls[0]['flavor'],'t4-small')
            self.assertNotIn(api.token,json.dumps(calls[0]['env'])); self.assertEqual(calls[0]['secrets'],{'HF_TOKEN':api.token})
            self.assertFalse(launcher.RESERVED & set(calls[0]['env']))

    def test_completed_resume_no_paid_job(self):
        with TemporaryDirectory() as tmp,patch.object(launcher,'ROOT',Path(tmp)):
            (Path(tmp)/'supplement_protocol.json').write_text('{"fixed":true}'); api=FakeAPI(); api.jobs=[job(stage='COMPLETED')]
            api.file_exists=lambda **kw:True
            args=launcher.parser().parse_args(['resume']); path,_=launcher.record_paths('test/supplement','fixed')
            launcher.save_record(path,{'run_id':'fixed','result_repo':'test/supplement','job_id':'job-test','phase':'submitted','code_sha256':'d'*64,'protocol_sha256':'protocol','flavor':'t4-small','original_source':{'repo_id':'test/prior'}})
            with patch.object(launcher,'validate_local',return_value=({},'protocol')),patch.object(launcher,'source_bytes',return_value=(b'source','d'*64)),patch.object(launcher,'remote_json',return_value={'status':'completed'}):
                launcher.submit(api,api.token,'test',args,resume=True)
            self.assertFalse(any(method=='run_job' for method,kw in api.calls))

    def test_reads_old_local_record(self):
        with TemporaryDirectory() as tmp:
            root=Path(tmp)/'DevBaby_Supplement'; root.mkdir(); old=root.parent/'DevBaby_Physical_Final/.launch_records'; old.mkdir(parents=True)
            (old/'old.json').write_text(json.dumps({'run_id':launcher.SOURCE_RUN,'result_repo':'test/observed'}))
            self.assertEqual(launcher.local_source_candidates(root,launcher.SOURCE_RUN),['test/observed'])

    def test_experience_cannot_overwrite_config(self):
        with TemporaryDirectory() as tmp:
            root=Path(tmp); archive=root/'shard.zip'
            with zipfile.ZipFile(archive,'w') as z: z.writestr('config.json','{}')
            with self.assertRaisesRegex(ValueError,'Unexpected file'): cloud.safe_extract(archive,root/'member',required_prefix='data/episodes/')

    def test_setup_only_resume_requires_completely_empty_run_prefix(self):
        api=FakeAPI(); api.list_repo_files=lambda **kw:['supplement_source/source.zip']
        has_output,state=launcher.inspect_resume_output(api,'test/result','fixed','r'*40)
        self.assertFalse(has_output); self.assertEqual(state['status'],'setup_failed_before_output')
        api.list_repo_files=lambda **kw:['runs/fixed/checkpoints/last.pt']
        with self.assertRaisesRegex(RuntimeError,'possible checkpoints'):
            launcher.inspect_resume_output(api,'test/result','fixed','r'*40)

    def test_restore_output_moves_files_without_second_disk_copy(self):
        with TemporaryDirectory() as tmp:
            root=Path(tmp); cache=root/'cache'; saved=cache/'runs/fixed'; saved.mkdir(parents=True)
            (saved/'supplement_state.json').write_text('{"status":"time_budget_reached"}')
            (saved/'checkpoint.pt').write_bytes(b'checkpoint'); (saved/'source_locator.json').write_text('{"revision":"fixed"}')
            manifest={'resume':True,'resume_has_output':True,'resume_revision':'r'*40,'result_repo':'test/result','run_id':'fixed','original_source':{'revision':'fixed'}}
            with patch('huggingface_hub.snapshot_download') as download:
                cloud.restore_output(manifest,root/'output',cache)
            self.assertEqual((root/'output/checkpoint.pt').read_bytes(),b'checkpoint')
            self.assertFalse(cache.exists()); self.assertEqual(download.call_args.kwargs['revision'],'r'*40)

    def test_setup_upload_never_overwrites_training_state_on_resume(self):
        with TemporaryDirectory() as tmp,patch('huggingface_hub.HfApi') as api:
            cloud.publish_setup({'resume':True,'resume_has_output':True},Path(tmp))
            api.assert_not_called()

    def test_setup_state_is_persisted_before_expensive_work(self):
        with TemporaryDirectory() as tmp,patch('huggingface_hub.HfApi') as api:
            api.return_value.file_exists.return_value=False
            cloud.publish_setup({'resume':False,'result_repo':'test/result','run_id':'fixed'},Path(tmp))
            self.assertEqual(json.loads((Path(tmp)/'supplement_state.json').read_text()),{'status':'setup','phase':'setup'})
            api.return_value.upload_folder.assert_called_once()

if __name__=='__main__': unittest.main()
