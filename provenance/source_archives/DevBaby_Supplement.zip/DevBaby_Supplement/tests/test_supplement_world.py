"""Simulator contracts, information boundary and independent-panel checks."""
import json
from dataclasses import asdict
import numpy as np
import pytest
from scipy.io import wavfile

from devbaby.config import Config
from devbaby.supplement_world import (
    DomainSpec, SupplementWorld, collect_episode, get_domain, make_panel,
    panel_seed, run_trial,
)
from devbaby.world import World


def config(**kwargs):
    return Config(episode_steps=12, clip_steps=8, batch_size=2,
                  physics_steps=6, motor_domain_randomization=True, **kwargs)


@pytest.mark.parametrize("delay", [0, 1, 2, 3, 4, 6])
def test_fixed_delay_is_exact_fifo_without_reordering(delay):
    cfg = config()
    rng = np.random.default_rng(71)
    commands = rng.uniform(-.6, .6, (delay+5, 5)).astype(np.float32)
    with SupplementWorld(cfg, None, 991, f"delay_{delay}",
                         objects=[("red", "block")]) as world:
        assert world.motor_delay == delay
        for i, command in enumerate(commands):
            _, _, ann = world.step(command)
            np.testing.assert_array_equal(ann["issued_action"], command)
            np.testing.assert_array_equal(ann["applied_action"],
                                          np.zeros(5) if i < delay else commands[i-delay])
            assert len(world.action_queue) == delay


def test_scene_pairing_is_independent_of_delay_and_model_seed():
    base = panel_seed("locked-id", "iid", "reach", 4, "final")
    assert base == panel_seed("locked-id", "delay_6", "reach", 4, "final")
    assert base != panel_seed("locked-id", "iid", "reach", 4, "validation")
    assert base != panel_seed("locked-id", "iid", "reach", 4, "train")
    assert base != panel_seed("locked-id", "iid", "reach", 4, "diagnostic")
    with SupplementWorld(config(), None, base, "delay_0", [("red", "block")]) as a:
        first = a.observe()
        meta = a.metadata()
    with SupplementWorld(config(), None, base, "delay_6", [("red", "block")]) as b:
        other = b.observe()
        assert meta["objects"] == b.metadata()["objects"]
        for key in first:
            np.testing.assert_array_equal(first[key], other[key])
    seen_seeds = []
    def factory(seed):
        seen_seeds.append(seed)
        return lambda obs, goal: np.zeros(5, np.float32)
    a = run_trial(config(), None, "iid", "reach", 4, "locked-id", factory, model_seed=2)
    b = run_trial(config(), None, "iid", "reach", 4, "locked-id", factory, model_seed=8)
    assert a["scene_seed"] == b["scene_seed"] == base
    assert a["goal"] == b["goal"]
    assert seen_seeds[0] != seen_seeds[1]


def test_controller_has_only_sensors_and_fixed_task_inputs(tmp_path):
    calls = []
    def factory(seed):
        def controller(obs, goal):
            assert set(obs) == {"rgb", "audio", "proprio"}
            assert obs["rgb"].shape == (64, 64, 3)
            assert obs["audio"].shape == (32, 16)
            assert obs["proprio"].shape == (10,)
            assert not hasattr(goal, "delay_steps")
            calls.append(goal)
            return np.asarray([.1, 0, 0, 1, 0], np.float32)
        return controller
    result = run_trial(config(), None, "delay_2", "push", 0, "trace-test", factory,
                       output_dir=tmp_path, record_sensory=True)
    assert len(calls) == result["steps"]
    assert all(goal is calls[0] for goal in calls)
    path = next(tmp_path.rglob("observations.npz"))
    with np.load(path, allow_pickle=False) as trace:
        assert set(trace.files) == {"rgb", "audio", "proprio", "actions"}
        assert len(trace["rgb"]) == len(trace["actions"])+1
        assert np.all(trace["actions"][:, 3] == -1)
    annotations = [json.loads(x) for x in (path.parent/"annotations"/"frames.jsonl").read_text().splitlines()]
    assert len(annotations) == result["steps"]+1
    assert annotations[1]["requested_action"][3] == 1
    assert annotations[1]["issued_action"][3] == -1
    assert annotations[1]["applied_action"] == [0]*5
    rate, audio = wavfile.read(path.parent/"audio.wav")
    assert rate == 16000 and len(audio) == result["steps"]*2000


def test_original_world_and_caller_configuration_are_unchanged():
    cfg = config()
    before = asdict(cfg)
    with World(cfg, None, 75, "iid", [("red", "block")], False) as original:
        old_meta = original.metadata()
        old_obs = original.observe()
    with SupplementWorld(cfg, None, 75, "iid", [("red", "block")]) as supplement:
        assert supplement.cfg is not cfg
        assert supplement.metadata()["objects"] == old_meta["objects"]
        for key in old_obs:
            np.testing.assert_array_equal(old_obs[key], supplement.observe()[key])
    assert asdict(cfg) == before


def test_collection_cache_identity_and_annotation_separation(tmp_path):
    cfg = config()
    seed = panel_seed("adaptation", "delay_2", "reach", 0, "train")
    summary = collect_episode(cfg, None, tmp_path/"0000", seed, "delay_2", caregiver=False)
    assert summary == collect_episode(cfg, None, tmp_path/"0000", seed, "delay_2", caregiver=False)
    with np.load(tmp_path/"0000"/"observations.npz", allow_pickle=False) as obs:
        assert set(obs.files) == {"rgb", "audio", "proprio", "actions"}
    with pytest.raises(ValueError, match="identity mismatch"):
        collect_episode(cfg, None, tmp_path/"0000", seed, "delay_3", caregiver=False)
    with pytest.raises(ValueError, match="train/diagnostic"):
        collect_episode(cfg, None, tmp_path/"bad", seed, "iid", caregiver=False, split="final")


def test_push_feasibility_and_open_gripper():
    # This exact diagnostic scene was selected for mechanics verification,
    # not for estimating or claiming an oracle's aggregate success rate.
    cfg = config()
    row = run_trial(cfg, None, "iid", "push", 0, "construction-check",
                    policy="oracle", split="diagnostic", steps=64)
    assert row["success"]
    assert row["object_displacement"] > .10
    assert all(action[3] == -1 for action in row["issued_actions"])
    assert row["scene"]["workspace"] == "raised_push_table"
    assert row["scene"]["independent_simulator"] is False
    assert row["privileged"]


@pytest.mark.parametrize("task", ["reach", "touch", "grasp_lift"])
def test_privileged_legacy_tasks_preserve_reference_state_contract(task):
    row = run_trial(config(), None, "new_layout", task, 0, "reference-contract",
                    policy="oracle", split="diagnostic", steps=4)
    assert len(row["issued_actions"]) == 4
    assert row["privileged"]


def test_panel_validation_and_canonical_names():
    assert get_domain("dynamics").name == "new_dynamics"
    panel = make_panel("new-panel", "final", ["iid", "delay_6"], ["push"], 3)
    assert len(panel) == 6
    assert [x["scene_seed"] for x in panel[:3]] == [x["scene_seed"] for x in panel[3:]]
    assert len({x["scene_seed"] for x in panel}) == 3
    with pytest.raises(ValueError):
        DomainSpec("bad", delay_steps=-1)
    with pytest.raises(ValueError):
        panel_seed("id", "iid", "reach", 0, "test-typo")
    with pytest.raises(ValueError):
        get_domain("random_delay")
