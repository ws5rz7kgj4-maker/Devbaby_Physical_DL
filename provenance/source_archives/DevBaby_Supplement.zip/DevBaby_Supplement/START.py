#!/usr/bin/env python3
"""Compatibility entry point: this package launches the supplemental experiment."""
from pathlib import Path
import runpy

if __name__ == "__main__":
    runpy.run_path(str(Path(__file__).with_name("SUPPLEMENT.py")), run_name="__main__")
