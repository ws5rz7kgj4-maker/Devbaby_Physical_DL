# DevBaby parameter-path audit

CPU audit completed: parameter-audits/b5a388062712 in the private dataset
swenlio/devbaby-control-audit-results. Source revisions and SHA256 hashes are
included in cpu_result.json. No long training was performed.

The exact seed-0 and seed-1 checkpoint comparisons each found all four dynamics
and all four filter parameter tensors unchanged after 4,096 recorded updates.
These eight parameters also had no optimizer state. Prefix matching explicitly
requires nonempty groups. The remaining model groups changed.

For seed 1, one FP32 CPU optimizer step from both initialization and the final
checkpoint produced finite gradients and nonzero updates for those eight tensors.
Serialization/reloading preserved all state tensors exactly. Thus the basic
model/loss and CPU optimizer path can update them; the old GPU training path
requires separate investigation.

gpu_cache_check.py compares matched FP32, FP16 with autocast cache, and FP16
without autocast cache. It uses the same initial weights and sensory batch.
This is a diagnostic of the no_grad burn-in inside the autocast region, not a
claim that an AMP bug is established before the result is read. No GradScaler
is used in this minimal GPU comparison. See gpu_job.json for its run identity.

Training data remain synthetic; simulator truth does not enter these gradient
checks. Neither audit establishes learned physical control or generalization.
