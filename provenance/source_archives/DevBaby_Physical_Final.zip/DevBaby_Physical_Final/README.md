# DevBaby Physical — 正式物理泛化与学习进步实验

本版主问题是：**从随机物理经历中成长的模型，在新的物理情境中，实际完成任务的成功率如何变化；它适应新情境是否越来越快？**

语言与声音保留为训练经历，主分数是实际执行的物理任务成功率，不是语音配对准确率。
所有神经网络从随机权重开始，所有经历由模拟器与非神经语音合成器生成。

## 直接启动正式实验（Mac）

解压得到 `DevBaby_Physical_Final` 文件夹。在 Finder 中双击里面的 **`START_MAC.command`**。
它会定位自己的目录、建立启动器环境、安装云端启动依赖，并复用你的 HF 登录。
若 Mac 阻止双击，打开终端，输入 `bash` 后按空格，把 `START_MAC.command` 拖进去并回车。

也可以在终端直接执行；不需要先 `cd`：

```bash
python3 "$HOME/Downloads/DevBaby_Physical_Final/START.py"
```

**这个入口直接提交正式方案，启动一个计费的 Hugging Face Job。**
需要 HF 账户余额，以及创建/写入私有数据集仓库和运行 Jobs 的 token 权限。
已有登录会自动复用；没有登录时启动 HF 本地登录界面。Token 不写进代码、日志或提交记录。

同一 Job 内完成 2 个条件 × 8 个种子，共 **16 个独立训练模型**，依次运行。
只安装一次云端依赖；同一种子的两条件复用相同随机物理记录，避免重复仿真。
默认资源 `t4-small`，Job 上限 **24 小时**，完成即退出。
23 小时时在完整训练块/适应 episode 后保存退出，为上传留出时间；24 小时是平台硬上限。
这不是完成时间或费用承诺；若未完成，已完成模型不会重新训练，需显式续跑剩余工作。
本机只负责提交，不安装 PyTorch/模拟器；提交成功后可以关闭终端。

重复相同启动命令会返回已记录的 Job。保留 `.launch_records`，避免删除提交记录造成重复作业。

## 状态、日志、结果、续跑

```bash
python3 "$HOME/Downloads/DevBaby_Physical_Final/START.py" status
python3 "$HOME/Downloads/DevBaby_Physical_Final/START.py" logs
python3 "$HOME/Downloads/DevBaby_Physical_Final/START.py" download
```

下载后，终端打印 `report.html` 的完整位置。报告在项目 `outputs/runs/运行编号/` 中。
默认下载报告、曲线、逐任务指标和试次轨迹；全部原始训练记录与权重在私有 HF 结果仓库保留。
要下载全部原始文件：

```bash
python3 "$HOME/Downloads/DevBaby_Physical_Final/START.py" download --all-data
```

若 `suite_state.json` 是 `time_budget_reached`，前一个 Job 结束后续跑：

```bash
python3 "$HOME/Downloads/DevBaby_Physical_Final/START.py" resume
```

`resume` 会创建新的计费 Job，代码和协议必须保持不变。程序不会自动购买下一段运行时间。
停止当前作业：

```bash
python3 "$HOME/Downloads/DevBaby_Physical_Final/START.py" cancel
```

只看方案、不提交：

```bash
python3 "$HOME/Downloads/DevBaby_Physical_Final/START.py" plan
```

## 正式测量的内容

| 任务 | 成功标准 |
|---|---|
| 到达 `reach` | 最后三个控制步，手与指定空间目标的距离均小于 8 cm |
| 接触 `touch` | 与目标物体实际发生连续三个控制步的接触 |
| 抓起 `grasp_lift` | 最后三步持续抓持目标，物体中心比初始高至少 14 cm，手距抬升目标小于 13 cm |

每次任务固定 40 个控制步，不挑选最好的一帧替代最终到达/抓起结果。
评测直接运行刚体物理与动作闭环，不用预测误差充当成功率。

| 情境 | 相对训练分布的变化 |
|---|---|
| `iid` | 熟悉参数范围中的新随机场景 |
| `new_dynamics` | 未见的手部质量、伺服增益、阻尼、动作幅度，以及重力/物体质量/摩擦 |
| `new_delay` | 未在基础训练中出现的 2–3 步执行器延迟 |
| `new_layout` | 新房间外观和工作区内的新障碍布局 |
| `joint_physics` | 同时改变动力学、延迟与布局 |

任务提供**空间位置及接触/抓持目标**。控制器只读 RGB、声学特征、本体感觉、历史动作和这个目标；
不会读取实时物体坐标、质量、摩擦、分割图或成功标签。
初始接触位置是任务提供的一部分，因此这不测从语言或视觉独立定位目标的能力。
简化身体有近距离抓持原语；任务代价函数和 CEM 搜索器由程序提供，神经运动预测器从经历中学习。

## 实验预算与曲线

- 8 个独立种子，完整模型 `full` 与移除动作输入的 `no_action` 各一套。
- 每模型 32,768 个随机训练交互、8,192 次更新；两条件匹配物理经历、初始化种子和更新预算。
- 在 0、8,192、16,384、24,576、32,768 个交互时评测发展曲线，所有检查点保留。
- 所有基础模型完成后，才运行另一套场景种子的最终测试：每任务×情境 24 个试次。
- 在 0、16,384、32,768 个训练交互的模型副本上，测试适应新动力学/新延迟。
- 额外交互预算固定为 0、128、512、2,048；各模型年龄使用同一批适应经历，测试轨迹与适应经历分开。
- 原模型不被适应实验修改；每个模型年龄、种子和目标分布都有自己的模型副本与新优化器。

报告给出：成功率曲线、每增加 1,000 次交互的百分点变化、曲线下面积、
连续两个检查点达到 50%/80% 成功率所需的交互量，以及各年龄的适应曲线。
没达到阈值会保留为空值/未达到，不伪造一个完成时间。

“起点已经更好”和“额外经历带来更多进步”分别报告。
适应主比较使用减去零适应成功率后的增益 AUC；同时保留原始 AUC、初始水平和区间斜率。
高起点仍可能产生天花板效应，不能把一个分数当作抽象的通用学习能力。

预先固定的三项主比较：完整模型最终成功率相对初始模型、完整模型相对无动作模型、
成熟模型相对初始模型的适应增益 AUC。按训练种子配对，给出 bootstrap 区间及 Holm 校正。
这是预算限定的研究基线；8 个种子不等于已完成统计功效设计，也不保证得出正结果。
具体定义在 `FORMAL_EXPERIMENT.md` 和 `formal_protocol.json` 中。

## 结果与记录

```text
report.html                         总报告
physical_learning.png               成功率、增长速度、适应和学习增益四图
success_curves.csv                  各种子/任务/情境的发展曲线
growth_rates.csv                    每千次交互的成功率变化（百分点）
adaptation_curves.csv                额外经历与成功率
final_success.csv                   未见最终测试的每种子结果
summary.json                        预先固定的主统计比较
summary_thresholds.json             学习 AUC、增长速度和达标交互量
summary_baselines.json              随机动作与有特权脚本参考的真实结果
protocol.json                       开始训练前锁定的协议、配置、源码哈希
suite_state.json                    实验是否完整完成，以及当前阶段
members/*/data/shards/*.zip          全部基础训练经历与独立标注
members/*/checkpoints/*.pt           所有阶段模型与恢复状态
members/*/metrics/trials_*.jsonl     每个物理试次的动作、身体轨迹、成功序列和评分用状态
members/*/final/**                  独立最终测试
adaptation/*/experience.zip          全部适应训练经历与独立标注
adaptation/*/metrics/**              每个适应预算上的独立测试
```

每个训练 episode 都记录 RGB、原始 PCM WAV、声学特征、本体感觉、动作、物理属性、
事件、摄像机参数以及养育者语音转录/指称关系。属性标注与训练数组分开，训练数据加载器拒绝额外语义标签。
场景、身体参数、动作和语句随机抽样；物理规律与声音的关联仍然存在，随机不等于互不相关的白噪声。

随机动作和有特权脚本参考共用测试场景。脚本参考仅用于检查任务可达性，它能读取模拟器信息，
绝不算作模型成绩。报告会完整保留参考控制器和模型的失败，不在看到结果后删除难例。

## 已有 Linux GPU 终端

推荐 Python 3.10/3.11。安装与你设备匹配的 PyTorch，然后：

```bash
python -m pip install -r requirements-runtime.txt
python -m devbaby.suite --protocol formal_protocol.json --output outputs/formal --device cuda
```

继续本地运行：

```bash
python -m devbaby.suite --protocol formal_protocol.json --output outputs/formal --device cuda --resume
```

验证代码用 `python -m pytest -q`，不需要在计费 GPU Job 中重复跑测试。
本包功能测试示例只是软件验证，不是正式实验结论。实际 HF GPU 执行尚未由本对话验证。
旧的声音配对研究入口保留在 `LEGACY_MULTIMODAL.md`，本版默认入口只启动上述物理实验。
